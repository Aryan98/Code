﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace SPPWebService.JsonHelperFile
{
    public class JsonMainHelper
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        [DataContract(Name = "{0}Response")]
        public class JsonResponse<T>
        {
            #region [Private Member]
            private bool isSuccess1;
            private string message1;
            private string isfailedcount1;
            private List<T> result1;

            #endregion

            #region Properties

            /// <summary>
            /// Response result
            /// </summary>
            [DataMember]
            public List<T> result
            {
                get { return result1; }
                set { result1 = value; }
            }


            /// <summary>
            /// True, If bussiness logic return successful response
            /// </summary>
            [DataMember]
            public bool issuccess
            {
                get { return isSuccess1; }
                set { isSuccess1 = value; }
            }

            /// <summary>
            /// Response message will be either for success or unsuccess
            /// </summary>
            [DataMember]
            public string message
            {
                get { return message1; }
                set { message1 = value; }
            }

           
            [DataMember]
            public string failedcount
            {
                get { return isfailedcount1; }
                set { isfailedcount1 = value; }
            }

            #endregion
        }

        /// <summary>
        /// Response format for service. 
        /// Added extra response field .
        /// </summary>
        /// <typeparam name="T">T</typeparam>
        [DataContract(Name = "{0}Response")]
        public class JsonAdvanceResponse<T>
        {
            #region [Private Member]
            private bool _isSuccess;
            private string _message;
            private string _isfailedcount;
            private List<T> _result;
            private string _othervalues;
            #endregion

            #region Properties

            /// <summary>
            /// Response result
            /// </summary>
            [DataMember]
            public List<T> result
            {
                get
                {
                    return _result;
                }
                set
                {
                    _result = value;
                }
            }


            /// <summary>
            /// True, If bussiness logic return successful response
            /// </summary>
            [DataMember]
            public bool issuccess
            {
                get
                {
                    return _isSuccess;
                }
                set
                {
                    _isSuccess = value;
                }
            }

            /// <summary>
            /// Response message will be either for success or unsuccess
            /// </summary>
            [DataMember]
            public string message
            {
                get
                {
                    return _message;
                }
                set
                {
                    _message = value;
                }
            }


            [DataMember]
            public string failedcount
            {
                get
                {
                    return _isfailedcount;
                }
                set
                {
                    _isfailedcount = value;
                }
            }

            [DataMember]
            public string othervalues
            {
                get
                {
                    return _othervalues;
                }
                set
                {
                    _othervalues = value;
                }
            }

            #endregion
        }


        /// <summary>
        /// For Scheme Payout Service
        /// </summary>
        [DataContract(Name = "{0}Response")]
        public class SchemePayoutJsonResponse
        {
            #region [Private Member]
            private bool isSuccess1;
            private string message1;
            private string isfailedcount1;
            private string _othervalues;

            
            private List<SPPWebService.SPPWebserviceDTO.SPPSchemePayoutResponseDTO1> _result1;
            private List<SPPWebService.SPPWebserviceDTO.SPPSchemePayoutResponseDTO2> _result2;
            private List<SPPWebService.SPPWebserviceDTO.SPPSchemePayoutResponseDTO3> _result3;

            #endregion

            #region Properties

            /// <summary>
            /// Response result
            /// </summary>
            [DataMember]
            public List<SPPWebService.SPPWebserviceDTO.SPPSchemePayoutResponseDTO1> result1
            {
                get
                {
                    return _result1;
                }
                set
                {
                    _result1 = value;
                }
            }

            [DataMember]
            public List<SPPWebService.SPPWebserviceDTO.SPPSchemePayoutResponseDTO2> result2
            {
                get
                {
                    return _result2;
                }
                set
                {
                    _result2 = value;
                }
            }

            [DataMember]
            public List<SPPWebService.SPPWebserviceDTO.SPPSchemePayoutResponseDTO3> result3
            {
                get
                {
                    return _result3;
                }
                set
                {
                    _result3 = value;
                }
            }

            /// <summary>
            /// True, If bussiness logic return successful response
            /// </summary>
            [DataMember]
            public bool issuccess
            {
                get
                {
                    return isSuccess1;
                }
                set
                {
                    isSuccess1 = value;
                }
            }

            /// <summary>
            /// Response message will be either for success or unsuccess
            /// </summary>
            [DataMember]
            public string message
            {
                get
                {
                    return message1;
                }
                set
                {
                    message1 = value;
                }
            }


            [DataMember]
            public string failedcount
            {
                get
                {
                    return isfailedcount1;
                }
                set
                {
                    isfailedcount1 = value;
                }
            }

            [DataMember]
            public string othervalues
            {
                get
                {
                    return _othervalues;
                }
                set
                {
                    _othervalues = value;
                }
            }

            #endregion
        }



        /// <summary>
        /// For Price Protection Payout Service
        /// Added by Shyam Sunder Kumar as on 18-Apr-2016
        /// </summary>
        [DataContract(Name = "{0}Response1")]
        public class PriceProtectionPayoutJsonResponse
        {
            #region [Private Member]
            private bool isSuccess1;
            private string message1;
            private string isfailedcount1;
            private string _othervalues;


            private List<SPPWebService.SPPWebserviceDTO.SPPPriceProtectionPayoutResponseDTO1> _result1;
            private List<SPPWebService.SPPWebserviceDTO.SPPPriceProtectionPayoutResponseDTO2> _result2;
            private List<SPPWebService.SPPWebserviceDTO.SPPPriceProtectionPayoutResponseDTO3> _result3;

            #endregion

            #region Properties

            /// <summary>
            /// Response result
            /// </summary>
            [DataMember]
            public List<SPPWebService.SPPWebserviceDTO.SPPPriceProtectionPayoutResponseDTO1> result1
            {
                get
                {
                    return _result1;
                }
                set
                {
                    _result1 = value;
                }
            }

            [DataMember]
            public List<SPPWebService.SPPWebserviceDTO.SPPPriceProtectionPayoutResponseDTO2> result2
            {
                get
                {
                    return _result2;
                }
                set
                {
                    _result2 = value;
                }
            }

            [DataMember]
            public List<SPPWebService.SPPWebserviceDTO.SPPPriceProtectionPayoutResponseDTO3> result3
            {
                get
                {
                    return _result3;
                }
                set
                {
                    _result3 = value;
                }
            }

            /// <summary>
            /// True, If bussiness logic return successful response
            /// </summary>
            [DataMember]
            public bool issuccess
            {
                get
                {
                    return isSuccess1;
                }
                set
                {
                    isSuccess1 = value;
                }
            }

            /// <summary>
            /// Response message will be either for success or unsuccess
            /// </summary>
            [DataMember]
            public string message
            {
                get
                {
                    return message1;
                }
                set
                {
                    message1 = value;
                }
            }


            [DataMember]
            public string failedcount
            {
                get
                {
                    return isfailedcount1;
                }
                set
                {
                    isfailedcount1 = value;
                }
            }

            [DataMember]
            public string othervalues
            {
                get
                {
                    return _othervalues;
                }
                set
                {
                    _othervalues = value;
                }
            }

            #endregion
        }

    }
}