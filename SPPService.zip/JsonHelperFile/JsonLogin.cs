﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace SPPWebService.JsonHelperFile
{
    public class JsonLogin
    {
        /// <summary>
        /// 
        /// </summary>
        /// <typeparam name="T"></typeparam>
        [DataContract(Name = "{0}Response")]
        public class JsonResponse<T>
        {
            #region [Private Member]

            private bool isSuccess1;
            private string isfailedcount1;
            private string message1;
            private List<T> result1;

            #endregion

            #region Properties

            /// <summary>
            /// Response result
            /// </summary>
            [DataMember]
            public List<T> result
            {
                get { return result1; }
                set { result1 = value; }
            }


            /// <summary>
            /// True, If bussiness logic return successful response
            /// </summary>
            [DataMember]
            public bool issuccess
            {
                get { return isSuccess1; }
                set { isSuccess1 = value; }
            }

            /// <summary>
            /// Response message will be either for success or unsuccess
            /// </summary>
            [DataMember]
            public string message
            {
                get { return message1; }
                set { message1 = value; }
            }
            [DataMember]
            public string failedcount
            {
                get { return isfailedcount1; }
                set { isfailedcount1 = value; }
            }
            #endregion
        }



    }
}