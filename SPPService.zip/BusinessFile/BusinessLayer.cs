﻿using System;
using System.Data;
using System.Text;
using System.Collections;
using System.Data.SqlClient;
using System.Net.Mail;
using Microsoft.ApplicationBlocks.Data;
using System.Security.Cryptography;


/// <summary>
/// Summary description for BusinessLayer
/// </summary>
public class BusinessLayer
{
    string sProjectName = "S2P2Android";
    string sModuleName = "AndroidServices";
    string sAuthorName = "MD Qyam uddin";
    string sPageName = "BusinessLayer.cs";

    public BusinessLayer()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    DataLayer objDataLayer = new DataLayer();
    DataSet dsOutletService = new DataSet();

    #region -----
    /// <summary>
    /// Added by qyam on 05-feb-15. To validate vulnerable parameter
    /// </summary>
    /// <param name="obj">class object</param>
    /// <returns>boolean</returns>
    public bool ValidateParameter(object obj)
    {

        bool status = false;
        //string[] VulnerKey = new string[] { " ", "-", ";", "'", "or", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        //string[] VulnerKeyUserID = new string[] { " ", "-", ";", "'", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };

        string[] VulnerKey = new string[] { " ", "-", ";", "'", "or", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        string[] VulnerKeyUserID = new string[] { " ", ";", "'", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        string[] VulnerKeysubtype = new string[] { ";", "'", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };

        foreach (var prop in obj.GetType().GetProperties())
        {

            //Commented and Added by Anil verma 07 Oct 2015 to prevent productserial key
            //if(prop.Name.ToLower() != "webserviceuserid" && prop.Name.ToLower() != "webservicepassword" && prop.Name.ToLower() != "sdescription" && prop.Name.ToLower() != "selectoption" && prop.Name.ToLower() != "question" && prop.Name.ToLower() != "fromdate" && prop.Name.ToLower() != "todate" && prop.Name.ToLower() != "userapkversion" && prop.Name.ToLower() != "saletype" && prop.Name.ToLower() != "email")
            if (prop.Name.ToLower() != "webserviceuserid" && prop.Name.ToLower() != "webservicepassword" && prop.Name.ToLower() != "sdescription" && prop.Name.ToLower() != "selectoption" && prop.Name.ToLower() != "question" && prop.Name.ToLower() != "fromdate" && prop.Name.ToLower() != "todate" && prop.Name.ToLower() != "userapkversion" && prop.Name.ToLower() != "saletype" && prop.Name.ToLower() != "email" && prop.Name.ToLower() != "productserial")
            {
                string str = Convert.ToString(prop.GetValue(obj, null));
                if (!string.IsNullOrEmpty(str))
                {
                    if (prop.Name.ToLower() == "userid" || prop.Name.ToLower() == "password" || prop.Name.ToLower() == "partnercode")
                    {
                        foreach (string x in VulnerKeyUserID)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                    else if (prop.Name.ToLower() == "subtype")//Added by Shyam Sunder Kumar as on 24-July-2015 to allow space[" "]
                    {
                        foreach (string x in VulnerKeysubtype)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (string x in VulnerKey)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                }
            }
        }


        return status;
    }


   

    /// <summary>
    /// To get Api key/Token
    /// </summary>
    /// <returns>string</returns>
    public string GetUniqueKey()
    {
        int maxSize = 10;
        char[] chars = new char[62];
        string a;
        a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        chars = a.ToCharArray();
        int size = maxSize;
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        size = maxSize;
        data = new byte[size];
        crypto.GetNonZeroBytes(data);
        StringBuilder result = new StringBuilder(size);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length - 1)]);
        }
        return result.ToString();
    }

    /// <summary>
    /// Added by qyam on 05-feb-15. To validate vulnerable parameter for device registration.
    /// </summary>
    /// <param name="obj">class object</param>
    /// <returns>boolean</returns>
    public bool ValidateParameterForDeviceRegistration(object obj)
    {
        bool status = false;
        string[] VulnerKey = new string[] { "select", "from", "where", "union", "update", "insert", "delete" };//for registrationid
        string[] VulnerKeyUserID = new string[] { " ", "-", "or", ";", "'", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };

        foreach (var prop in obj.GetType().GetProperties())
        {
            if (prop.Name.ToLower() != "message")
            {
                string str = Convert.ToString(prop.GetValue(obj, null));
                if (!string.IsNullOrEmpty(str))
                {
                    if (prop.Name.ToLower() == "userid" || prop.Name.ToLower() == "webserviceuserid" || prop.Name.ToLower() == "webservicepassword" || prop.Name.ToLower() == "deviceregistrationid" || prop.Name.ToLower() == "commtype")
                    {
                        foreach (string x in VulnerKey)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (string x in VulnerKeyUserID)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                }
            }
        }

        return status;
    }

    
    

    /// <summary>
    /// Method Name   : GetForgotPasswordDetails
    /// Createdby     : MD Qyam Uddin
    /// Created On    : 25 Mar 2015
    /// Description    : To get forgot password details.
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable GetForgotPasswordDetails()
    {
        DataSet ds = null;
        DataLayer objDataLayer = new DataLayer();

        try
        {
           // ds = SqlHelper.ExecuteDataset(objDataLayer.GetS2P2Connection(), System.Data.CommandType.StoredProcedure, "spGetForgotPasswordDetails");
        }
        catch (Exception exc)
        {
           // AddExceptionLog(sProjectName, sModuleName, "", sPageName, "GetForgotPasswordDetails", sAuthorName, sAuthorName, exc.Message, "S2P2 WCF Android Exception");
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
        return ds.Tables[0];
    }
    #endregion
    #region Samsung Smart Partner Portal
    public DataSet GetPssword(string strUserID)
    {
        DataLayer dtLayer = null;
        Hashtable _hshTab = null;
        try
        {
            dtLayer = new DataLayer();

            return SqlHelper.ExecuteDataset(dtLayer.GetMCSConnection(), CommandType.StoredProcedure, "LOCAL_CE_MOB_LOGIN_PASSWORD",
                                                                                                new SqlParameter("@USERID", strUserID));
        }
        catch (Exception ex)
        {
            //Custom Error Handling 
            DataTable errTab = new DataTable();

            DataColumn errCol = new DataColumn("ErrCol");
            errCol.DataType = System.Type.GetType("System.string");
            errTab.Columns.Add(errCol);

            DataRow rw = errTab.NewRow();
            rw["Error"] = ex.Message.ToString();

            DataSet errDS = new DataSet();
            errDS.Tables.Add(errTab);

            //Finally dispose objects
            errTab.Dispose();
            errCol.Dispose();

            return errDS;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    public DataSet Login(string sUserID)
    {
        DataLayer dtLayer = null;
        Hashtable _hshTab = null;
        try
        {
            dtLayer = new DataLayer();
            /*Modified by Shyam Sunder Kumar as on 26-Jun-2015 to Change SP Name[SP2_USER_MST_GET_USERINFO to spCeGetUserInfo] to integrate SPP to the Module*/
            return SqlHelper.ExecuteDataset(dtLayer.GetMCSConnection(), CommandType.StoredProcedure, "spCeGetUserInfo",
                                                                                                new SqlParameter("@USERID", sUserID));
            /*End Changes*/
        }
        catch (Exception ex)
        {
            //Custom Error Handling 
            DataTable errTab = new DataTable();

            DataColumn errCol = new DataColumn("ErrCol");
            errCol.DataType = System.Type.GetType("System.string");
            errTab.Columns.Add(errCol);

            DataRow rw = errTab.NewRow();
            rw["Error"] = ex.Message.ToString();

            DataSet errDS = new DataSet();
            errDS.Tables.Add(errTab);

            //Finally dispose objects
            errTab.Dispose();
            errCol.Dispose();

            return errDS;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }


    #endregion

    #region"AppVersion"

    ///// <summary>
    ///// Method Name   : GetLatestAppVersion
    ///// Createdby     : MD Qyam Uddin
    ///// Created On    : 04 Feb 2015
    ///// Description   : To get Latest Mobile application version.
    ///// </summary>
    ///// <returns>string</returns>
    //public String GetLatestAppVersion()
    //{
    //    DataLayer objDataLayer = new DataLayer();
    //    String Version = null;
    //    try
    //    {
    //        Version = SqlHelper.ExecuteScalar(objDataLayer.GetS2P2Connection(), System.Data.CommandType.StoredProcedure, "SPP_GetLatestAppVersion").ToString();
    //    }
    //    catch (Exception exc)
    //    {
    //        AddExceptionLog(sProjectName, sModuleName, "", sPageName, "GetLatestAppVersion", sAuthorName, sAuthorName, exc.Message, "S2P2 WCF Android Exception");
    //    }
    //    finally
    //    {
    //        if (objDataLayer != null)
    //        {
    //            objDataLayer = null;
    //        }
    //    }
    //    return Version;
    //}

    /// <summary>
    /// Method Name   : GetLatestAppVersion
    /// Createdby     : Anil Verma
    /// Created On    : 29 july 2015
    /// Description   : To get Latest Mobile application version and isupgrademandatory column value.
    /// </summary>
    /// <returns>string</returns>
    public DataSet GetLatestAppVersion()
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsVersion = new DataSet();
        try
        {
            // dsVersion = SqlHelper.ExecuteDataset(objDataLayer.GetS2P2Connection(), System.Data.CommandType.StoredProcedure, "SPP_GetLatestAppVersion");
        }
        catch (Exception exc)
        {
            // AddExceptionLog(sProjectName, sModuleName, "", sPageName, "GetLatestAppVersion", sAuthorName, sAuthorName, exc.Message, "S2P2 WCF Android Exception");
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
        return dsVersion;
    }
    #endregion

    #region"Access Log Implementation"

   

  
   
 

    #endregion





}

