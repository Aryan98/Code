﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using SPPWebservice.SPPWebserviceDTO;

namespace Auth2.SDS
{
    public enum tokentype
    {
        bearer,
        create,
        modify,
        refresh_token,
        authorization_code
    }
    public enum DeviceType
    {
        WEB,
        APP,
       
    }
    public class AuthProvider : IAuthProviderfunc
    {
        SPPBusinessLayer oSPPBusinessLayer = new SPPBusinessLayer();
        public string getToken()
        {
            return Guid.NewGuid().ToString();
        }

        public bool validationClient(AuthModel authmodel)
        {
            //Todo: check with database
            return true;
        }
        public void InsertAuthorizationCode(AuthModel authmodel)
        {

            oSPPBusinessLayer.AddAuthorizationcodeAuth2(authmodel);


        }
        public DataTable GetDealerCodeByAuthToken(AuthModel authmodel)
        {
            DataTable dt = new DataTable();
            dt = oSPPBusinessLayer.GetDealerCodeByAuthToken(authmodel);
            return dt;
        }
        public bool ValidateTokenParameter(AuthTokenParamRequestDTO input)
        {
            return oSPPBusinessLayer.ValidateAddTokenParam(input);
        }
    }
}