﻿/****************************** Module Header ******************************
Module Name     :   Utility Module
Project         :   S2P2 Android Application
Developer       :   Shyam Sunder Kumar
Team Mates      :   Manoj Maurya
Team Lead       :   Sabi Abbas, Vipin Talwar
Project Manager :   Moraji Kumar
CreatedOn       :   23-June-2015
ModifiedBy      :
ModifiedOn      :   
Description     : 

Utility Class
***************************************************************************/
using System;
using System.Web;
using System.Text.RegularExpressions;
using System.Data;
using Microsoft.ApplicationBlocks.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
using System.Text;
using System.Security.Cryptography;
using System.Globalization;
using System.Collections.Generic;
using System.Net.Mail;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Transactions;
using System.Net;
using System.Net.Mime;
using System.Collections;
namespace SPPWebService.SPP
{
    public class SPPUtility
    {

        private byte[] key = { };
        private byte[] IV = { 18, 52, 86, 120, 144, 171, 205, 239 };
        string sEncryptionKey = "!*&@9876543210";
        public string[] Month = new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
        public string[] ShortMonth = new string[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sept", "Oct", "Nov", "Dec" };

        static private Byte[] m_Key = new Byte[8];
        static private Byte[] m_IV = new Byte[8];
        private static readonly byte[] salt = Encoding.ASCII.GetBytes("sdspp100");

        private static string IV1 = "IV_VALUE_16_BYTE";
        private static string PASSWORD = "PASSWORD_VALUE";

        public enum _Sections
        {

            Product_Corner = 1,
            Marketing_Corner = 2,
            Channel_Corner = 3,
            Menu = 4,
            Inbox = 5,
            Support = 6,
            Login = 7,
            Notification = 8,
            MyGalaxtMCS = 9, // for My galaxy error log
            Latest_Updates = 10,

            //Code by Sandeep kaur on 31 march 2016 to implement city and state
            App_Profile = 11,
            Leadershipblog = 12,
            //Added By Amit Kr Singh on 19-Oct-2016 for Digital Signature
            DigitalSignature = 13,

            //Added By shaif rizvi on 19-Oct-2016 for MyReward
            MyRewardCategory = 14,

            //Added By shaif rizvi on 27-Oct-2016 for MyReward
            MyRewardGetProduct = 15,

            //Added By shaif rizvi on 27-Oct-2016 for MyReward
            MyRewardGetHolidayfilter = 16,
            //Added By Shabi on 03-Nov-2016 for MyReward
            MyRewardHolidayPackages = 17,
            //Added By Shabi on 03-Nov-2016 for MyReward
            MyRewardPackageDetails = 18,

            //Added By shaif on 02-feb-2017 for policy and guidlines
            PoliceandGuidelines = 18,
            GetMyRewardPartnerDetails = 19,
            SaveGiftPoint = 20,
            //Added by Shyam Sunder Kumar as on 23-05-2017 for channel Program
            ChannelProgram = 21,
            //Added by shaif 6-8-2017
            PurchaseAccessories = 22,

            //Added by chandra prakash singh 20-04-2018
            B2B = 23,

            DigitalSignatureOpramail = 24,
            Auth2 = 25,
            SMAPPModule = 26,
            OrderManagement = 27,
            ADSIntegration = 28,
            TwoFactorAuthentication = 29,
            SuperAPP = 30,
            MRRRFSmartToolManagement = 31
        }

        public enum _Division
        {
            CE = 1,
            HHP = 2,
        }

        /*For Module Name*/
        public static string MenuModule
        {
            get
            {
                return "Menu";
            }
        }

        public static string ProductCornerModule
        {
            get
            {
                return "PC";
            }
        }

        public static string MarketingCornerModule
        {
            get
            {
                return "MC";
            }
        }

        public static string ChannelCornerModule
        {
            get
            {
                return "CC";
            }
        }

        public static string InboxModule
        {
            get
            {
                return "Inbox";
            }
        }
        public static string Support
        {
            get
            {
                return "Support";
            }
        }
        /*End For Module Name*/
        /*For Image path of Menu/dashboard*/
        public static string MenuCenter
        {
            get
            {
                return "Materials/MenuCenter";
            }
        }
        public static string OverlayPopup
        {
            get
            {
                return "Materials/App/OverlayPopup";
            }
        }
        public static string ProductCenter
        {
            get
            {
                return "Materials/ProductCenter";
            }
        }

        public static string MarketingCenter
        {
            get
            {
                return "Materials/MarketingCenter";
            }
        }

        public static string ChannelCorner
        {
            get
            {
                return "Materials/ChannelCorner";
            }
        }

        public static string AppMenu
        {
            get
            {
                return "Materials/App/AppMenuIcons";
            }
        }

        public static string MyReward
        {
            get
            {
                return "Materials/App/MyReward";
            }
        }

        public static string AppNotificationCategoryIcon
        {
            get
            {
                return "Materials/App/AppNotificationCategoryIcon";
            }
        }
        // Added by Shaif Rizvi on 04-Apr-2018 for Upgrade Popup
        public static string UpgradePopup
        {
            get
            {
                return "Materials/Upgrade";
            }
        }
        /// <summary>
        /// For Channel Program File Path
        /// Added by Shyam Sunder Kumar as on 23-05-2017
        /// </summary>
        public static string ChannelProgramEngine
        {
            get
            {
                return "Materials/PME";
            }
        }

        //Added by shaif on 25-Oct-2016
        public static string DigitalSignature
        {
            get
            {
                return "DS";
            }
        }
        //Added by Anil verma on 18 april 2016 for leadership blog module
        public static string Leadershipblog
        {
            get
            {
                return "LB";
            }
        }


        //Added by Anil verma on 30 May 2016 for My Profile module
        public static string MYProfile
        {
            get
            {
                return "MyProfile";
            }
        }
        //Added by shaif on 17 OCT 2016 for My Reward
        public static string MyRewardModule
        {
            get
            {
                return "MyReward";
            }
        }

        //Added by Shyam Sunder Kumar as on 23-05-2017 for Channel Program
        public static string ChannelProgram
        {
            get
            {
                return "ChannelProgram";
            }
        }
        //Added by shaif on 2 feb 2017 for PoliceandGuideline
        public static string PoliceandGuideline
        {
            get
            {
                return "PoliceandGuideline";
            }
        }
        //Added by Shyam Sunder Kumar as on 23-05-2017 for Channel Program
        public static string PrebookOrder
        {
            get
            {
                return "PrebookOrder";
            }
        }
        //Added by Dheeraj on 27 Aug 2020 for SMAPP
        public static string SMAPPModule
        {
            get
            {
                return "SMAPP";
            }
        }

        public static string OrderBookingModule
        {
            get
            {
                return "Orderbook";
            }
        }
        public static string B2BModule
        {
            get
            {
                return "Materials/B2B";
            }
        }
        //Added by Shyam Sunder on 14-07-2023 for MM MR Tool Report
        public static string MMMRTool
        {
            get
            {
                return "MMMRTool";
            }
        }
        public static String HexConverterColor()
        {
            Random rnd = new Random();
            Color c = Color.FromArgb(rnd.Next(256), rnd.Next(256), rnd.Next(256));
            return "#" + c.R.ToString("X2") + c.G.ToString("X2") + c.B.ToString("X2");
        }
        /// <summary>
        /// Function to Write Log
        //Added by Anil verma on 3 June 2016 
        /// </summary>
        /// <param name="vMessageText">Message Text</param>
        public static void WriteLog(string vMessageText)
        {
            string vStrLog = string.Empty;
            String vStrFlPath = string.Empty;
            DirectoryInfo objDrInfo = null;
            StreamWriter objSw = null;
            try
            {


                //                string appPath = HttpContext.Current.Request.PhysicalApplicationPath;
                string filePath = "\\bin\\Smslog.txt";
                StreamWriter w;
                //w = File.CreateText("Log Date " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "\n" + vMessageText);
                string finalpath = HttpContext.Current.Server.MapPath("~") + filePath;
                File.AppendAllText(finalpath, "Log Date : " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + vMessageText);



            }
            catch (Exception ex)
            {
                throw new Exception("Error in Write File. Error Details : " + ex.Message);

            }
            finally
            {
                if (objDrInfo != null)
                {
                    objDrInfo = null;
                }

                if (objSw != null)
                {
                    objSw = null;
                }
            }
        }


        public static string AppBanners
        {
            get
            {
                return "Materials/App/AppBanners";
            }
        }
        /*End For Image path of Menu/dashboard*/

        private static string webserviceuserid
        {
            get
            {
                return ConfigurationManager.AppSettings["SPP_webserviceuserid"];
            }
        }

        private static string webservicepassword
        {
            get
            {
                return ConfigurationManager.AppSettings["SPP_webservicepassword"];
            }
        }

        private static string HtmlContentBaseURL
        {
            get
            {
                return ConfigurationManager.AppSettings["SPP_HtmlContentBaseURL"];
            }
        }

        private string FileCredential
        {
            get
            {
                return "&webserviceuserid=" + Encrypt(webserviceuserid) + "&webservicepassword=" + Encrypt(webservicepassword);
            }
        }

        //SPP nepal changes for image 64 bit securiy issue fixes Amandeep Singh 2022 march 16 start [SPP_Nepal_Mearge]

        public string GetFilePath(string vFilePath)
        {
            vFilePath = vFilePath.Replace("%20", " ");
            return "AppHandler.ashx?FilePath=" + Encrypt(vFilePath) + FileCredential;
        }

        //public string GetFilePath(string vFilePath)
        //{
        //    vFilePath = vFilePath.Replace("%20", " ");
        //    return Encrypt(vFilePath);
        //}

        //SPP nepal changes for get image in post method start 15 march 2022 [SPP_Nepal_Mearge]
        public SPPImageDetailsDTO GetFileDetails(string vFilePath)
        {
            SPPImageDetailsDTO sppImageDetailsDTO = new SPPImageDetailsDTO();
            sppImageDetailsDTO.filepath = Encrypt(vFilePath);
            sppImageDetailsDTO.webserviceuserid = Encrypt(webserviceuserid);
            sppImageDetailsDTO.webservicepassword = Encrypt(webservicepassword);
            return sppImageDetailsDTO;
        }
        //SPP nepal changes for get image in post method end 15 march 2022
        /// <summary>
        /// To Get NAS File Path [Added by Shyam Sunder Kumar as on 24-05-2017]
        /// </summary>
        /// <param name="vFilePath">File Path</param>
        /// <returns>string</returns>
        /// <summary>
        /// To Get NAS File Path [Added by Shyam Sunder Kumar as on 24-05-2017]
        /// </summary>
        /// <param name="vFilePath">File Path</param>
        /// <returns>string</returns>
        public string GetNASFilePath(string vFilePath)
        {
            vFilePath = vFilePath.Replace("%20", " ");
            return "FileHandler.ashx?" + EncryptQueryString("FilePath=" + vFilePath + "&source=service");
        }
        /*To Encrypt Credential*/

        /// <summary>
        /// Function to Clean Input Text
        /// </summary>
        /// <param name="vSourceData">Source Data</param>
        /// <param name="vHTMLAllowed">HTML Allowed</param>
        /// <param name="vScriptTagAllowed">Script Tag Allowed</param>
        /// <returns>string</returns>
        public string Clean(string vSourceData, bool vHTMLAllowed, bool vScriptTagAllowed)
        {

            if (vSourceData != "" & vSourceData != null)
            {
                // Replace single quote 
                vSourceData = vSourceData.Replace("'", "''");
                while (vSourceData.IndexOf("<  ") >= 0)
                {
                    vSourceData = vSourceData.Replace("<  ", "< ");
                }

                while (vSourceData.IndexOf(">  ") >= 0)
                {
                    vSourceData = vSourceData.Replace(">  ", "> ");
                }

                vSourceData = vSourceData.Replace("--", "&#173;");
                //

                //SQL Related SQL Injection Cleaned
                vSourceData = Regex.Replace(vSourceData, "exec", "&#101;xec", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "xp_cmdshell", "&#120;p_cmdshell", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "select", "&#115;elect", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "insert", "&#105;nsert", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "update", "&#117;pdate", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "delete", "&#100;elete", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "drop", "&#100;rop", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "truncate", "&#116;runcate", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "create", "&#99;reate", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "rename", "&#114;ename", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "alter", "&#97;lter", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "exists", "&#101;xists", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "master.", "&#109;aster.", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "restore", "&#114;estore", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "sp_", "&#115;p_", RegexOptions.IgnoreCase);
                //END

                if (vHTMLAllowed == false)
                {
                    vSourceData = HttpContext.Current.Server.UrlEncode(vSourceData);
                    //vSourceData = HttpUtility.UrlEncode(vSourceData);
                }
                else
                {
                    if (vScriptTagAllowed == false)
                    {
                        // Replace SCRIPT Tag 

                        vSourceData = Regex.Replace(vSourceData, "<script", "&lt;script", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "</script", "&lt;/script", RegexOptions.IgnoreCase);

                        vSourceData = Regex.Replace(vSourceData, "< script", "&lt;script", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "</ script", "&lt;/script", RegexOptions.IgnoreCase);


                        vSourceData = Regex.Replace(vSourceData, "&lt;script", "", RegexOptions.IgnoreCase);

                        vSourceData = Regex.Replace(vSourceData, "<input", "&lt;input", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "</input", "&lt;/input", RegexOptions.IgnoreCase);

                        vSourceData = Regex.Replace(vSourceData, "<form", "&lt;form", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "</form", "&lt;/form", RegexOptions.IgnoreCase);

                        vSourceData = Regex.Replace(vSourceData, "<embed", "&lt;embed", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "</embed", "&lt;/embed", RegexOptions.IgnoreCase);


                        vSourceData = Regex.Replace(vSourceData, "<textarea", "&lt;textarea", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "</textarea", "&lt;/textarea", RegexOptions.IgnoreCase);

                        vSourceData = Regex.Replace(vSourceData, "<select", "&lt;select", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "</select", "&lt;/select", RegexOptions.IgnoreCase);


                        vSourceData = Regex.Replace(vSourceData, "<img", "&lt;img", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "</img", "&lt;/img", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "window.open", "", RegexOptions.IgnoreCase);
                        vSourceData = vSourceData.Replace("alert(", "");

                    }
                }
                vSourceData = vSourceData.Replace("<", "&lt;");
                vSourceData = vSourceData.Replace(">", "&gt;");

                vSourceData = vSourceData.Replace(";", "&#59;");
            }

            return vSourceData.Trim();
        }

        /// <summary>
        /// To Clean Normal Data
        /// </summary>
        /// <param name="vSourceData">Source Data</param>
        /// <returns>string</returns>
        public string Clean(string vSourceData)
        {
            string CleanedData = Clean(vSourceData, true, false);
            return CleanedData;
        }

        /// <summary>
        /// Function to Clean Data Table
        /// </summary>
        /// <param name="vDataTable">Data Table</param>
        /// <returns>Data Table</returns>
        public DataTable CleanDataTable(DataTable vDataTable)
        {
            int vRowCount = vDataTable.Rows.Count;
            int vColumnCount = vDataTable.Columns.Count;

            for (int i = 0; i < vRowCount; i++)
            {
                for (int j = 0; j < vColumnCount; j++)
                {
                    string DataType = vDataTable.Rows[0][j].GetType().ToString();

                    if (DataType.ToUpper() == "SYSTEM.STRING")
                    {
                        if (vDataTable.Columns[j].ReadOnly == false)
                        {
                            vDataTable.Rows[i][j] = Clean(vDataTable.Rows[i][j].ToString(), true, false);
                        }
                    }
                }
            }
            return vDataTable;

        }

        /// <summary>
        /// Function to Reverse Conversion
        /// </summary>
        /// <param name="vSourceData">Source Data</param>
        /// <returns>string</returns>
        public string ReverseConversion(string vSourceData)
        {
            string ReversedData = ReverseConversion(vSourceData, true, false);
            return ReversedData;
        }

        /// <summary>
        /// Function to Reverse Conversion
        /// </summary>
        /// <param name="vSourceData">Source Data</param>
        /// <param name="vHTMLAllowed">HTML Allowed</param>
        /// <param name="vscriptTagAllowed">Script Tag Allowed</param>
        /// <returns>string</returns>
        public string ReverseConversion(string vSourceData, bool vHTMLAllowed, bool vscriptTagAllowed)
        {

            if (vSourceData != "" & vSourceData != null)
            {
                vSourceData = vSourceData.Replace("&#59;", ";");
                vSourceData = vSourceData.Replace("&#59", ";");
                vSourceData = vSourceData.Replace("’", "'");
                //SQL Related SQL Injection Cleaned
                vSourceData = Regex.Replace(vSourceData, "&#101;xec", "exec", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#120;p_cmdshell", "xp_cmdshell", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#115;elect", "select", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#105;nsert", "insert", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#117;pdate", "update", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#100;elete", "delete", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#100;rop", "drop", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#116;runcate", "truncate", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#99;reate", "create", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#114;ename", "rename", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#97;lter", "alter", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#101;xists", "exists", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#109;aster.master.", "", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#114;estore", "restore", RegexOptions.IgnoreCase);
                vSourceData = Regex.Replace(vSourceData, "&#115;p_", "sp_", RegexOptions.IgnoreCase);
                //END

                if (vHTMLAllowed == false)
                {
                    vSourceData = HttpContext.Current.Server.UrlEncode(vSourceData);
                }
                else
                {
                    if (vscriptTagAllowed == false)
                    {

                        vSourceData = Regex.Replace(vSourceData, "&lt;script", "", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "&lt;/script", "", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "<script", "", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "</script", "", RegexOptions.IgnoreCase);


                        vSourceData = Regex.Replace(vSourceData, "&lt;input", "<input", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "&lt;/input", "</input", RegexOptions.IgnoreCase);

                        vSourceData = Regex.Replace(vSourceData, "&lt;form", "<form", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "&lt;/form", "</form", RegexOptions.IgnoreCase);

                        vSourceData = Regex.Replace(vSourceData, "&lt;embed", "<embed", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "&lt;/embed", "</embed", RegexOptions.IgnoreCase);


                        vSourceData = Regex.Replace(vSourceData, "&lt;textarea", "<textarea", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "&lt;/textarea", "</textarea", RegexOptions.IgnoreCase);

                        vSourceData = Regex.Replace(vSourceData, "&lt;select", "<select", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "&lt;/select", "</select", RegexOptions.IgnoreCase);

                        vSourceData = Regex.Replace(vSourceData, "&lt;img", "<img", RegexOptions.IgnoreCase);
                        vSourceData = Regex.Replace(vSourceData, "&lt;/img", "</img", RegexOptions.IgnoreCase);
                        vSourceData = vSourceData.Replace("alert(", "");


                    }
                }
                vSourceData = vSourceData.Replace("''", "'");
                vSourceData = vSourceData.Replace("&lt;", "<");
                vSourceData = vSourceData.Replace("&gt;", ">");

                vSourceData = vSourceData.Replace("&#173;", "--");

            }

            return vSourceData.Trim();
        }

        /// <summary>
        /// Function to Generic Replace
        /// </summary>
        /// <param name="vDataTable">Data Table</param>
        /// <returns>DataTable</returns>
        public DataTable GenericReplace(DataTable vDataTable)
        {

            int maxRow = vDataTable.Rows.Count;
            int maxColumn = vDataTable.Columns.Count;
            for (int i = 0; i < maxRow; i++)
            {
                for (int j = 0; j < maxColumn; j++)
                {
                    string DataType = vDataTable.Rows[0][j].GetType().ToString();
                    if (DataType.ToUpper() == "SYSTEM.STRING")
                    {
                        if (vDataTable.Columns[j].ReadOnly == false)
                        {
                            vDataTable.Rows[i][j] = ReverseConversion(vDataTable.Rows[i][j].ToString());
                        }
                    }
                }
            }
            return vDataTable;

        }
        /// <summary>
        /// Function to insert Error Log
        /// </summary>
        /// <param name="vLogComments">Log Comments</param>
        /// <param name="vFullError">Full Error</param>
        /// <param name="vSection">Section</param>
        /// <param name="vSectionID">Section ID</param>
        /// <param name="vUserID">User ID</param>
        /// <returns>bool</returns>
        public bool InsertintoErrorLog(string vLogComments, string vFullError, string vSection, int vSectionID, int vUserID)
        {
            DataTable dt = new DataTable();
            DataLayer dtLayer = new DataLayer();
            string vMailerBody = string.Empty;
            string vURL = string.Empty;

            string vIPAddress = string.Empty;
            string vErrorSource = string.Empty;
            try
            {

                vErrorSource = (string.IsNullOrEmpty(ConfigurationManager.AppSettings["ErrorSource"]) == true ? ""
                          : ConfigurationManager.AppSettings["ErrorSource"].ToString());


                vIPAddress = string.Empty;

                SqlHelper.ExecuteNonQuery(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spInsertErrorLog"
                                                     , new SqlParameter("@LogComments", vLogComments)
                                                     , new SqlParameter("@FullError", vFullError)
                                                     , new SqlParameter("@Section", vSection)
                                                     , new SqlParameter("@IPAddress", vIPAddress)
                                                     , new SqlParameter("@URL", vURL)
                                                     , new SqlParameter("@SectionID", Convert.ToInt32(vSectionID).ToString())
                                                     , new SqlParameter("@RefUserID", Convert.ToInt32(vUserID).ToString())
                                                     , new SqlParameter("@CreatedOn", DateTime.Now));
                vMailerBody = vMailerBody + "<div class=DetlsBand><table width='100%' border='1' cellspacing='0' cellpadding='3'>" +
                    "<tr>" +
                        "<td width='7%' valign='top'>" + "ProjectName</td>" + "<td width='7%' valign='top'>" + "Section</td>" + "<td valign='top'>" +
                            "Log Comment</td>" +
                        "<td valign='top'>" +
                            "Full Error </td>" +
                    "</tr>" +
                    "<tr>" +
                        "<td>SPP Android Application - " + vErrorSource + "</td>" +
                        "<td>SPP - Android Application Web services - " + vSection + "</td>" +
                        "<td>" +
                            vLogComments + "</td>" +
                        "<td>" +
                            vFullError + "</td>" +
                    "</tr>" +
                "</table></div>";

                SendMailer(ConfigurationManager.AppSettings["SendErrorMailList"].ToString(), ConfigurationManager.AppSettings["ErrorLogAdmin"].ToString(),
                    "SPPWebService-Exception", vMailerBody);
                return true;

            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                if (dt != null)
                {
                    dt.Dispose();
                    dt = null;
                }

                if (dtLayer != null)
                {
                    dtLayer = null;
                }

            }
        }

        /// <summary>
        /// Function to insert Error Log
        /// </summary>
        /// <param name="vLogComments">Log Comments</param>
        /// <param name="vFullError">Full Error</param>
        /// <param name="vSection">Section</param>
        /// <param name="vSectionID">Section ID</param>
        /// <param name="vUserID">User ID</param>
        /// <returns>bool</returns>
        public bool InsertintoLog(string vLogComments, string vFullError, string vSection, int vSectionID, int vUserID)
        {
            DataTable dt = new DataTable();
            DataLayer dtLayer = new DataLayer();
            string vMailerBody = string.Empty;
            string vURL = string.Empty;

            string vIPAddress = string.Empty;
            string vErrorSource = string.Empty;
            try
            {

                vErrorSource = (string.IsNullOrEmpty(ConfigurationManager.AppSettings["ErrorSource"]) == true ? ""
                          : ConfigurationManager.AppSettings["ErrorSource"].ToString());


                vIPAddress = string.Empty;

                SqlHelper.ExecuteNonQuery(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spInsertErrorLog"
                                                     , new SqlParameter("@LogComments", vLogComments)
                                                     , new SqlParameter("@FullError", vFullError)
                                                     , new SqlParameter("@Section", vSection)
                                                     , new SqlParameter("@IPAddress", vIPAddress)
                                                     , new SqlParameter("@URL", vURL)
                                                     , new SqlParameter("@SectionID", Convert.ToInt32(vSectionID).ToString())
                                                     , new SqlParameter("@RefUserID", Convert.ToInt32(vUserID).ToString())
                                                     , new SqlParameter("@CreatedOn", DateTime.Now));

                return true;

            }
            catch (Exception ex)
            {
                return false;
            }
            finally
            {
                if (dt != null)
                {
                    dt.Dispose();
                    dt = null;
                }

                if (dtLayer != null)
                {
                    dtLayer = null;
                }

            }
        }

        /// <summary>
        /// Function to Insert User Section Visit Log
        /// </summary>
        /// <param name="vUserID">User ID</param>
        /// <param name="vApiKey">Api Key</param>
        /// <param name="vApiToken">Api Token</param>
        /// <param name="vModule">Module</param>
        /// <param name="vWebMethodName">Visit Page Name</param>
        /// <param name="vIPAddress">IP Address</param>
        public void UserSectionVisitInsert(int vUserID, string vApiKey, string vApiToken, string vModule, string vWebMethodName, string vIPAddress)
        {
            DataLayer dtLayer = new DataLayer();
            try
            {

                SqlHelper.ExecuteNonQuery(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spInsertLogTransaction"
                                                    , new SqlParameter("@UserID", vUserID)
                                                    , new SqlParameter("@Portal", "Android App")
                                                    , new SqlParameter("@Module", vModule)
                                                    , new SqlParameter("@Token", vApiKey + vApiToken)
                                                    , new SqlParameter("@VisitPageName", vWebMethodName + "- WS")
                                                    , new SqlParameter("@IPAddress", vIPAddress)
                                                    , new SqlParameter("@VisitTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dtLayer != null)
                {
                    dtLayer = null;
                }
            }
        }

        /// <summary>
        /// Function to Insert User Section Visit Log
        /// </summary>
        /// <param name="vUserID">User ID</param>
        /// <param name="vApiKey">Api Key</param>
        /// <param name="vApiToken">Api Token</param>
        /// <param name="vModule">Module</param>
        /// <param name="vWebMethodName">Visit Page Name</param>
        /// <param name="vIPAddress">IP Address</param>
        public void UserSectionVisitInsert(int vUserID, string vApiKey, string vApiToken, string vModule, string vWebMethodName, string vIPAddress, string callby, string sduserid)
        {
            DataLayer dtLayer = new DataLayer();
            try
            {

                SqlHelper.ExecuteNonQuery(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spInsertLogTransaction"
                                                    , new SqlParameter("@UserID", vUserID)
                                                    , new SqlParameter("@Portal", "Android App")
                                                    , new SqlParameter("@Module", vModule)
                                                    , new SqlParameter("@Token", vApiKey + vApiToken)
                                                    , new SqlParameter("@VisitPageName", vWebMethodName + "- WS")
                                                    , new SqlParameter("@IPAddress", vIPAddress)
                                                    , new SqlParameter("@VisitTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))
                                                    , new SqlParameter("@callby", callby)
                                                     , new SqlParameter("@sduserid", sduserid));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dtLayer != null)
                {
                    dtLayer = null;
                }
            }
        }

        /// <summary>
        /// Service to get the comma seprated value.
        /// </summary>
        /// <param name="dt">Datatable collection</param>
        /// <param name="sColName">any coloumn of datatable</param>
        /// <returns>string</returns>
        public string GetCommaSepratedValue(DataTable dt, string sColName)
        {
            string result = string.Empty;
            foreach (DataRow dr in dt.Rows)
            {
                result += dr[sColName].ToString() + ",";
            }
            if (result.Length > 1)
            {
                result = result.Remove(result.Length - 1, 1);
            }
            return (result);
        }

        /// <summary>
        /// Function to Decrypt 
        /// </summary>
        /// <param name="stringToDecrypt">string To Decrypt</param>
        /// <returns>string</returns>
        public string Decrypt(string stringToDecrypt)
        {
            stringToDecrypt = stringToDecrypt.Replace(" ", "+");
            byte[] inputByteArray = new byte[stringToDecrypt.Length + 1];

            key = System.Text.Encoding.UTF8.GetBytes(sEncryptionKey.Substring(0, 8));
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            inputByteArray = Convert.FromBase64String(stringToDecrypt);
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(key, IV), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            System.Text.Encoding encoding = System.Text.Encoding.UTF8;
            return encoding.GetString(ms.ToArray());

        }

        /// <summary>
        /// Function to Encrypt
        /// </summary>
        /// <param name="stringToEncrypt">string To Encrypt</param>
        /// <returns>string</returns>
        public string Encrypt(string stringToEncrypt)
        {

            key = System.Text.Encoding.UTF8.GetBytes(sEncryptionKey.Substring(0, 8));
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            byte[] inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(key, IV), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            return Convert.ToBase64String(ms.ToArray());

        }

        /// <summary>
        ///  Method to convert datetime into dd-mm-yyyy format.
        /// </summary>
        /// <param name="vSource"></param>
        /// <returns></returns>
        public string GetDateFormate(DateTime vSource)
        {
            return vSource.ToString("dd-MM-yyyy");
        }

        /// <summary>
        /// Method to convert string representation of a date and time into DateTime.
        /// </summary>
        /// <param name="vSource">vSource</param>
        /// <returns>DateTime</returns>
        public DateTime SetDateFormate(string vSource)
        {
            return DateTime.ParseExact(vSource, "dd-MM-yyyy", CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// Method to convert string representation of a date and time
        /// </summary>
        /// <param name="vSource">vSource</param>
        /// <returns>string</returns>
        public string SetDateFormateForDB(string vSource)
        {
            return DateTime.ParseExact(vSource, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyy-MM-dd").ToString();
        }

        /// <summary>
        /// Method to get month name from string representation of a date and time.
        /// </summary>
        /// <param name="txtdate">Date</param>
        /// <param name="format">Date format</param>
        /// <returns>string</returns>
        public string FormatDisplayDate(string txtdate, string format)
        {
            string result = string.Empty;

            if (!string.IsNullOrEmpty(txtdate) && !string.IsNullOrEmpty(format))
            {
                DateTime postingDate = Convert.ToDateTime(txtdate);
                result = string.Format(format, postingDate);
            }

            return result;
        }

        /// <summary>
        /// Method to get Start Date of Previous Months
        /// </summary>
        /// <param name="NoMonth">(int) Number of months</param>
        /// <returns>string</returns>
        public string getPreviousMonthStartDate(int NoMonth)
        {
            DateTime SDate = DateTime.Now;
            DateTime month = new DateTime(SDate.Year, SDate.Month, 1);
            DateTime first = month.AddMonths(-NoMonth);

            return first.ToString("dd-MM-yyyy");
        }

        /// <summary>
        /// Method to get EndDate of Current Month
        /// </summary>
        /// <returns></returns>
        public string getCurrentMonthEndDate()
        {
            DateTime SDate = DateTime.Now;
            DateTime firstOfNextMonth = new DateTime(SDate.Year, SDate.Month, 1).AddMonths(1);
            DateTime lastOfThisMonth = firstOfNextMonth.AddDays(-1);

            return lastOfThisMonth.ToString("dd-MM-yyyy");
        }

        /// <summary>
        /// Function will provide current date in yyyy-MM-dd HH:mm:ss
        /// </summary>
        /// <returns>string</returns>
        public string CurrentDatetime()
        {
            DateTime currentDateTime = DateTime.Now;
            string dtString = currentDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            return dtString;
        }

        /// <summary>
        /// Method to get data from database
        /// according to page index and page size.
        /// </summary>
        /// <param name="dt">Data form database Datatable</param>
        /// <param name="pageindex">Page Index</param>
        /// <param name="pageSize">Page Size</param>
        /// <returns>DataTable</returns>
        public DataTable GetFilterDataByPaging(DataTable dt, int pageindex, int pageSize)
        {
            DataTable paggedtable = new DataTable();
            paggedtable = dt.Clone();
            int initial = pageSize * (pageindex - 1);
            int last = initial + pageSize;

            if (last > dt.Rows.Count)
                last = dt.Rows.Count;

            if (initial < 0)
            {
                paggedtable = null;
            }
            else
            {
                for (int i = initial; i < last; i++)
                {
                    paggedtable.ImportRow(dt.Rows[i]);

                }
            }
            return paggedtable;
        }
        /// <summary>
        /// To get the number of page will 
        /// be created by paging.
        /// </summary>
        /// <param name="recordCount">Total recordCount</param>
        /// <param name="pageSize">Page Size</param>
        /// <returns>int</returns>
        public int GetPageCount(int recordCount, int pageSize)
        {
            double dblPageCount = (double)((decimal)recordCount / Convert.ToDecimal(pageSize));
            int pageCount = (int)Math.Ceiling(dblPageCount);
            return pageCount;
        }

        /// <summary>
        /// Function to Get HTML Content Image URL
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public string GetHTMLContentImageUrl(string vSource)
        {
            List<string> images = new List<string>();
            string pattern = @"<(img)\b[^>]*>";

            Regex rgx = new Regex(pattern, RegexOptions.IgnoreCase);
            MatchCollection matches = rgx.Matches(vSource);
            string vStyle = string.Empty;
            string vAlt = string.Empty;
            for (int k = 0, l = matches.Count; k < l; k++)
            {
                images.Add(matches[k].Value);
            }

            List<imgobject> objImages = new List<imgobject>();
            string sBasePath = HtmlContentBaseURL;
            for (int p = 0; p < images.Count; p++)
            {
                imgobject objimg = new imgobject();
                if (images[p].IndexOf(images[p]) != -1)
                {
                    objimg.oldimg = images[p].ToString();
                    if (objimg.oldimg.Contains("style"))
                    {
                        vStyle = Regex.Match(objimg.oldimg, "<img.+?style=[\"'](.+?)[\"'].+?>", RegexOptions.IgnoreCase).Groups[1].Value;
                    }

                    if (objimg.oldimg.Contains("alt"))
                    {
                        vAlt = Regex.Match(objimg.oldimg, "<img.+?alt=[\"'](.+?)[\"'].+?>", RegexOptions.IgnoreCase).Groups[1].Value;
                        if (vAlt.Contains("src"))
                        {
                            vAlt = string.Empty;
                        }
                    }

                    //Change by ajit kumar  for removing ' from pattern matching
                    //objimg.newimg = "<img src='" + sBasePath + GetFilePath(Regex.Match(objimg.oldimg, "<img.+?src=[\"'](.+?)[\"'].+?>", RegexOptions.IgnoreCase).Groups[1].Value) + "' alt='" + vAlt + "' style = '" + vStyle + "'/>";
                    objimg.newimg = "<img src='" + sBasePath + GetFilePath(Regex.Match(objimg.oldimg, "<img.+?src=[\"](.+?)[\"].+?>", RegexOptions.IgnoreCase).Groups[1].Value) + "' alt='" + vAlt + "' style = '" + vStyle + "'/>";
                    objImages.Add(objimg);

                }
            }



            for (int z = 0; z < objImages.Count; z++)
            {
                vSource = vSource.Replace(objImages[z].oldimg, objImages[z].newimg);
            }
            return vSource;
        }


        /// <summary>
        /// Function will provide current date and time.
        /// </summary>
        /// <returns>DateTime</returns>
        public DateTime Datetime()
        {
            return DateTime.Now;
        }

        /// <summary>
        /// Function to encrypt the security token. 
        /// Added by Manoj Maurya as on 05-Aug-2015 for security implementation
        /// </summary>
        /// <returns>string</returns>
        public string GenerateSecurityToken()
        {
            string securityToken = Guid.NewGuid().ToString().Split('-').GetValue(0).ToString();
            return GetEncryptSHA256(securityToken);
        }

        /// <summary>
        /// Function to encrypt the data.
        /// Added by Manoj Maurya as on 05-Aug-2015 for security implementation
        /// </summary>
        /// <param name="data">data</param>
        /// <returns>string</returns>
        public string GetEncryptSHA256(string data)
        {


            // data = saltKey + data;

            SHA256 sha256 = SHA256.Create();

            //convert the input text to array of bytes

            byte[] hashData = sha256.ComputeHash(Encoding.Default.GetBytes(data));

            StringBuilder returnValue = new StringBuilder();

            for (int i = 0; i < hashData.Length; i++)
            {

                returnValue.Append(hashData[i].ToString());

            }

            // return hexadecimal string

            return returnValue.ToString();

        }

        /// <summary>
        /// Created by Ajit Kumar on 18-4-2016 for Resize image.
        /// </summary>
        /// <param name="image"></param>
        /// <param name="width"></param>
        /// <param name="height"></param>
        /// <returns></returns>
        public Bitmap ResizeImage(System.Drawing.Image image, int width, int height)
        {
            var destRect = new Rectangle(0, 0, width, height);
            var destImage = new Bitmap(width, height);

            destImage.SetResolution(image.HorizontalResolution, image.VerticalResolution);

            using (var graphics = Graphics.FromImage(destImage))
            {
                graphics.CompositingMode = CompositingMode.SourceCopy;
                graphics.CompositingQuality = CompositingQuality.HighQuality;
                graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                graphics.SmoothingMode = SmoothingMode.HighQuality;
                graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;

                using (var wrapMode = new ImageAttributes())
                {
                    wrapMode.SetWrapMode(WrapMode.TileFlipXY);
                    graphics.DrawImage(image, destRect, 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, wrapMode);
                }
            }

            return destImage;
        }


        /// <summary>
        /// Function to Send Mailer with attachment file
        /// Added by Ajit Kumar Created date:18-04-2016
        /// </summary>
        public bool SendMailer(string vToAddress, string vFromAddress, string vSubject, string vBody, string[] vAttachment)
        {
            SPPUtility objUtility = new SPPUtility();
            try
            {
                if (ConfigurationManager.AppSettings["EmailAllowed"].ToString().ToUpper() == "Y")
                {
                    CDO.Message objMessage = new CDO.Message();
                    CDO.Configuration iConfg;
                    ADODB.Fields oFields;
                    ADODB.Field oField;
                    iConfg = objMessage.Configuration;
                    oFields = iConfg.Fields;

                    //Mode from which mail willgo
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/sendusing"];
                    oField.Value = 2; //cdoSendUsingPickup->1  cdoSendUsingPort -->2 cdoSendUsingExchange-->3
                    //Name or IP of Remote SMTP Server
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpserver"];
                    oField.Value = System.Configuration.ConfigurationManager.AppSettings["smtpserver"].ToString(); //"v7smtp.samsung.com";
                    //'Type of authentication, NONE, Basic (Base64 encoded), NTLM
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpauthenticate"];
                    oField.Value = 1;
                    //Your UserID on the SMTP server
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/sendusername"];
                    oField.Value = System.Configuration.ConfigurationManager.AppSettings["sendusername"].ToString(); //"mkt.india";
                    //Your password on the SMTP server
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/sendpassword"];
                    oField.Value = System.Configuration.ConfigurationManager.AppSettings["sendpassword"].ToString(); //"abc135";
                    //Server port (typically 25)
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpserverport"];
                    oField.Value = 25;
                    //Use SSL for the connection (False or True)
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpusessl"];
                    oField.Value = false;
                    //Connection Timeout in seconds (the maximum time CDO will try to establish a connection to the SMTP server)
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpconnectiontimeout"];
                    oField.Value = 60;
                    oFields.Update();
                    objMessage.Configuration = iConfg;


                    oField.Value = 60;
                    oFields.Update();
                    objMessage.Configuration = iConfg;
                    objMessage.From = vFromAddress;
                    objMessage.To = vToAddress;
                    objMessage.Subject = vSubject;
                    objMessage.HTMLBody = vBody;
                    foreach (string str in vAttachment)
                    {
                        if (!string.IsNullOrEmpty(str))
                        {
                            objMessage.AddAttachment(str, "mkt.india", "abc135");
                        }
                    }

                    objMessage.Send();


                    objMessage = null;
                }

                return true;
            }
            catch (Exception ex)
            {

                objUtility.InsertintoErrorLog("Function - SaveHappyPartners", ex.Message, "SPP Send Happy File Attachment,From: " + vFromAddress + " To: " + vToAddress,
                    Convert.ToInt32(SPPUtility._Sections.Support), 0);
                return false;
            }
        }


        public bool SendMailer(string vToAddress, string vFromAddress, string vSubject, string vBody)
        {
            SPPUtility objUtility = new SPPUtility();
            try
            {
                if (ConfigurationManager.AppSettings["EmailAllowed"].ToString().ToUpper() == "Y")
                {
                    CDO.Message objMessage = new CDO.Message();
                    CDO.Configuration iConfg;
                    ADODB.Fields oFields;
                    ADODB.Field oField;
                    iConfg = objMessage.Configuration;
                    oFields = iConfg.Fields;

                    //Mode from which mail willgo
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/sendusing"];
                    oField.Value = 2; //cdoSendUsingPickup->1  cdoSendUsingPort -->2 cdoSendUsingExchange-->3
                    //Name or IP of Remote SMTP Server
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpserver"];
                    //Added by shaif : july-28-2016
                    oField.Value = System.Configuration.ConfigurationManager.AppSettings["smtpserver"].ToString(); //"v7smtp.samsung.com";
                    //'Type of authentication, NONE, Basic (Base64 encoded), NTLM
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpauthenticate"];
                    oField.Value = 1;
                    //Your UserID on the SMTP server
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/sendusername"];
                    oField.Value = System.Configuration.ConfigurationManager.AppSettings["sendusername"].ToString(); //"mkt.india";
                    //Your password on the SMTP server
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/sendpassword"];
                    oField.Value = System.Configuration.ConfigurationManager.AppSettings["sendpassword"].ToString(); //"abc135";
                    //Server port (typically 25)
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpserverport"];
                    oField.Value = 25;
                    //Use SSL for the connection (False or True)
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpusessl"];
                    oField.Value = false;
                    //Connection Timeout in seconds (the maximum time CDO will try to establish a connection to the SMTP server)
                    oField = oFields["http://schemas.microsoft.com/cdo/configuration/smtpconnectiontimeout"];
                    oField.Value = 60;
                    oFields.Update();
                    objMessage.Configuration = iConfg;


                    oField.Value = 60;
                    oFields.Update();
                    objMessage.Configuration = iConfg;
                    objMessage.From = vFromAddress;
                    objMessage.To = vToAddress;
                    objMessage.Subject = vSubject;
                    objMessage.HTMLBody = vBody;
                    objMessage.Send();


                    objMessage = null;
                }

                return true;
            }
            catch (Exception ex)
            {

                objUtility.InsertintoErrorLog("Function - SPPSaveProfileDetails-Email", ex.Message, "SPP Save Profile Details,From: " + vFromAddress + " To: " + vToAddress,
                    Convert.ToInt32(SPPUtility._Sections.Notification), 0);
                return false;
            }
        }

        /// <summary>
        /// Function to Get global Setting
        /// </summary>
        /// <returns></returns>
        DataSet GetGlobalSettings()
        {
            DataSet dsGlobalsettings = null;
            DataLayer dtLayer = new DataLayer();
            DataTable dt = new DataTable();
            try
            {
                DataColumn dc1 = new DataColumn("MAIL_SERVER_HOST");
                DataColumn dc2 = new DataColumn("MAIL_FROM_NAME");
                DataColumn dc3 = new DataColumn("MAIL_USER_ID");
                DataColumn dc4 = new DataColumn("MAIL_PASSWORD");
                DataColumn dc5 = new DataColumn("MAIL_SENDER_EMAIL");
                DataColumn dc6 = new DataColumn("MAIL_SERVER_PORT");
                DataColumn dc7 = new DataColumn("ENABLE_SSL");
                DataColumn dc8 = new DataColumn("MAILER_LOGO_IMAGE_PATH");
                DataColumn dc9 = new DataColumn("HELPLINE_EMAIL_ID");
                dt.Columns.Add(dc1);
                dt.Columns.Add(dc2);
                dt.Columns.Add(dc3);
                dt.Columns.Add(dc4);
                dt.Columns.Add(dc5);
                dt.Columns.Add(dc6);
                dt.Columns.Add(dc7);
                dt.Columns.Add(dc8);
                dt.Columns.Add(dc9);
                DataRow dr = dt.NewRow();
                dr["MAIL_SERVER_HOST"] = "smtp.samsung.com";
                dr["MAIL_FROM_NAME"] = "Smart Connect";
                dr["MAIL_USER_ID"] = "mkt.india";
                dr["MAIL_PASSWORD"] = "abc135";
                dr["MAIL_SENDER_EMAIL"] = "smartconnect@samsung.com";
                dr["MAIL_SERVER_PORT"] = "25";
                dr["ENABLE_SSL"] = "0";
                dr["MAILER_LOGO_IMAGE_PATH"] = "images\\samsung_logo.png";
                dr["HELPLINE_EMAIL_ID"] = "s.subhash1@partner.samsung.com";
                dt.AcceptChanges();
                dsGlobalsettings.Tables.Add(dt);
            }
            catch (Exception exc)
            {
            }
            return dsGlobalsettings;
        }

        //public enum _BidStatus
        //{
        //    Active = 1,
        //    BidPlaced = 2,
        //    Closed = 3,
        //    Expired = 4,
        //    BidLimitExceed = 5,
        //    ReglobePickupRequested = 6,
        //}
        public enum _BidMasterStatus
        {
            Initialize = 0,//Default value 
            NewBid = 1,
            BidPlaced = 2,
            ReglobePickupRequested = 3,
            Closed = 4,
            Expired = 5,
            ReglobePickupRequestedByOther = 6,


        }

        //Added by Anil Verma for Leadership blog 

        #region " QueryString Encryption "
        /// <summary>
        /// To Encrypt Query String
        /// </summary>
        /// <param name="querystring"></param>
        /// <returns></returns>
        /// <remarks></remarks>
        public static string EncryptQueryString(string querystring)
        {

            return clsCryptography.Encrypt(querystring, "!@#$%&)(");
        }
        public static QueryString DecryptQueryString(string querystring)
        {
            QueryString QString = new QueryString();
            string[] pair;
            string[] QStr = clsCryptography.Decrypt(querystring, "!@#$%&)(").Split('&');
            foreach (string qs in QStr)
            {
                pair = qs.Split('=');
                if (pair.Length == 2)
                {
                    QString.addQS(pair[0].ToUpper(), pair[1]);
                }
            }
            return QString;
        }
        #endregion


        /// <summary> 
        /// This function will Provide a Month Name accordig to the Month Index
        /// </summary> 
        /// <param name="month">Index  Value of Month</param> 
        /// <remarks></remarks> 

        public static string datetime()
        {
            DateTime currentDateTime = DateTime.Now;
            string dtString = currentDateTime.ToString("yyyy-MM-dd HH:mm:ss");
            return dtString;
        }
        public static DateTime currentdatetime()
        {
            return DateTime.Now;
            // return DateTime.Now.AddHours(-2.5);
        }
        #region Check for Valid Character
        public bool IsValidCharater(string text)
        {
            bool isValid = false;
            if (!string.IsNullOrEmpty(text.Trim()))
            {
                Regex regex = new Regex(@"^[ A-Za-z0-9\s\r\n_@,./#&+-]*$");
                Match match = regex.Match(text.Trim());

                if (match.Success)
                {
                    isValid = true;
                }
            }
            else
            {
                isValid = true;
            }

            return isValid;
        }
        #endregion

        #region Digital signature
        //***********************************VM CODE**************************************************//

        /// <summary>
        /// method to convert stream to byte array
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public byte[] StreamToByteArray(Stream stream)
        {
            byte[] buffer = new byte[32768];
            using (MemoryStream ms = new MemoryStream())
            {
                while (true)
                {
                    int read = stream.Read(buffer, 0, buffer.Length);
                    if (read <= 0)
                        return ms.ToArray();
                    ms.Write(buffer, 0, read);
                }
            }
        }

        //*****************
        public Image byteArrayToImage(byte[] bytesArr)
        {
            using (MemoryStream memstr = new MemoryStream(bytesArr))
            {
                return Image.FromStream(memstr);
            }
        }
        //*******************

        /// <summary>
        /// Upload File to Specified FTP Url with username and password and Upload Directory, accept file as byte[] fileStream
        /// </summary>
        /// <param name="fileName">file name only like purpose_purposeid_userrole_userid_timestamp_imageid </param>
        /// <param name="fileStream"></param>
        /// <param name="UploadDirectory"></param>
        /// <returns></returns>
        public string UploadFileOnServer(string fileName, byte[] fileStream, string UploadDirectory)
        {
            AppSettingsReader settingsReader = new AppSettingsReader();
            string fileServerType = (string)settingsReader.GetValue("FileServerType", typeof(String));
            //string fileServerUrl = (string)settingsReader.GetValue("FileServerUrl", typeof(String));
            //**********fileServerUrl = UploadDirectory BOTH ARE SAME********
            string fileServerUserName = (string)settingsReader.GetValue("FileServerUserName", typeof(String));
            string fileServerPassword = (string)settingsReader.GetValue("FileServerPassword", typeof(String));

            string response = string.Empty;
            string uploadUrl = string.Empty;
            string pureFileName = string.Empty;
            switch (fileServerType)
            {
                case "FTP":
                    pureFileName = new FileInfo(fileName).Name;
                    uploadUrl = String.Format("{0}{1}", UploadDirectory, pureFileName);
                    FtpWebRequest req = (FtpWebRequest)FtpWebRequest.Create(uploadUrl);
                    FtpWebResponse res;
                    req.Proxy = null;
                    req.Method = WebRequestMethods.Ftp.UploadFile;
                    req.Credentials = new NetworkCredential(fileServerUserName, fileServerPassword);
                    req.UseBinary = true;
                    req.UsePassive = true;
                    byte[] data = fileStream;
                    req.ContentLength = data.Length;
                    Stream stream = req.GetRequestStream();
                    stream.Write(data, 0, data.Length);
                    stream.Close();

                    res = (FtpWebResponse)req.GetResponse();
                    response = res.StatusDescription;

                    break;

                case "FileSystem":

                    string RootPath = AppDomain.CurrentDomain.BaseDirectory;
                    //RootPath = "D:\\S2P2_Source_TFS\\S2P2_Webservice\\S2P2_Services_Sep-SP-3010\\S2P2WebService\\RLImages\\";
                    pureFileName = new FileInfo(fileName).Name;
                    uploadUrl = String.Format("{0}{1}{2}", RootPath, UploadDirectory, pureFileName);
                    File.WriteAllBytes(uploadUrl, fileStream);
                    response = "File uploaded complete";
                    break;
                default:
                    break;
            }
            return response;
        }

        /// <summary>
        /// Upload File to Specified FTP Url with username and password and Upload Directory, accept file as byte[] fileStream
        /// </summary>
        /// <param name="fileName">file name only like purpose_purposeid_userrole_userid_timestamp_imageid </param>
        /// <param name="fileStream"></param>
        /// <param name="UploadDirectory"></param>
        /// <returns></returns>
        public string UploadSMAPPFileOnServer(string fileName, byte[] fileStream, string UploadDirectory)
        {
            AppSettingsReader settingsReader = new AppSettingsReader();
            string fileServerType = (string)settingsReader.GetValue("FileServerTypeSMAPP", typeof(String));
            string fileServerUrl = (string)settingsReader.GetValue("FileServerUrlSMAPP", typeof(String));
            //**********fileServerUrl = UploadDirectory BOTH ARE SAME********
            string fileServerUserName = (string)settingsReader.GetValue("FileServerUserNameSMAPP", typeof(String));
            string fileServerPassword = Decrypt((string)settingsReader.GetValue("FileServerPasswordSMAPP", typeof(String)));

            string response = string.Empty;
            string uploadUrl = string.Empty;
            string pureFileName = string.Empty;
            switch (fileServerType)
            {
                case "FTP":
                    pureFileName = new FileInfo(fileName).Name;
                    uploadUrl = String.Format("{0}{1}", UploadDirectory, pureFileName);
                    FtpWebRequest req = (FtpWebRequest)FtpWebRequest.Create(uploadUrl);
                    FtpWebResponse res;
                    req.Proxy = null;
                    req.Method = WebRequestMethods.Ftp.UploadFile;
                    req.Credentials = new NetworkCredential(fileServerUserName, fileServerPassword);
                    req.UseBinary = true;
                    req.UsePassive = true;
                    byte[] data = fileStream;
                    req.ContentLength = data.Length;
                    Stream stream = req.GetRequestStream();
                    stream.Write(data, 0, data.Length);
                    stream.Close();

                    res = (FtpWebResponse)req.GetResponse();
                    response = res.StatusDescription;

                    break;

                case "NAS":
                    pureFileName = new FileInfo(fileName).Name;
                    uploadUrl = String.Format("{0}{1}{2}", fileServerUrl, UploadDirectory, pureFileName);
                    //File.WriteAllBytes(uploadUrl, fileStream);


                    FileWebRequest httpreq = (FileWebRequest)FileWebRequest.Create(uploadUrl);
                    FileWebResponse httpres;
                    httpreq.Proxy = null;
                    httpreq.Method = WebRequestMethods.Ftp.UploadFile;
                    httpreq.Credentials = new NetworkCredential(fileServerUserName, fileServerPassword);
                    byte[] httpData = fileStream;
                    httpreq.ContentLength = httpData.Length;
                    Stream httpStream = httpreq.GetRequestStream();
                    httpStream.Write(httpData, 0, httpData.Length);
                    httpStream.Close();

                    httpres = (FileWebResponse)httpreq.GetResponse();

                    response = "File uploaded successfully";
                    break;

                case "FileSystem":

                    string RootPath = AppDomain.CurrentDomain.BaseDirectory;
                    //RootPath = "D:\\S2P2_Source_TFS\\S2P2_Webservice\\S2P2_Services_Sep-SP-3010\\S2P2WebService\\RLImages\\";
                    pureFileName = new FileInfo(fileName).Name;
                    uploadUrl = String.Format("{0}{1}{2}", RootPath, UploadDirectory, pureFileName);
                    File.WriteAllBytes(uploadUrl, fileStream);
                    response = "File uploaded complete";
                    break;
                default:
                    break;
            }
            return response;
        }
        public bool SendFinalMail(string MailTo, string MailFrom, string MailFromName, string MailSubject, string MailBody, string Attachments, string BCCEmail)
        {
            SPPUtility objUtility = new SPPUtility();
            //FailedTo = "";
            bool SentStatus = false;
            SmtpClient objSmtpClient = new SmtpClient();
            try
            {
                System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
                //message.From = new MailAddress(ConfigurationSettings.AppSettings["MAIL_SENDER_EMAIL"].ToString(),
                //                                ConfigurationSettings.AppSettings["MAIL_FROM_NAME"].ToString());
                //message.ReplyTo = new MailAddress(ConfigurationSettings.AppSettings["MAIL_SENDER_EMAIL"].ToString(),
                //                                ConfigurationSettings.AppSettings["MAIL_FROM_NAME"].ToString());

                message.From = new MailAddress(MailFrom, MailFromName);
                message.ReplyTo = new MailAddress(MailFrom, MailFromName);

                string[] arrAttachments = Attachments.Split('?');
                ArrayList alStream = new ArrayList();

                for (int i = 0; i < arrAttachments.Length; i++)
                {
                    if (arrAttachments[i].Length > 0)
                    {
                        FileStream fs = new FileStream(arrAttachments[i], FileMode.Open, FileAccess.Read);
                        ContentType cType = new ContentType();
                        cType.MediaType = MediaTypeNames.Application.Octet;
                        cType.Name = "ConsentForm_" + Guid.NewGuid().ToString().Substring(1, 6) + ".pdf";
                        Attachment objattachment = new Attachment(fs, cType);
                        message.Attachments.Add(objattachment);
                        alStream.Add(fs);
                    }
                }
                /** Changes On 02 May 14 **/
                MailTo = MailTo.Trim();

                message.To.Add(MailTo);
                if (!string.IsNullOrEmpty(BCCEmail))
                    message.Bcc.Add(BCCEmail);

                message.Subject = MailSubject;

                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(MailBody, null, "text/html");
                message.AlternateViews.Add(htmlView);
                message.IsBodyHtml = true;
                message.Priority = System.Net.Mail.MailPriority.Normal;

                System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential(ConfigurationSettings.AppSettings["sendusername"].ToString(),
                                                                                             ConfigurationSettings.AppSettings["sendpassword"].ToString());
                objSmtpClient.Host = ConfigurationSettings.AppSettings["smtpserver"].ToString();
                objSmtpClient.Port = Int16.Parse(ConfigurationSettings.AppSettings["MAIL_SERVER_PORT"]);
                objSmtpClient.Credentials = SMTPUserInfo;// CredentialCache.DefaultNetworkCredentials;
                objSmtpClient.EnableSsl = false;

                // objSmtpClient.PickupDirectoryLocation = ConfigurationSettings.AppSettings["MailExcelDestination"].ToString();
                objSmtpClient.Send(message);

                SentStatus = true;
                for (int i = 0; i < alStream.Count; i++)
                {
                    FileStream fs = (FileStream)alStream[i];
                    fs.Close();
                    fs.Dispose();
                }

            }
            catch (Exception Ex)
            {
                objUtility.InsertintoErrorLog("Function - SendFinalMail", Ex.Message, "try to send mail with attachment: " + MailTo + " To: " + MailTo + "filepath:" + Attachments,
                     Convert.ToInt32(SPPUtility._Sections.Support), 0);
                return false;
            }

            return SentStatus;
        }

        public bool SendFinalMail(string MailTo, string MailSubject, string MailBody, string Attachments, string BCCEmail)
        {
            SPPUtility objUtility = new SPPUtility();
            //FailedTo = "";
            bool SentStatus = false;
            SmtpClient objSmtpClient = new SmtpClient();
            try
            {
                System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
                message.From = new MailAddress(ConfigurationSettings.AppSettings["MAIL_SENDER_EMAIL"].ToString(),
                                                ConfigurationSettings.AppSettings["MAIL_FROM_NAME"].ToString());
                message.ReplyTo = new MailAddress(ConfigurationSettings.AppSettings["MAIL_SENDER_EMAIL"].ToString(),
                                                ConfigurationSettings.AppSettings["MAIL_FROM_NAME"].ToString());



                string[] arrAttachments = Attachments.Split('?');
                ArrayList alStream = new ArrayList();

                for (int i = 0; i < arrAttachments.Length; i++)
                {
                    if (arrAttachments[i].Length > 0)
                    {
                        FileStream fs = new FileStream(arrAttachments[i], FileMode.Open, FileAccess.Read);
                        ContentType cType = new ContentType();
                        cType.MediaType = MediaTypeNames.Application.Octet;
                        cType.Name = "ConsentForm_" + Guid.NewGuid().ToString().Substring(1, 6) + ".pdf";
                        Attachment objattachment = new Attachment(fs, cType);
                        message.Attachments.Add(objattachment);
                        alStream.Add(fs);
                    }
                }
                /** Changes On 02 May 14 **/
                MailTo = MailTo.Trim();

                message.To.Add(MailTo);

                if (!string.IsNullOrEmpty(BCCEmail))
                    message.Bcc.Add(BCCEmail);
                message.Subject = MailSubject;

                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(MailBody, null, "text/html");
                message.AlternateViews.Add(htmlView);
                message.IsBodyHtml = true;
                message.Priority = System.Net.Mail.MailPriority.Normal;

                System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential(ConfigurationSettings.AppSettings["sendusername"].ToString(),
                                                                                             ConfigurationSettings.AppSettings["sendpassword"].ToString());
                objSmtpClient.Host = ConfigurationSettings.AppSettings["smtpserver"].ToString();
                objSmtpClient.Port = Int16.Parse(ConfigurationSettings.AppSettings["MAIL_SERVER_PORT"]);
                objSmtpClient.Credentials = SMTPUserInfo;// CredentialCache.DefaultNetworkCredentials;
                objSmtpClient.EnableSsl = false;

                // objSmtpClient.PickupDirectoryLocation = ConfigurationSettings.AppSettings["MailExcelDestination"].ToString();
                objSmtpClient.Send(message);

                SentStatus = true;
                for (int i = 0; i < alStream.Count; i++)
                {
                    FileStream fs = (FileStream)alStream[i];
                    fs.Close();
                    fs.Dispose();
                }

            }
            catch (Exception Ex)
            {
                objUtility.InsertintoErrorLog("Function - SendFinalMail", Ex.Message, "try to send mail with attachment: " + MailTo + " To: " + MailTo + "filepath:" + Attachments,
                     Convert.ToInt32(SPPUtility._Sections.Support), 0);
                return false;
            }

            return SentStatus;
        }

        public bool SendFinalMailDigital(string MailTo, string MailFrom, string MailFromName, string MailSubject, string MailBody, string Attachments, string BCCEmail)
        {
            SPPUtility objUtility = new SPPUtility();
            //FailedTo = "";
            bool SentStatus = false;
            SmtpClient objSmtpClient = new SmtpClient();
            try
            {
                System.Net.Mail.MailMessage message = new System.Net.Mail.MailMessage();
                //message.From = new MailAddress(ConfigurationSettings.AppSettings["MAIL_SENDER_EMAIL"].ToString(),
                //                                ConfigurationSettings.AppSettings["MAIL_FROM_NAME"].ToString());
                //message.ReplyTo = new MailAddress(ConfigurationSettings.AppSettings["MAIL_SENDER_EMAIL"].ToString(),
                //                                ConfigurationSettings.AppSettings["MAIL_FROM_NAME"].ToString());

                message.From = new MailAddress(MailFrom, MailFromName);
                message.ReplyTo = new MailAddress(MailFrom, MailFromName);

                string[] arrAttachments = Attachments.Split('?');
                ArrayList alStream = new ArrayList();

                for (int i = 0; i < arrAttachments.Length; i++)
                {
                    if (arrAttachments[i].Length > 0)
                    {
                        FileStream fs = new FileStream(arrAttachments[i], FileMode.Open, FileAccess.Read);
                        ContentType cType = new ContentType();
                        cType.MediaType = MediaTypeNames.Application.Octet;
                        cType.Name = "DigitalSignatureReport_" + System.DateTime.Now.ToString("yyyyMMddHH") + ".xls";
                        Attachment objattachment = new Attachment(fs, cType);
                        message.Attachments.Add(objattachment);
                        alStream.Add(fs);
                    }
                }
                /** Changes On 02 May 14 **/
                MailTo = MailTo.Trim();

                message.To.Add(MailTo);
                if (!string.IsNullOrEmpty(BCCEmail))
                    message.Bcc.Add(BCCEmail);

                message.Subject = MailSubject;

                AlternateView htmlView = AlternateView.CreateAlternateViewFromString(MailBody, null, "text/html");
                message.AlternateViews.Add(htmlView);
                message.IsBodyHtml = true;
                message.Priority = System.Net.Mail.MailPriority.Normal;

                System.Net.NetworkCredential SMTPUserInfo = new System.Net.NetworkCredential((new SPPUtility()).Decrypt(ConfigurationSettings.AppSettings["sendusername"].ToString()),
                                                                                           (new SPPUtility()).Decrypt(ConfigurationSettings.AppSettings["sendpassword"].ToString()));
                objSmtpClient.Host = ConfigurationSettings.AppSettings["smtpserver"].ToString();
                objSmtpClient.Port = Int16.Parse(ConfigurationSettings.AppSettings["MAIL_SERVER_PORT"]);
                objSmtpClient.Credentials = SMTPUserInfo;// CredentialCache.DefaultNetworkCredentials;
                objSmtpClient.EnableSsl = false;

                // objSmtpClient.PickupDirectoryLocation = ConfigurationSettings.AppSettings["MailExcelDestination"].ToString();
                objSmtpClient.Send(message);

                SentStatus = true;
                for (int i = 0; i < alStream.Count; i++)
                {
                    FileStream fs = (FileStream)alStream[i];
                    fs.Close();
                    fs.Dispose();
                }

            }
            catch (Exception Ex)
            {
                objUtility.InsertintoErrorLog("Function - SendFinalMailDigital", Ex.Message, "try to send mail with attachment: " + MailTo + " To: " + MailTo + "filepath:" + Attachments,
                     Convert.ToInt32(SPPUtility._Sections.DigitalSignatureOpramail), 0);
                return false;
            }

            return SentStatus;
        }

        #endregion RLSHELPER METHODS FOR IMAGE UPLOAD
        public string GetRandomNumbers(int count)
        {
            var random = new Random();
            string s = string.Empty;
            for (int i = 0; i < count; i++)
                s = String.Concat(s, random.Next(10).ToString());
            return s;
        }

        public string GetRandomNumbers(Random rand)
        {
            // Random rand = new Random();
            long randnum2 = (long)(rand.NextDouble() * 9000000000) + 1000000000;
            return randnum2.ToString();
        }

        public static string GenerateOTP()
        {

            // declare array string to generate random string with combination of small,capital letters and numbers
            char[] charArr = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            //char[] charArr = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray();
            //char[] charArr = "0123456789".ToCharArray();
            string strrandom = string.Empty;
            Random objran = new Random();
            int noofcharacters = 6;
            for (int i = 0; i < noofcharacters; i++)
            {
                //It will not allow Repetation of Characters
                int pos = objran.Next(1, charArr.Length);
                if (!strrandom.Contains(charArr.GetValue(pos).ToString()))
                    strrandom += charArr.GetValue(pos);
                else
                    i--;
            }
            return strrandom;


        }
        public static bool SendSMS(string userid, string mobileno, string SMSTxt)
        {
            bool status = false;



            try
            {
                string smsReturnCode = "";

                string smsurl = ConfigurationSettings.AppSettings["SMSAPI"] + "?uname=" + ConfigurationSettings.AppSettings["SMSAPIUser"] + "&pass=" + ConfigurationSettings.AppSettings["SMSAPIPWD"] + "&send=" + ConfigurationSettings.AppSettings["send"] + "&dest=" + mobileno + "&msg=" + SMSTxt + "&prty=" + ConfigurationSettings.AppSettings["SMSPriority"] + "&vp=" + ConfigurationSettings.AppSettings["SMSValidityPeriod"] + "";

                HttpWebRequest smsRequest = (HttpWebRequest)WebRequest.Create(smsurl);
                HttpWebResponse smsResponse = (HttpWebResponse)smsRequest.GetResponse();
                String ver = smsRequest.ProtocolVersion.ToString();
                StreamReader smsReader = new StreamReader(smsResponse.GetResponseStream());

                //  SPPUtility.WriteLog(smsurl);
                //Dynamic url genrating : http://www.unicel.in/SendSMS/sendmsg.php?uname=SamSDTHHPTr&pass=f6O)T5s!&send=SPPHHP&dest=9015256854&msg=LNEIFU&prty=3&vp=30

                smsReturnCode = smsReader.ReadToEnd();
                //  WriteLog("check sms s2p2", "", "", "", "SendSMS", "", "", smsReturnCode + " " + smsurl, "check sms s2p2");
                status = true;

                // SPPUtility.WriteLog(Environment.NewLine + Environment.NewLine + " SMS Url : " + smsurl + Environment.NewLine + Environment.NewLine + " Return Code : " + smsReturnCode);


            }
            catch (Exception ex)
            {
                //  objUtility.InsertintoErrorLog("Function - SPPGenerateOtp", hostingserver + " - " + ex.Message, "SPP Get Profile Details", Convert.ToInt32(SPPUtility._Sections.App_Profile), useridcode);
            }
            finally
            {


            }


            return status;
        }

        #region "Encryption salt"
        private static ICryptoTransform GetCryptoTransform(AesCryptoServiceProvider csp, bool encrypting, string SALT)
        {
            csp.Mode = CipherMode.CBC;
            csp.Padding = PaddingMode.PKCS7;
            var spec = new Rfc2898DeriveBytes(Encoding.UTF8.GetBytes(PASSWORD), Encoding.UTF8.GetBytes(SALT), 65536);
            byte[] key = spec.GetBytes(16);


            csp.IV = Encoding.UTF8.GetBytes(IV1);
            csp.Key = key;
            if (encrypting)
            {
                return csp.CreateEncryptor();
            }
            return csp.CreateDecryptor();
        }



        public static string EncryptAndEncode(string raw, string salt)
        {
            using (var csp = new AesCryptoServiceProvider())
            {
                ICryptoTransform e = GetCryptoTransform(csp, true, salt);
                byte[] inputBuffer = Encoding.UTF8.GetBytes(raw);
                byte[] output = e.TransformFinalBlock(inputBuffer, 0, inputBuffer.Length);
                string encrypted = Convert.ToBase64String(output);
                return encrypted;
            }
        }

        public static string DecodeAndDecrypt(string encrypted, string Salt)
        {
            using (var csp = new AesCryptoServiceProvider())
            {
                var d = GetCryptoTransform(csp, false, Salt);
                byte[] output = Convert.FromBase64String(encrypted);
                byte[] decryptedOutput = d.TransformFinalBlock(output, 0, output.Length);
                string decypted = Encoding.UTF8.GetString(decryptedOutput);
                return decypted;
            }
        }


        /// <summary>
        /// Function to Send SMS Using Route Mobile API
        /// Added by Shyam Sunder kumar as on 18-Dec-2020
        /// </summary>
        /// <param name="MobileNo">Mobile No</param>
        /// <param name="Message">Message</param>
        /// <param name="TempID">Template ID</param>
        /// <returns>SMSOutput [status,uniqueRefNO,remark]</returns>
        public static SMSOutput sendIASMS(string MobileNo, string Message, string TempID)
        {
            SMSOutput smsout = new SMSOutput();
            StringBuilder requestBody = new StringBuilder();

            string serverResult;

            try
            {

                if (!string.IsNullOrEmpty(MobileNo))
                {
                    try
                    {
                        if (ConfigurationManager.AppSettings["IsSMSSend"] != null && ConfigurationManager.AppSettings["IsSMSSend"].ToUpper() == "Y")
                        {
                            MobileNo = MobileNo.Trim();
                            if (MobileNo.Length > 10)
                            {
                                MobileNo = MobileNo.Substring(0, 10);
                            }

                            Message = Message.Replace("&", "%26");

                            string url = ConfigurationManager.AppSettings["smsurl"].ToString();

                            requestBody.AppendFormat(url + "username={0}&password={1}&type=0&dlr=1&destination={2}&source={3}&message={4}&entityid={5}&tempid={6}", ConfigurationManager.AppSettings["uname"].ToString(), (new SPPUtility()).Decrypt(ConfigurationManager.AppSettings["pass"]).ToString(), MobileNo, ConfigurationManager.AppSettings["SenderId"].ToString(), Message, ConfigurationManager.AppSettings["entityid"].ToString(), TempID);
                            url = Convert.ToString(requestBody);
                            using (System.Net.WebClient wlc = new System.Net.WebClient())
                            {

                                serverResult = wlc.DownloadString(url);

                            }
                            smsout.uniqueRefNO = serverResult;
                            smsout.status = true;
                        }
                        else
                        {
                            smsout.status = false;
                            smsout.remark = "Send SMS not configured in web.config";
                        }
                    }
                    catch (Exception ex)
                    {

                        smsout.status = false;
                        smsout.remark = ex.Message;



                    }
                }
            }
            catch (Exception ex)
            {
                smsout.status = false;
                smsout.remark = ex.Message;

            }
            return smsout;


        }


        //SPP changes for IP address Amandeep Singh 17 march 2022 start [SPP_Nepal_Mearge]
        public static string GetIp()
        {
            string ip = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(ip))
            {
                ip = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }
            return ip;
        }
        //SPP changes for IP address Amandeep Singh 17 march 2022 end

        //SPP changes for app hash key Amandeep Singh 30 march 2022 start [SPP_Nepal_Mearge]
        public String sha256_hash(String value)
        {
            StringBuilder Sb = new StringBuilder();
            using (SHA256 hash = SHA256Managed.Create())
            {
                Encoding enc = Encoding.UTF8;
                Byte[] result = hash.ComputeHash(enc.GetBytes(value));
                foreach (Byte b in result)
                    Sb.Append(b.ToString("x2"));
            }
            return Sb.ToString();
        }
        //SPP changes for app hash key Amandeep Singh 30 march 2022 end
        //SPP changes for app hash key Amandeep Singh 30 march 2022 end

        /// <summary>
        /// Function to Write File from Server
        /// Added by Shyam Sunder Kumar as on 20-Apr-2016
        /// </summary>
        /// <param name="fileName">file Name</param>
        /// <param name="fileStream">file Stream</param>
        /// <param name="UploadDirectory">Upload Directory</param>
        /// <returns>string</returns>
        public string WriteFileOnFileServer(string fileName, byte[] fileStream, string UploadDirectory)
        {

            try
            {
                AppSettingsReader settingsReader = new AppSettingsReader();
                //Get your key from config file to open the lock!

                string fileServerType = (string)settingsReader.GetValue("WebFileServerType", typeof(String));
                string uploadfileServerUrl = (string)settingsReader.GetValue("WebUploadFileServerUrl", typeof(String));
                string downloadfileServerUrl = (string)settingsReader.GetValue("WebDownloadFileServerUrl", typeof(String));
                string fileServerUserName = (string)settingsReader.GetValue("WebFileServerUserName", typeof(String));
                string fileServerPassword = (string)settingsReader.GetValue("WebFileServerPassword", typeof(String));

                string response = string.Empty;
                string uploadUrl = string.Empty;
                //  string pureFileName = string.Empty;
                string uploadDirectoryPath = string.Empty;

                UploadDirectory = UploadDirectory.Replace("/", "\\");

                switch (fileServerType)
                {

                    case "NAS":
                        // pureFileName = new FileInfo(fileName).Name;
                        uploadUrl = String.Format("{0}{1}{2}{3}{4}", uploadfileServerUrl, "\\", UploadDirectory, "\\", fileName);

                        //Create Directoty
                        uploadDirectoryPath = String.Format("{0}{1}{2}", uploadfileServerUrl, "\\", UploadDirectory);

                        if (!Directory.Exists(downloadfileServerUrl + "\\" + UploadDirectory))
                        {
                            Directory.CreateDirectory(uploadDirectoryPath);
                        }
                        //End Create Directoty

                        FileWebRequest httpreq = (FileWebRequest)FileWebRequest.Create(uploadUrl);
                        FileWebResponse httpres;
                        httpreq.Proxy = null;
                        httpreq.Method = WebRequestMethods.Ftp.UploadFile;
                        httpreq.Credentials = new NetworkCredential(fileServerUserName, fileServerPassword);
                        byte[] httpData = fileStream;
                        httpreq.ContentLength = httpData.Length;
                        Stream httpStream = httpreq.GetRequestStream();
                        httpStream.Write(httpData, 0, httpData.Length);
                        httpStream.Close();

                        httpres = (FileWebResponse)httpreq.GetResponse();

                        response = "success";
                        break;

                    case "FileSystem":

                        //Create Directoty
                        uploadDirectoryPath = String.Format("{0}{1}{2}", uploadfileServerUrl, "\\", UploadDirectory);

                        if (!Directory.Exists(uploadDirectoryPath))
                        {
                            Directory.CreateDirectory(uploadDirectoryPath);
                        }
                        //End Create Directoty

                        //  pureFileName = new FileInfo(fileName).Name;
                        uploadUrl = String.Format("{0}{1}{2}{3}{4}", uploadfileServerUrl, "//", UploadDirectory, "//", fileName);
                        File.WriteAllBytes(uploadUrl, fileStream);
                        response = "success";
                        break;
                    default:
                        break;
                }
                return response;
            }
            catch
            {
                throw;
            }
            finally
            {

            }
        }

        public static byte[] ConvertStreamToByte(Stream input)

        {

            byte[] buffer = new byte[16 * 1024];

            using (MemoryStream ms = new MemoryStream())

            {

                int read;

                while ((read = input.Read(buffer, 0, buffer.Length)) > 0)

                {

                    ms.Write(buffer, 0, read);

                }

                return ms.ToArray();

            }

        }
        public void S2P2AddKeyToken(string _strUser, string sKey, string sToken)
        {
            DataLayer objDataLayer = new DataLayer();
            int iFlag = 1;
            try
            {
                SqlHelper.ExecuteNonQuery(objDataLayer.GetS2P2Connection(), CommandType.StoredProcedure, "spUserTokenSecurity",
                                                                                                                new SqlParameter("@UserID", _strUser),
                                                                                                                new SqlParameter("@APIKey", sKey),
                                                                                                                new SqlParameter("@ApiToken", sToken),
                                                                                                                new SqlParameter("@Flag", iFlag));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objDataLayer != null)
                {
                    objDataLayer = null;
                }
            }

        }
        public DataSet GetS2P2Details(string _strUser)
        {
            DataLayer objDataLayer = new DataLayer();
            DataSet ds = new DataSet();

            try
            {
                ds = SqlHelper.ExecuteDataset(objDataLayer.GetS2P2Connection(), CommandType.StoredProcedure, "spGetCEHHPDealerCode",
                                                       new SqlParameter("@UserID", _strUser), new SqlParameter("@Flag", "SPP"));
                return ds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objDataLayer != null)
                {
                    objDataLayer = null;
                }
            }

        }
    }

}
public class SMSOutput
{
    public bool status { get; set; }
    public string uniqueRefNO { get; set; }
    public string remark { get; set; }
}
/// <summary>
/// Image Object Class
/// </summary>
public class imgobject
{
    public string oldimg;
    public string newimg;

}

public class BidStatus
{
    private string[] bidStatus = new string[7] { "Initialize", "NewBid", "BidPlaced", "ReglobePickupRequested", "Closed", "Expired", "ReglobePickupRequestedByOther" };

    public string this[int index]
    {
        get
        {
            return bidStatus[index];
        }
    }
}


#endregion