﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;


   public class Encrypt_Decrypt
    {
       AesCryptoServiceProvider AesCryptoServiceObject;
       //Key and IV will be reside on both the system samsung sds and e-store
       // below key and IV is used for testing purpose it will change after actual code push on production
       public string CONFIGKEY = "[PurchaseAccessories : sppestoresamsung1^2@3#4&]; [2017][June];[samsung]; [gurgaon]";
       public string CONFIGIV =  "[PurchaseAccessories : sppestoresamsung5^6@7#8&]; [2017][June];[samsung]; [gurgaon]";
       public Encrypt_Decrypt()
       {
           //AES 256 initilization
           AesCryptoServiceObject = new AesCryptoServiceProvider();
           AesCryptoServiceObject.BlockSize = 128;
           AesCryptoServiceObject.KeySize = 256;
          // block cipher mode of operation is an algorithm that uses a block cipher to provide an information service such as confidentiality or authenticity
           AesCryptoServiceObject.Mode = CipherMode.CBC;
           AesCryptoServiceObject.Padding = PaddingMode.PKCS7;
       }
       // Encrypt Method
       public string encrypt(string key, string IV, string plaintext)
       {
           byte[] keybyte = System.Text.Encoding.ASCII.GetBytes(key);
           byte[] IVbyte = System.Text.Encoding.ASCII.GetBytes(IV);

           byte[] sha256Byteskey = { };
           byte[] sha256BytesIV = { };


           System.Security.Cryptography.SHA256 sha256 = new System.Security.Cryptography.SHA256Managed();
           sha256Byteskey = sha256.ComputeHash(keybyte);
           sha256BytesIV = sha256.ComputeHash(IVbyte);

           StringBuilder sha256Keystring = new StringBuilder();
           StringBuilder sha256IVstring = new StringBuilder();
           for (int i = 0; i < sha256Byteskey.Length; i++)
           {
               sha256Keystring.Append(sha256Byteskey[i].ToString("X2"));
           }
           string shakey = sha256Keystring.ToString().Substring(0, 16);

           for (int i = 0; i < sha256BytesIV.Length; i++)
           {
               sha256IVstring.Append(sha256BytesIV[i].ToString("X2"));
           }
           string shakeyIV = sha256IVstring.ToString().Substring(48);

           //------------------------------------------------------------------

           AesCryptoServiceObject.Key = Encoding.ASCII.GetBytes(shakey);
           AesCryptoServiceObject.IV = Encoding.ASCII.GetBytes(shakeyIV);


           ICryptoTransform transform = AesCryptoServiceObject.CreateEncryptor();
           byte[] encrypt_byte = transform.TransformFinalBlock(ASCIIEncoding.ASCII.GetBytes(plaintext), 0, plaintext.Length);
           string encryptstr = Convert.ToBase64String(encrypt_byte);
           return encryptstr;
       }
       // Decrypt Method
       public string decrypt(string key, string IV, string text)
       {
           byte[] keybyte = System.Text.Encoding.ASCII.GetBytes(key);
           byte[] IVbyte = System.Text.Encoding.ASCII.GetBytes(IV);

           byte[] sha256Byteskey = { };
           byte[] sha256BytesIV = { };


           System.Security.Cryptography.SHA256 sha256 = new System.Security.Cryptography.SHA256Managed();
           sha256Byteskey = sha256.ComputeHash(keybyte);
           sha256BytesIV = sha256.ComputeHash(IVbyte);

           StringBuilder sha256Keystring = new StringBuilder();
           StringBuilder sha256IVstring = new StringBuilder();
           for (int i = 0; i < sha256Byteskey.Length; i++)
           {
               sha256Keystring.Append(sha256Byteskey[i].ToString("X2"));
           }
           string shakey = sha256Keystring.ToString().Substring(0, 16);

           for (int i = 0; i < sha256BytesIV.Length; i++)
           {
               sha256IVstring.Append(sha256BytesIV[i].ToString("X2"));
           }
           string shakeyIV = sha256IVstring.ToString().Substring(48);

           //------------------------------------------------------------------

           AesCryptoServiceObject.Key = Encoding.ASCII.GetBytes(shakey);
           AesCryptoServiceObject.IV = Encoding.ASCII.GetBytes(shakeyIV);


           ICryptoTransform transform = AesCryptoServiceObject.CreateDecryptor();
           byte[] enc_bytes = Convert.FromBase64String(text);
           byte[] decrypt_bytes = transform.TransformFinalBlock(enc_bytes, 0, enc_bytes.Length);
           string decryptstr = ASCIIEncoding.ASCII.GetString(decrypt_bytes);
           return decryptstr;

       }
    }

   public class Smartdostintegration : Encrypt_Decrypt
   {
       public new string CONFIGKEY = "[smartdostspp : sppsmartdostsamsung1^2@3#4&]; [2017][sep];[samsung]; [gurgaon]";
       public new string CONFIGIV = "[ smartdostspp: sppsmartdostsamsung5^6@7#8&]; [2017][sep];[samsung]; [gurgaon]";


   }

