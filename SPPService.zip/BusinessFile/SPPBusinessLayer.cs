﻿using System;
using System.Data;
using System.Data.SqlClient;
using Microsoft.ApplicationBlocks.Data;
using SPPWebService.SPP;
using System.Security.Cryptography;
using System.Text;
using SPPWebservice.SPPWebserviceDTO;
using SPPWebservice.Model;
using System.Transactions;
using System.Configuration;
using System.Linq;
using System.Collections.Generic;
using System.Web;
using System.Net;
using System.IO;
using System.Collections.Specialized;
using System.Xml.Linq;
using System.Web.Script.Serialization;
using Spire.Pdf;
using System.Drawing;
using System.Threading;
using System.Xml.Serialization;
using Spire.Pdf.Graphics;
using SPPWebService.SPPWebserviceDTO;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;

public enum enummyreward
{
    TearmCondition = 1,
    Meal = 2
}
public class SPPBusinessLayer
{
    public const string KEY_DEALERRADIUS = "DealerSearchRadius";  //Dealer search radius From MyGalaxyConfigurationSettings table
    public const string KEY_CONFIGHOURS = "DealerBidMaxHours";   //Dealer ConfigurationHours 
    public const string KEY_REGLOBEPERCENT = "ReGlobePercentage"; //Reglobe price percentage 
    public const string KEY_BIDCOUNTLIMIT = "BidCountLimit";   // Dealer Bid count limit per transaction 
    public const string KEY_REGLOBEBIDVALIDITYDAYS = "ReglobeBidValidityDays";   // Reglobe expiry day From app config
    public const string KEY_REGLOBESERVICE_URL = "ReglobeServiceBaseURL";   // Reglobe expiry day From app config
    public const string KEY_DISPLAYTOPUP = "DisplayTopUp";
    public const string KEY_MYGALAXYSERVICE_URL = "MyGalaxyServiceBaseURL";
    public const string KEY_SENDPOSTBIDOFFER = "SendPostBidOffer";
    public const string KEY_SENDREGLOBEPICKUP = "SendReglobePickUp";
    public const string KEY_POSTUSERIDCODE = "PostUserIdCode";
    public const string KEY_POSTAPIKEY = "PostApiKey";
    public const string KEY_POSTAPITOKEN = "PostApiToken";
    public const string KEY_BIDHISTORYVISIBILITY = "BidHistoryVisibility";
    public const string KEY_TOPDEALERCOUNT = "TopDealerCount";
    public const string KEY_GOOGLEAPI = "GoogleAPI";
    public const string KEY_DEALERCITYRADIUS = "Radius";
    //-------------------------------New Changes in global bid amount: May-02-2016--------------------------------

    public const string KEY_BIDMINAMOUNT = "BidMinAmount";
    public const string KEY_BIDMAXAMOUNT = "BidMaxAmount";
    public const string KEY_BIDMINPERCENTAGET = "BidMinPercentage";
    public const string KEY_BIDMAXPERCENTAGET = "BidMaxPercentage";
    public const string KEY_MINFLAG = "MinFlag";
    public const string KEY_MAXFLAG = "MaxFlag";
    public const string KEY_Radius = "Radius"; // Added by shaif : now dealer allowcate bid acroding to population density
    public const string KEY_BUYBACKSINGLEDEALER = "BuyBackSingleDealer";

    //----------------------------------------------------------------------------------------------
    public const string KEY_CALLBYSMARTDOST = "SD";
    public List<MyGalaxyConfigurationSetting> lstConfigSettings = null;


    public SPPBusinessLayer()
    {

    }

    #region "validation"
    /// <summary>
    /// Validate Web Service SPI Token
    /// </summary>
    /// <param name="_strUser">User id</param>
    /// <param name="sKey">Key</param>
    /// <param name="sToken">Token</param>
    /// <param name="tokeExpiratioinTime">tokeExpiratioinTime</param>
    /// <returns>bool</returns>
    public bool ValidateWebServiceApiToken(string _strUser, string sKey, string sToken, int tokeExpiratioinTime)
    {
        bool status = false;
        DataLayer objDataLayer = new DataLayer();
        try
        {

            var Userid = SqlHelper.ExecuteScalar(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spUserTokenSecurity",
                                                                                                          new SqlParameter("@UserID", _strUser),
                                                                                                          new SqlParameter("@APIKey", sKey),
                                                                                                          new SqlParameter("@ApiToken", sToken),
                                                                                                          new SqlParameter("@Flag", 2));

            if (Userid != null && Userid.ToString().ToLower() == _strUser.ToLower())
            {
                status = true;
            }
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            objDataLayer = null;
        }

        return status;
    }
    public bool ValidateWebServiceApiToken(string _strUser, string sKey, string sToken, int tokeExpiratioinTime, string Flag)
    {
        bool status = false;
        DataLayer objDataLayer = new DataLayer();
        try
        {

            var Userid = SqlHelper.ExecuteScalar(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spUserTokenSecurity",
                                                                                                          new SqlParameter("@UserID", _strUser),
                                                                                                          new SqlParameter("@APIKey", sKey),
                                                                                                          new SqlParameter("@ApiToken", sToken),
                                                                                                          new SqlParameter("@Flag", Flag));

            if (Userid != null && Userid.ToString().ToLower() == _strUser.ToLower())
            {
                status = true;
            }
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            objDataLayer = null;
        }

        return status;
    }

    /// <summary>
    /// To validate service credential.
    /// </summary>
    /// <param name="WebServiceUserID"></param>
    /// <param name="WebServicePassword"></param>
    /// <returns>int</returns>
    public int ValidateWebServiceCredentials(string WebServiceUserID, string WebServicePassword)
    {
        int iIsValid = 0;
        int iFlag = 3;
        DataSet ds = null;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spUserTokenSecurity",
                                                                                                          new SqlParameter("@UserID", string.Empty),
                                                                                                          new SqlParameter("@APIKey", string.Empty),
                                                                                                          new SqlParameter("@ApiToken", string.Empty),
                                                                                                          new SqlParameter("@Flag", iFlag));
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                if (WebServiceUserID == ds.Tables[0].Rows[0]["UserLoginID"].ToString() && WebServicePassword == ds.Tables[0].Rows[0]["Password"].ToString())
                {
                    iIsValid = 1;
                }
            }

        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {

        }

        return iIsValid;
    }
    /// <summary>
    /// Added by Shyam Sunder Kumar as on 17
    /// </summary>
    /// <param name="obj">class object</param>
    /// <returns>boolean</returns>
    public bool ValidateParameter(object obj)
    {

        bool status = false;

        string[] VulnerKey = new string[] { " ", "-", ";", "'", "or", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        string[] VulnerKeyUserID = new string[] { " ", ";", "'", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        string[] VulnerKeysubtype = new string[] { ";", "'", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        /*Modified by Shyam Sunder Kumar as on 24-May-2017 to allow "-" from spp web portal request*/
        string[] VulnerKeyapikey = new string[] { " ", ";", "'", "or", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        string[] VulnerKeyapiToken = new string[] { " ", ";", "'", "or", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        /*End Changes*/
        foreach (var prop in obj.GetType().GetProperties())
        {

            //Commented and Added by Anil verma 07 Oct 2015 to prevent productserial key
            //if(prop.Name.ToLower() != "webserviceuserid" && prop.Name.ToLower() != "webservicepassword" && prop.Name.ToLower() != "sdescription" && prop.Name.ToLower() != "selectoption" && prop.Name.ToLower() != "question" && prop.Name.ToLower() != "fromdate" && prop.Name.ToLower() != "todate" && prop.Name.ToLower() != "userapkversion" && prop.Name.ToLower() != "saletype" && prop.Name.ToLower() != "email")
            //Commented and Added by Anil verma 9 march 2016 to prevent schemecode key
            //Commented and Added by Anil verma 31 march 2016 to prevent officeadd key 
            //Commented and Added by Anil verma 21 April 2016 to prevent commentcontent key 
            //Commented and Added by Anil verma 26 April 2016 to prevent searchkeyword key 
            // Changed by Dheeraj on 01-Sep-20 for SMAPP customer product service return process            

            if (prop.Name.ToLower() != "webserviceuserid" && prop.Name.ToLower() != "webservicepassword" && prop.Name.ToLower() != "sdescription" && prop.Name.ToLower() != "selectoption" && prop.Name.ToLower() != "question" && prop.Name.ToLower() != "fromdate" && prop.Name.ToLower() != "todate" && prop.Name.ToLower() != "userapkversion" && prop.Name.ToLower() != "saletype" && prop.Name.ToLower() != "email" && prop.Name.ToLower() != "productserial" && prop.Name.ToLower() != "schemecode"
                && prop.Name.ToLower() != "officeadd" && prop.Name.ToLower() != "commentcontent" && prop.Name.ToLower() != "refrcname" && prop.Name.ToLower() != "username" && prop.Name.ToLower() != "subject" && prop.Name.ToLower() != "summary" && prop.Name.ToLower() != "searchkeyword" && prop.Name.ToLower() != "feedbackreplytext" && prop.Name.ToLower() != "requestno" && prop.Name.ToLower() != "authtoken" && prop.Name.ToLower() != "skucode" && prop.Name.ToLower() != "urlcode" && prop.Name.ToLower() != "cluster" && prop.Name.ToLower() != "region" && prop.Name.ToLower() != "subregion" && prop.Name.ToLower() != "state" && prop.Name.ToLower() != "state" && prop.Name.ToLower() != "callmethod" && prop.Name.ToLower() != "callby" && prop.Name.ToLower() != "menuname"
                && prop.Name.ToLower() != "customername" && prop.Name.ToLower() != "model" && prop.Name.ToLower() != "marketname" && prop.Name.ToLower() != "productcode" && prop.Name.ToLower() != "securitykey" && prop.Name.ToLower() != "password" && prop.Name.ToLower() != "longitude" && prop.Name.ToLower() != "latitude" && prop.Name.ToLower() != "customeraccount" && prop.Name.ToLower() != "orderno" && prop.Name.ToLower() != "mddcode" && prop.Name.ToLower() != "filtervalue"
                )
            {
                string str = Convert.ToString(prop.GetValue(obj, null));
                if (!string.IsNullOrEmpty(str))
                {
                    if (prop.Name.ToLower() == "userid" || prop.Name.ToLower() == "password" || prop.Name.ToLower() == "partnercode")
                    {
                        foreach (string x in VulnerKeyUserID)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                    else if (prop.Name.ToLower() == "subtype")//Added by Shyam Sunder Kumar as on 24-July-2015 to allow space[" "]
                    {
                        foreach (string x in VulnerKeysubtype)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                    /*Modified by Shyam Sunder Kumar as on 24-May-2017 to allow "-" from spp web portal request*/
                    else if (prop.Name.ToLower() == "apikey")
                    {
                        foreach (string x in VulnerKeyapikey)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                    else if (prop.Name.ToLower() == "apitoken")
                    {
                        foreach (string x in VulnerKeyapiToken)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                    /*End Changes*/
                    else
                    {
                        foreach (string x in VulnerKey)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                }
            }
        }


        return status;
    }

    /// <summary>
    /// Added by qyam on 05-feb-15. To validate vulnerable parameter for device registration.
    /// </summary>
    /// <param name="obj">class object</param>
    /// <returns>boolean</returns>
    public bool ValidateParameterForDeviceRegistration(object obj)
    {
        bool status = false;
        string[] VulnerKey = new string[] { "select", "from", "where", "union", "update", "insert", "delete" };//for registrationid
        string[] VulnerKeyUserID = new string[] { " ", "-", "or", ";", "'", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };

        foreach (var prop in obj.GetType().GetProperties())
        {
            if (prop.Name.ToLower() != "message")
            {
                string str = Convert.ToString(prop.GetValue(obj, null));
                if (!string.IsNullOrEmpty(str))
                {
                    if (prop.Name.ToLower() == "userid" || prop.Name.ToLower() == "webserviceuserid" || prop.Name.ToLower() == "webservicepassword" || prop.Name.ToLower() == "deviceregistrationid" || prop.Name.ToLower() == "commtype")
                    {
                        foreach (string x in VulnerKey)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (string x in VulnerKeyUserID)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                }
            }
        }

        return status;
    }

    /// <summary>
    /// Validate parameter only for my galaxy excluding Date,webserviceuserid ,webservicepassword
    /// </summary>
    /// <param name="obj"></param>
    /// <returns></returns>
    public bool ValidateParameterForMyGalaxy(object obj)
    {

        bool status = false;

        string[] VulnerKey = new string[] { "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        string[] VulnerKeyUserID = new string[] { " ", ";", "'", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };
        string[] VulnerKeysubtype = new string[] { ";", "'", "=", "/", "null", "select", "from", "where", "union", "update", "insert", "delete" };

        foreach (var prop in obj.GetType().GetProperties())
        {
            if (prop.Name.ToLower() != "webserviceuserid" && prop.Name.ToLower() != "webservicepassword" && prop.Name.ToLower() != "dateofcreation" && prop.Name.ToLower() != "phonecondition" && prop.Name.ToLower() != "topupoffer"
                 && prop.Name.ToLower() != "reglobebidvalidity" && prop.Name.ToLower() != "email" && prop.Name.ToLower() != "interestdatetime" && prop.Name.ToLower() != "createddate" && prop.Name.ToLower() != "productserial")
            {
                string str = Convert.ToString(prop.GetValue(obj, null));
                if (!string.IsNullOrEmpty(str))
                {
                    if (prop.Name.ToLower() == "userid" || prop.Name.ToLower() == "password" || prop.Name.ToLower() == "partnercode")
                    {
                        foreach (string x in VulnerKeyUserID)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                    else
                    {
                        foreach (string x in VulnerKey)
                        {
                            if (str.ToLower().Contains(x))
                            {
                                return status = true;
                            }
                        }
                    }
                }
            }
        }


        return status;
    }
    #endregion

    #region"AppVersion"
    /// <summary>
    /// Method Name   : Get Latest App Version
    /// Createdby     : Shyam Sunder Kumar
    /// Created On    : 17-Dec-2015
    /// Description   : To get Latest Mobile application version and isupgrademandatory column value.
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable GetLatestAppVersion()
    {
        DataLayer objDataLayer = new DataLayer();
        DataTable dtVersion = new DataTable();
        try
        {
            dtVersion = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spSPPAPPGetLatestAppVersion").Tables[0];
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
        return dtVersion;
    }

    /// <summary>
    /// Method Name   : Add Ndncconsent
    /// Createdby     : shaif rizvi
    /// Created On    : 22-july-2016
    /// Description   : Add Ndncconsent from app.
    /// </summary>
    /// <returns>DataTable</returns>
    public int AddSPPAPPAddNdncconsent(string vUserName)
    {
        DataLayer objDataLayer = new DataLayer();
        int retval = 0;
        try
        {
            retval = SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPAPPAddNdncconsent", new SqlParameter("@UserName", vUserName));
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
        return retval;
    }

    /// <summary>
    /// Method Name   : Get ForGot Password Details
    /// Createdby     : Shyam Sunder Kumar
    /// Created On    : 17-Dec-2015
    /// Description   : To get Latest Mobile application version and isupgrademandatory column value.
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable GetForgotPasswordDetails()
    {
        DataTable dt = new DataTable();
        DataLayer objDataLayer = new DataLayer();

        try
        {
            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spSPPAPPGetForgotPasswordDetails").Tables[0];
            return dt;
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }
    #endregion

    #region Login
    /// <summary>
    /// Function to Get User Details
    /// Modifed by Shyam Sunder Kumar as on 09-Dec-2020
    /// </summary>   
    /// <param name="vUserName">User Name</param>
    /// <param name="vLatitide">Latitide</param>
    /// <param name="vLongitude">Longitude</param>
    /// <returns>DataTable</returns>
    public DataTable GetUserDetails(string vUserName, string vLatitide = "-", string vLongitude = "-")
    {
        DataLayer objDataLayer = new DataLayer();
        DataTable dt = null;
        SPPUtility objUtility = new SPPUtility();
        try
        {
            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetUserDetailsByUserName",
                new SqlParameter("@UserName", vUserName)
                , new SqlParameter("@Latitide", vLatitide)
                , new SqlParameter("@Longitude", vLongitude)).Tables[0];
            dt = objUtility.GenericReplace(dt);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;
    }

    /// <summary>
    /// Function to Get Login Details from GMCS
    /// </summary>
    /// <param name="sUserID">User ID</param>
    /// <returns></returns>
    public DataTable Login(string sUserID, string ipaddress)
    {
        DataLayer dtLayer = null;
        try
        {
            dtLayer = new DataLayer();
            return SqlHelper.ExecuteDataset(dtLayer.GetMCSConnection(), CommandType.StoredProcedure, "spCeGetUserInfo",
                                                                                                new SqlParameter("@USERID", sUserID),
                                                                                                new SqlParameter("@LASTACCESSIP", ipaddress)).Tables[0];
        }
        catch (Exception ex)
        {
            //Custom Error Handling 
            DataTable errTab = new DataTable();

            DataColumn errCol = new DataColumn("ErrCol");
            errCol.DataType = System.Type.GetType("System.string");
            errTab.Columns.Add(errCol);

            DataRow rw = errTab.NewRow();
            rw["Error"] = ex.Message.ToString();


            errTab.Dispose();
            return errTab;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }
    /// <summary>
    /// Function to Get Failure Counter
    /// </summary>
    public int GetSetFailureCounter(string sUserID, int iLoginStatus, int iAttempt, int iAction, string userapkversion)
    {
        DataLayer dtLayer = new DataLayer();

        int iCount = 0;
        int iBlockTime = 1800;
        int iMaxBlockAttempts = 5;
        if (iLoginStatus == 1) // pass
        {
            iAttempt = 0;
        }

        try
        {
            DataSet ds = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spManageUserBlocking",
                                                                                                        new SqlParameter("@Flag", iAction),
                                                                                                        new SqlParameter("@UserId", sUserID),
                                                                                                        new SqlParameter("@BlockTime", iBlockTime),
                                                                                                        new SqlParameter("@MaxFailureCount", iMaxBlockAttempts),
                                                                                                        new SqlParameter("@FailureCounter", iAttempt),
                                                                                                        new SqlParameter("@userapkversion", userapkversion));

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                iCount = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (dtLayer != null)
            {
                dtLayer = null;
            }
        }
        return iCount;
    }

    /// <summary>
    /// Function to Get Failure Counter
    /// </summary>
    public int GetSetFailureCounter(string sUserID, int iLoginStatus, int iAttempt, int iAction, string userapkversion, int popupcount, int configpopupcount)
    {
        DataLayer dtLayer = new DataLayer();

        int iCount = 0;
        int iBlockTime = 1800;
        int iMaxBlockAttempts = 5;
        if (iLoginStatus == 1) // pass
        {
            iAttempt = 0;
        }

        try
        {
            DataSet ds = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spManageUserBlocking",
                                                                                                        new SqlParameter("@Flag", iAction),
                                                                                                        new SqlParameter("@UserId", sUserID),
                                                                                                        new SqlParameter("@BlockTime", iBlockTime),
                                                                                                        new SqlParameter("@MaxFailureCount", iMaxBlockAttempts),
                                                                                                        new SqlParameter("@FailureCounter", iAttempt),
                                                                                                        new SqlParameter("@userapkversion", userapkversion),
                                                                                                        new SqlParameter("@configpopupcount", configpopupcount),
                                                                                                        new SqlParameter("@popupcount", popupcount)
                                                                                                        );

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                iCount = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (dtLayer != null)
            {
                dtLayer = null;
            }
        }
        return iCount;
    }
    /// <summary>
    /// To save API key token.
    /// </summary>
    /// <param name="_strUser">User</param>
    /// <param name="sKey">Key</param>
    /// <param name="sToken">Token</param>
    public void AddKeyToken(string _strUser, string sKey, string sToken)
    {
        DataLayer objDataLayer = new DataLayer();
        int iFlag = 1;
        try
        {
            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spUserTokenSecurity",
                                                                                                            new SqlParameter("@UserID", _strUser),
                                                                                                            new SqlParameter("@APIKey", sKey),
                                                                                                            new SqlParameter("@ApiToken", sToken),
                                                                                                            new SqlParameter("@Flag", iFlag));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }

    }

    public void AddKeyToken(string _strUser, string sKey, string sToken, string Flag)
    {
        DataLayer objDataLayer = new DataLayer();

        try
        {
            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spUserTokenSecurity",
                                                                                                            new SqlParameter("@UserID", _strUser),
                                                                                                            new SqlParameter("@APIKey", sKey),
                                                                                                            new SqlParameter("@ApiToken", sToken),
                                                                                                            new SqlParameter("@Flag", Flag));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }

    }
    /// <summary>
    /// Function to insert User Login AccessLog
    /// </summary>
    /// <param name="vUserID">User ID</param>
    /// <param name="vTokenName">Token Name</param>
    public void InsertUserLoginAccessLog(string vUserID, string vTokenName)
    {
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spInsertApplicationLog",
                                                                                                        new SqlParameter("@UserId", vUserID),
                                                                                                        new SqlParameter("@IPAddress", string.Empty),
                                                                                                        new SqlParameter("@TokenName", vTokenName),
                                                                                                        new SqlParameter("@LoginTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))                                                                                                        
                                                                                                       );
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }

    /// <summary>
    /// Function to insert User Login AccessLog
    /// Added by Shyam Sunder Kumar as on 25-July-2023 for Module/Login Tracking
    /// </summary>
    /// <param name="vUserID">User ID</param>
    /// <param name="vTokenName">Token Name</param>
    /// <param name="vUserApkVersion">User Apk Version</param>
    /// <param name="vapkversionCode">APK version name</param>
    /// <param name="vAndroidVersion">Android Version</param>
    public void InsertUserLoginAccessLog(string vUserID, string vTokenName, string vUserApkVersion, string vapkversionCode, string vAndroidVersion)
    {
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spInsertApplicationLog",
                                                                                                        new SqlParameter("@UserId", vUserID),
                                                                                                        new SqlParameter("@IPAddress", string.Empty),
                                                                                                        new SqlParameter("@TokenName", vTokenName),
                                                                                                        new SqlParameter("@LoginTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")),
                                                                                                        new SqlParameter("@UserApkVersion", vUserApkVersion),
                                                                                                        new SqlParameter("@ApkVersionCode", vapkversionCode),
                                                                                                        new SqlParameter("@AndroidVersion", vAndroidVersion)
                                                                                                       );
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }

    /// <summary>
    /// To get Api key/Token
    /// </summary>
    /// <returns>string</returns>
    public string GetUniqueKey()
    {
        int maxSize = 10;
        char[] chars = new char[62];
        string a;
        a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        chars = a.ToCharArray();
        int size = maxSize;
        byte[] data = new byte[1];
        RNGCryptoServiceProvider crypto = new RNGCryptoServiceProvider();
        crypto.GetNonZeroBytes(data);
        size = maxSize;
        data = new byte[size];
        crypto.GetNonZeroBytes(data);
        StringBuilder result = new StringBuilder(size);
        foreach (byte b in data)
        {
            result.Append(chars[b % (chars.Length - 1)]);
        }
        return result.ToString();
    }

    /// <summary>
    /// Method Name   : SPPInsertToken
    /// Createdby     : Shyam Sunder Kumar
    /// Created On    : 11 Sep 2015
    /// Description   :Function to Update Token by blank.
    /// </summary>
    /// <param name="vuserID">User ID</param>
    /// <returns>bool</returns>
    public bool SPPUpdateToken(string vuserID)
    {
        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spAPPUpdateKeyToken",
                new SqlParameter("@UserID", vuserID),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);


            if (ires == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }


    }



    public bool CheckSmartDostTokenbySPP(string vuserID, string Token, string TokenKey)
    {
        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSmartDostConnection(), CommandType.StoredProcedure, "spCheckSmartdostTokenbyspp",
                new SqlParameter("@UserCode", vuserID), new SqlParameter("@ApiToken", Token), new SqlParameter("@ApiKey", TokenKey),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);


            if (ires == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }


    }

    /// <summary>
    /// Returns Sales Hierarchy[ABM/ZSM/RSM] of User based on UserName
    /// Created by : Shyam Sunder Kumar
    /// Created On : 28 Dec 2015
    /// </summary>
    /// <param name="vUserName">User Name</param>
    /// <returns> A - ABM, Z - ZSM, R - RSM, O - Others</returns>
    public string GetSalesHierarchy(string vUserName)
    {
        DataLayer dtLayer = null;
        string vResult = "O";
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "uspGetSalesHierarchy",
                                                                                                new SqlParameter("@UserName", vUserName)).Tables[0];

            if (dt.Rows.Count > 0)
            {
                vResult = dt.Rows[0]["Mapping"].ToString();
            }
            return vResult;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
            if (dt != null)
            {
                dt.Dispose();
                dt = null;
            }

        }


    }


    /// <summary>
    /// Function to check SMD User Type of User
    /// Added by Anil Verma on 03 May 2016
    /// </summary>
    /// <param name="vDMSCode">DMS Code</param>
    /// <returns>bool</returns>
    public bool IsSMDUser(string vDMSCode)
    {

        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@IsExists";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Bit;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 1;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPCheckSMDUserType",
                new SqlParameter("@DMSCode", vDMSCode),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);

            if (ires == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }



    }

    /// <summary>
    /// Function to check SMD User Type of User
    /// Added by Shaif Rizvi on Feb-21-2017
    /// </summary>
    /// <param name="vDMSCode">DMS Code</param>
    /// <returns>bool</returns>
    public bool IsAuthorizedPolicyandGuidline(string vDMSCode)
    {

        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@IsExists";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Bit;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 1;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPCheckUserForPolicyandGuidLines",
                new SqlParameter("@DMSCode", vDMSCode),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);

            if (ires == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }



    }

    public bool IsUserTypeMyReward(string usercode)
    {
        bool iseditprofile = false;
        SPPBusinessLayer objSPPBusinessLayer = new SPPBusinessLayer();
        DataTable SPPTable = objSPPBusinessLayer.GetUserDetails(usercode);
        if (SPPTable != null && SPPTable.Rows.Count > 0 && SPPTable.Rows[0]["IsActive"].ToString().ToUpper() == "Y")
        {
            if (SPPTable.Rows[0]["RefUserTypeID"] != null)
            {
                string usertypeid = SPPTable.Rows[0]["RefUserTypeID"].ToString();

                //User profile non editable on MDD user type
                if (ConfigurationManager.AppSettings["isprofileeditusertype"] != null)
                {
                    if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["isprofileeditusertype"].ToString()))
                    {
                        string[] IsProfileEditUserType = ConfigurationManager.AppSettings["isprofileeditusertype"].ToString().Split(',');
                        iseditprofile = IsProfileEditUserType.Any(n => Equals(n, usertypeid)) == true ? true : false;

                    }
                }
            }
        }
        return iseditprofile;
    }
    /// <summary>
    /// Returns Device Registration ID
    /// Created by : Shyam Sunder Kumar
    /// Created On : 11 Jan 2016
    /// </summary>
    /// <param name="vUserName">User Name</param>
    /// <returns>Device Registration ID</returns>
    public string GetDeviceRegistration(string vUserName)
    {
        DataLayer dtLayer = null;
        string vResult = string.Empty;
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPAppGetDeviceRegistration",
                                                                                                new SqlParameter("@UserName", vUserName)).Tables[0];

            if (dt.Rows.Count > 0)
            {
                vResult = dt.Rows[0]["DeviceRegistrationID"].ToString();
            }
            return vResult;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
            if (dt != null)
            {
                dt.Dispose();
                dt = null;
            }

        }


    }

    /// <summary>
    /// Function to Get Login Alert Message
    /// Added by Shyam Sunder Kumar as on 15-Dec-2020
    /// </summary>
    /// <param name="vIMEINumber">IMEI Number</param>
    /// <param name="vDistCode">Dist Code</param> 
    /// <returns>DataSet</returns>
    public DataSet GetLoginAlertMessage(string vIMEINumber, string vDistCode)
    {
        DataLayer dtLayer = new DataLayer();

        try
        {

            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spLAGetLoginSuccessMessage",
                                                                                                new SqlParameter("@IMEINumber", vIMEINumber)
                                                                                                , new SqlParameter("@DistCode", vDistCode));


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
        }


    }

    /// <summary>
    /// Function to Get Login Locked Message
    /// Added by Shyam Sunder Kumar as on 16-Dec-2020
    /// </summary>
    /// <param name="vIMEINumber">IMEI Number</param>
    /// <returns>DataSet</returns>
    public DataSet GetLoginIDLockMessage(string vIMEINumber)
    {
        DataLayer dtLayer = new DataLayer();

        try
        {

            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spLAGetIDLockMessage",
                                                                                                new SqlParameter("@IMEINumber", vIMEINumber));


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
        }


    }


    /// <summary>
    /// Function to check orderbook applicablility
    /// Added by Shyam Sunder Kumar as on 16-Dec-2020
    /// </summary>
    /// <param name="vDistCode">Dist Code</param>
    /// <returns>DataSet</returns>
    public DataSet GetOrderBookOTPApplicable(string vDistCode)
    {
        DataLayer dtLayer = new DataLayer();

        try
        {

            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spLAGetOrderBookOTPApplicable",
                                                                                                new SqlParameter("@DistCode", vDistCode));


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
        }


    }

    /// <summary>
    /// Function to Get TSE Manager Message
    /// Added by Shyam Sunder Kumar as on 16-Dec-2020
    /// </summary>
    /// <param name="vIMEINumber">IMEI Number</param>
    /// <param name="vDistCode">Dist Code</param> 
    /// <returns>DataSet</returns>
    public DataSet GetTSEManagerMessage(string vIMEINumber, string vDistCode)
    {
        DataLayer dtLayer = new DataLayer();

        try
        {

            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spLAGetTSEManagerDetailsWithMessage",
                                                                                                new SqlParameter("@IMEINumber", vIMEINumber)
                                                                                                , new SqlParameter("@DistCode", vDistCode));


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
        }


    }


    /// <summary>
    /// Function to Insert App Launch History
    /// Added by Shyam Sunder Kumar as on 04-Dec-2020
    /// </summary>
    /// <param name="vIMEINumber">IMEI Number</param>
    /// <returns></returns>
    public int SPPInsertAppLaunchHistory(string vIMEINumber)
    {
        DataLayer objDataLayer = new DataLayer();


        int ires = 0;
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            ires = Convert.ToInt32(SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spLAInsertAppLaunchHistory",
                      new SqlParameter("@IMEINumber", vIMEINumber),
                      outPutParameter
                      ));
            ires = Convert.ToInt16(outPutParameter.Value.ToString());
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

        }
        return ires;
    }
    /// <summary>
    /// Function to Get Payment Gateway Applicability
    /// Added by shyam sunder kumar as on 02-May-2021
    /// </summary>
    /// <param name="vDistCode">DistCode</param>
    /// <returns>DataSet</returns>
    public DataSet GetPaymentGatewayApplicable(string vDistCode)
    {
        DataLayer dtLayer = new DataLayer();

        try
        {

            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBPGGetPaymentGatewayApplicable",
                                                                                                new SqlParameter("@DistCode", vDistCode));


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
        }


    }

    /// <summary>
    /// Added By Shyam Sunder Kumar as on 24-July-2023
    /// Function to Get Module Tracking Applicability
    /// </summary>
    /// <returns>DataSet</returns>
    public DataSet GetModuleTrackingApplicability()
    {
        DataLayer dtLayer = new DataLayer();

        try
        {

            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMTGetTrackingApplicability");


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
        }


    }
    #endregion

    #region "MenuList"

    /// <summary>
    /// Function to Get Menu List
    /// Changes for SPP Nepal 04 april 2022 Amandeep start  [SPP_Nepal_Mearge]
    /// </summary>
    /// <param name="vUserTypeID"></param>
    /// <param name="vUserSubTypeID"></param>
    /// <param name="vMenuID"></param>
    /// <param name="vMenuType"></param>
    /// <returns></returns>
    public DataTable SPPGetMenuListByRefID(string RefId, string CategoryType, string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dtMenuList = null;
        try
        {

            dtMenuList = objUtility.GenericReplace(SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMenuListByRefID"
                                , new SqlParameter("@RefId", RefId)
                                , new SqlParameter("@CategoryType", CategoryType)
                                , new SqlParameter("@CountryCode", CountryCode)
                          ).Tables[0]);
            return dtMenuList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
            if (dtMenuList != null)
            {
                dtMenuList = null;
            }
        }

    }

    //Changes for SPP Sri lanka 20 may 2022 Amandeep start

    public DataTable AppNotificationCategoryTextAndMenuById(string CategoryId, string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dtMenuList = null;
        try
        {

            dtMenuList = objUtility.GenericReplace(SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "sppSPPAppNotificationCategoryTextAndMenuById"
                                , new SqlParameter("@CategoryId", CategoryId)
                                , new SqlParameter("@CountryCode", CountryCode)
                          ).Tables[0]);
            return dtMenuList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
            if (dtMenuList != null)
            {
                dtMenuList = null;
            }
        }

    }
    /// <summary>
    /// Function to Get Menu List
    /// Modified by Smariti Shukla as on 02-Feb-2022 for Countrywise changes in SPP Nepal
    /// </summary>
    /// <param name="vUserTypeID"></param>
    /// <param name="vUserSubTypeID"></param>
    /// <param name="vMenuID"></param>
    /// <param name="vMenuType"></param>
    /// <param name="vCallBy"></param>
    /// <param name="vCountryCode">[SPP_Nepal_Mearge]</param>
    /// <returns></returns>
    public DataTable SPPGetMenuList(string vUserTypeID, string vUserSubTypeID, string vMenuID, string vMenuType, string vDealerCode, string vCallBy, string vCountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dtMenuList = null;
        try
        {

            dtMenuList = objUtility.GenericReplace(SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPAppGetMenuList"
                                , new SqlParameter("@UserTypeID", vUserTypeID)
                                , new SqlParameter("@SubUserTypeID", vUserSubTypeID)
                                , new SqlParameter("@MenuID", vMenuID)
                                , new SqlParameter("@MenuType", vMenuType)
                                , new SqlParameter("@DealerCode", vDealerCode)
                                , new SqlParameter("@CallBy", vCallBy)
                                 , new SqlParameter("@CountryCode", vCountryCode)).Tables[0]);//[SPP_Nepal_Mearge]
            return dtMenuList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
            if (dtMenuList != null)
            {
                dtMenuList = null;
            }
        }

    }

    /// <summary>
    /// To get banners.
    /// Added by Shyam Sunder Kumar as on 22-Dec-2015 
    /// SPP app changes for nepal 09 feb 2022 Amandeep Start [SPP_Nepal_Mearge]
    /// </summary>
    /// <param>CountryCode</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetBanners(string CountryCode)
    {
        DataTable dt = new DataTable();
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        try
        {
            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPAppGetBanner", new SqlParameter("@CountryCode", CountryCode)).Tables[0];//[SPP_Nepal_Mearge]
            return objUtility.GenericReplace(dt);
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (dt != null)
            {
                dt.Dispose();
                dt = null;
            }
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
    }

    /// <summary>
    /// To get Product Category.
    /// Added by Amit Kumar Singh as on 30-Aug-2020 
    /// SPP Nepal changes for country code 7 march 2022 Amandeep Singh start [SPP_Nepal_Mearge]
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable SPPGetPCCategory(string categoryId, string CountryCode)
    {
        DataTable dt = new DataTable();
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        try
        {
            // SPP Nepal changes for country code 2 march 2022 Amandeep Singh end [SPP_Nepal_Mearge]
            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetPCCategory", new SqlParameter("@CategoryID", categoryId)
              , new SqlParameter("@CountryCode", CountryCode)).Tables[0];

            return objUtility.GenericReplace(dt);
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (dt != null)
            {
                dt.Dispose();
                dt = null;
            }
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
    }

    /// <summary>
    /// Function to Check Is SMAPP Eligible
    /// Added by Shyam Sunder Kumar on 17-Sep-2020
    /// </summary>
    /// <param name="vDealerCode">DealerCode</param>
    /// <returns></returns>
    public bool IsSMAPPEligible(string vDealerCode)
    {
        DataTable dt = new DataTable();
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@IsEligible";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Bit;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 1;

            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetRequestReturnAccessRights",
                 new SqlParameter("@DealerCode", vDealerCode),
                 new SqlParameter("@IsWebRequest", false),
                 outPutParameter
                 );
            bool vIsEligible = Convert.ToBoolean(outPutParameter.Value);

            return vIsEligible;
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (dt != null)
            {
                dt.Dispose();
                dt = null;
            }
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
    }
    #endregion
    #region"Product Corner"
    /// <summary>
    /// Method Name   : SppGetProductByCategoryID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 30 June 2015
    /// Description    :To get all product with respect to productcategoryid.
    /// SPP Nepal changes for country code 2 march 2022 Amandeep Singh Start [SPP_Nepal_Mearge]
    /// </summary>
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="categoryId">Category ID</param>
    /// <param name="stateId">State ID</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetProductByCategoryID(int usercode, string categoryId, string stateId, string DealerCode, string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProductList = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtProductList = null;
        try
        {
            // SPP Nepal changes for country code 2 march 2022 Amandeep Singh End [SPP_Nepal_Mearge]
            dsProductList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetProductList", new SqlParameter("@CategoryID", categoryId), new SqlParameter("@StateID", stateId), new SqlParameter("@DealerCode", DealerCode)
                , new SqlParameter("@CountryCode", CountryCode));
            dtProductList = objUtility.GenericReplace(dsProductList.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtProductList;
    }

    /// <summary>
    /// Method Name   : SPPGetProductByProductID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 1 July 2015
    /// Description    :To get product details with respect to productId.
    /// Changes for SPP Nepal 02 march 2022 Amandeep start [SPP_Nepal_Mearge]
    /// </summary>
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="productId">Product ID</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetProductByProductID(int usercode, string productId, string countryCode, string _Source)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProductDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtProductDetails = null;
        try
        {
            //Changes for SPP Nepal 02 march 2022 Amandeep end [SPP_Nepal_Mearge]
            dsProductDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetProductByProductID", new SqlParameter("@ProductID", productId)
              , new SqlParameter("@CountryCode", countryCode), new SqlParameter("@Source", _Source));
            dtProductDetails = objUtility.GenericReplace(dsProductDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtProductDetails;
    }


    /// <summary>
    /// Method Name   : SppGetProductSpecsAndImages
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 1 July 2015
    /// Description   :To get productspecification and product images download path with respect to productId and
    /// and contenttyeid. 
    /// </summary>
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="productId">Product ID</param>
    /// <param name="contentTypeID">Content type ID </param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetProductSpecsAndImages(int usercode, string productId, string _Source, string contentTypeID, string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProductList = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtProductSpecs = null;
        try
        {
            dsProductList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetProductViewContentByContentTypeIDAndProductID ", new SqlParameter("@ProductID", productId), new SqlParameter("@Source", _Source), new SqlParameter("@ContentTypeID", contentTypeID), new SqlParameter("@CountryCode", CountryCode));
            dtProductSpecs = objUtility.GenericReplace(dsProductList.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtProductSpecs;
    }

    /// <summary>
    /// Method Name   : SPPGetProductDownloadContentTypeID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 15 July 2015
    /// Description   :To get contentid for Product spect download with respect to productId and
    /// and contenttyeid. 
    /// </summary>
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="productId">Product ID</param>
    /// <param name="contentTypeID">Content Type ID</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetProductDownloadContentTypeID(int usercode, string productId, string _Source, string contentTypeID, string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProductList = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtProductSpecs = null;
        try
        {
            dsProductList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetProductDownloadContentByContentTypeIDAndProductID", new SqlParameter("@ProductID", productId), new SqlParameter("@Source", _Source), new SqlParameter("@ContentTypeID", contentTypeID), new SqlParameter("@CountryCode", CountryCode));
            dtProductSpecs = objUtility.GenericReplace(dsProductList.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtProductSpecs;
    }

    /// <summary>
    /// Method Name   : SPPGetProductContentByContentID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 15 July 2015
    /// Description   :To get Content details with respect to Content ID.
    /// </summary>
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="ContentID">>Product ID</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetProductContentByContentID(int usercode, string ContentID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProductContent = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtProductContent = null;
        try
        {
            dsProductContent = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetProductContentByContentID", new SqlParameter("@ContentID", ContentID));
            dtProductContent = objUtility.GenericReplace(dsProductContent.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtProductContent;
    }
    #endregion

    #region"Marketing Corner"

    /// <summary>
    /// Method Name   : GetMarketingCornerSubCategoryByCategoryID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 08 July 2015
    /// Description    :To Get Subcategory List by Category ID.
    /// </summary>
    /// <param name="usercode">Autogenrated UserID</param>
    /// <param name="catId">CategoryID</param>
    /// <returns>DataTable</returns>
    public DataTable GetMarketingCornerSubCategoryByCategoryID(string DealerCode, string catId)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsMCSubCat = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtMCSubCat = null;
        try
        {

            dsMCSubCat = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMarketingCornerSubCategoryListByCategoryID", new SqlParameter("@CategoryID", catId), new SqlParameter("@DealerCode", DealerCode));
            dtMCSubCat = objUtility.GenericReplace(dsMCSubCat.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objUtility != null)
            {
                objUtility = null;
            }

        }

        return dtMCSubCat;
    }


    /// <summary>
    /// Method Name   : GetMarketingCornerContentID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 08 July 2015
    /// Description    :To Get content ID with respect to subcategoryid. 
    /// </summary>
    /// <param name="usercode">Autogenrated UserID</param>
    /// <param name="subCategoryID">Sub Category ID</param>
    /// <returns>DataTable</returns>
    public DataTable GetMarketingCornerContentID(int usercode, string subCategoryID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsContent = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtContent = null;

        try
        {

            dsContent = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMarketingCornerSingleContentBySubCatID", new SqlParameter("@SubCategoryID", subCategoryID),
                        new SqlParameter("@ViewMode", "T"));
            dtContent = objUtility.GenericReplace(dsContent.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objUtility != null)
            {
                objUtility = null;
            }

        }

        return dtContent;

    }

    /// <summary>
    /// Method Name   : GetMarketingCornerVideoUrl
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 08 July 2015
    /// Description    :To Get video url with respect to contentID. 
    /// </summary>
    /// <param name="usercode">Autogenrated UserID</param>
    /// <param name="contentID">Content ID</param>
    /// <returns>DataTable</returns>
    public DataTable GetMarketingCornerVideoUrl(int usercode, string contentID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsVideoContent = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtVideoContent = null;

        try
        {

            dsVideoContent = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMarketingCornerContentByContentID", new SqlParameter("@ContentID", contentID));
            dtVideoContent = objUtility.GenericReplace(dsVideoContent.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objUtility != null)
            {
                objUtility = null;
            }

        }

        return dtVideoContent;

    }

    /// <summary>
    /// Method Name   : GetPrintAdsContent
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 09 July 2015
    /// Description    :To Get PrintAds Content.
    /// </summary>
    /// <param name="usercode">Autogenrated UserID</param>
    /// <param name="catID">Category ID</param>
    /// <param name="subCatID">SubCategory ID</param>
    /// <returns>DataTable</returns>
    public DataTable GetPrintAdsContent(int usercode, string catID, string subCatID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsPrintAdContent = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtPrintAdContent = null;

        try
        {

            dsPrintAdContent = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMarketingCornerViewContentBySubCatIDAndCatID", new SqlParameter("@CategoryID", catID), new SqlParameter("@SubCategoryID", subCatID));
            dtPrintAdContent = objUtility.GenericReplace(dsPrintAdContent.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objUtility != null)
            {
                objUtility = null;
            }

        }

        return dtPrintAdContent;

    }

    /// <summary>
    /// Method Name   : GetMarketingCornerMappedProductID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 10 July 2015
    /// Description   :To get Marketing Corner Mapped Product.
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable GetMarketingCornerMappedProductID(int usercode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet ds = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMarketingCornerMappedProductID");
            dt = objUtility.GenericReplace(ds.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }

    /// <summary>
    /// Method Name   : GetMCFilterItem
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 10 July 2015
    /// Description   :To get marketing corner filter item.
    /// </summary> 
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="productIds">List of mapped products IDS</param>
    /// <param name="filterType">Filter type</param>
    /// <returns>DataTable</returns>
    public DataTable GetMCFilterItem(int usercode, string productIds, string filterType)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsFilterItem = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtFilterItem = null;

        try
        {

            dsFilterItem = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMarketingCornerProductByProductOrCampaign", new SqlParameter("@ProductIDs", productIds), new SqlParameter("@Mode", filterType));
            dtFilterItem = objUtility.GenericReplace(dsFilterItem.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dtFilterItem;
    }

    /// <summary>
    /// Method Name   : GetMCSubCategoryByFilter
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 10 July 2015
    /// Description   :To get marketing corner subCategory
    /// with respect to  filterid,categoryid,filter type.
    /// </summary>
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="searchText">Search Text</param>
    /// <param name="categoryID">Category ID</param>
    /// <param name="filterType">Filter type</param>
    /// <returns>DataTable</returns>
    public DataTable GetMCSubCategoryByFilter(int usercode, string searchText, string categoryID, string filterType, string DealerCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsFilterItem = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtFilterItem = null;

        try
        {

            dsFilterItem = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSearchMarketingCornerSubCategory", new SqlParameter("@SearchText", searchText), new SqlParameter("@CategoryID", categoryID)
                           , new SqlParameter("@Mode", filterType), new SqlParameter("@DealerCode", DealerCode));
            dtFilterItem = objUtility.GenericReplace(dsFilterItem.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dtFilterItem;
    }

    #endregion

    #region Channel Corner

    #region Price List

    /// <summary>
    /// Function for Product Categories for Price List
    /// Function Added by Manoj Kumar on 01-July-2015
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="CategoryID">Category ID ( 0 for All )</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetPriceListCategories(int usercode, string CategoryID)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsPriceListCategories = null;
        DataTable dtPriceListCategories = null;

        try
        {
            dsPriceListCategories = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spGetPriceListCategories", new SqlParameter("@CategoryID", Convert.ToInt32(CategoryID)));
            dtPriceListCategories = objUtility.GenericReplace(dsPriceListCategories.Tables[0]);
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dtPriceListCategories;
    }

    /// <summary>
    /// Function to get Product Price List
    /// Function Added by Manoj Kumar on 01-July-2015
    /// Modified by Shyam Sunder Kumar as on 24-Dec-2015 for All Category
    /// Modifed by Ajit Kumar as on 17-Mar-2016 for Ordering of Product according to new price effective date
    /// country code change for nepal app 17 feb 2022 start [SPP_Nepal_Mearge]
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="StateID">StateID (0 for all)</param>
    /// <param name="CountryCode">CountryCode [SPP_Nepal_Mearge]</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetPriceList(string usercode, int StateID, string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsPriceList = null;
        DataTable dtPriceList = null;
        string sPathChannel = SPPUtility.ProductCenter.Replace("\\", "/");
        string ImagePath = sPathChannel + "/ProductImages/Products/Small/";
        try
        {
            dsPriceList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spGetPriceList",
                new SqlParameter("@StateID", Convert.ToInt32(StateID)),
                new SqlParameter("@CategoryID", "0"),
                new SqlParameter("@ImagePath", ImagePath),
                 new SqlParameter("@Source", "A"),
                 new SqlParameter("@DealerCode", usercode),
                   new SqlParameter("@CountryCode", CountryCode) //[SPP_Nepal_Mearge]
                );
            dtPriceList = objUtility.GenericReplace(dsPriceList.Tables[0]);
        }
        catch (Exception exc)
        {

            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dtPriceList;
    }

    #endregion

    #region Price Change announcements

    /// <summary>
    /// Function to Get Month For Price Change Announcment By Year/ Latest Month
    /// Function Added by Manoj Kumar on 03-July-2015
    /// </summary>
    /// <param name="Year">Selected Year to get months, and 0 to get years</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetMonthYear(string Year)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsYearList = null;
        DataTable dtYearList = null;
        try
        {
            dsYearList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spGetMonthYear",
                new SqlParameter("@Year", Convert.ToInt32(Year)));
            dtYearList = objUtility.GenericReplace(dsYearList.Tables[0]);
        }
        catch (Exception exc)
        {

            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dtYearList;
    }

    /// <summary>
    /// Service to get product price change announcement list
    /// Created by Manoj Kumar on 03-July-2015
    /// Changes for SPP Nepal 21 feb 2022 Amandeep start [SPP_Nepal_Mearge]
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="sStateId">StateId</param>
    /// <param name="sMonth">Month</param>
    /// <param name="sYear">Year</param>
    /// <returns>DataTable</returns>
    public DataTable SPPPriceChangeAnnouncementList(int usercode, string sStateId, string sMonth, string sYear, string DealerCode, string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsPriceChange = null;
        DataTable dtPriceChange = null;
        try
        {
            dsPriceChange = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "SP_Select_PriceDrop",
                new SqlParameter("@RefStateID", Convert.ToInt32(sStateId)),
                new SqlParameter("@Month", Convert.ToInt32(sMonth)),
                new SqlParameter("@Year", Convert.ToInt32(sYear)),
                new SqlParameter("@DealerCode", DealerCode),
                new SqlParameter("@CountryCode", CountryCode)); //[SPP_Nepal_Mearge]
            dtPriceChange = objUtility.GenericReplace(dsPriceChange.Tables[0]);
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dtPriceChange;
    }


    #endregion

    #region Dealer Type
    /// <summary>
    /// Method Name   : GetDealerTypeList
    /// Createdby     : Shyam Sunder Kumar
    /// Created On    : 29 Dec 2015
    /// Description   : Function to Get Dealer Type List
    /// </summary>
    /// <param name="vDealerTypeID">Dealer Type ID</param>
    /// <param name="vIsSOC">Is SOC</param>
    /// <returns>DataTable</returns>
    public DataTable GetDealerTypeList(string vDealerTypeID, string vIsSOC)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = new DataTable();
        try
        {
            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetDealerType", new SqlParameter("@DealerTypeID", vDealerTypeID)
                , new SqlParameter("@IsSOC", vIsSOC)).Tables[0];
            return objUtility.GenericReplace(dt);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objUtility != null)
            {
                objUtility = null;
            }
            if (dt != null)
            {
                dt.Dispose();
                dt = null;
            }
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }

    }
    #endregion Dealer Type
    #region "SchemeAnouncement"
    /// <summary>
    /// Method Name   : GetMonthsForSchemes
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 2 July 2015
    /// Description   :Service to get the month year collection.
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <returns>DataTable</returns>
    public DataTable GetMonthsForSchemes(int usercode, string source, string callby)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsMonthYearList = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtMonthYearList = null;
        try
        {
            dsMonthYearList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMonthsForSchemes", new SqlParameter("@source", source), new SqlParameter("@callby", callby));
            dtMonthYearList = objUtility.GenericReplace(dsMonthYearList.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objUtility != null)
            {
                objUtility = null;
            }

        }

        return dtMonthYearList;
    }
    /// <summary>
    /// Method Name   : GetZoneDealerCategoryID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 3 July 2015
    /// Description   :Service to get the Dealer Category ID
    /// with respect to zone Id.
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sZoneID">Zone ID</param>
    /// <returns>string</returns>
    public string GetZoneDealerCategoryID(int usercode, string sZoneID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsDealerCategoryId = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        string ZoneDealerCategoryID = string.Empty;
        try
        {
            dsDealerCategoryId = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SelectZoneDealerCategoryID", new SqlParameter("@ZoneID", sZoneID));
            dt = objUtility.GenericReplace(dsDealerCategoryId.Tables[0]);

            if (dt != null && dt.Rows.Count > 0)
            {
                ZoneDealerCategoryID = objUtility.GetCommaSepratedValue(dt, "DealerCategoryID");
            }
            else
            {
                ZoneDealerCategoryID = "301";
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return ZoneDealerCategoryID;
    }

    /// <summary>
    /// Method Name   : GetDealerCategoryID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 3 July 2015
    /// Description   :Service to get the Ref dealer categoryId.
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sDealerCode">Dealer Code</param>
    /// <returns>DataTable</returns>
    public DataTable GetDealerCategoryID(int usercode, string sDealerCode)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsDealerCategoryId = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        string DealerCategoryID = string.Empty;
        try
        {
            dsDealerCategoryId = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SelectDealerCategory", new SqlParameter("@DealerCode", sDealerCode));
            dt = objUtility.GenericReplace(dsDealerCategoryId.Tables[0]);


        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;

    }
    /// <summary>
    /// Method Name   : GetCityCategoryID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 3 July 2015
    /// Description   :Service to get the city categoryId.
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sCityID">City ID</param>
    /// <param name="sMonth">Month</param>
    /// <param name="sYear">Year</param>
    /// <returns>string</returns>
    public string GetCityCategoryID(int usercode, string sCityID, string sMonth, string sYear)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsCityCategoryId = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        string sCityCategoryId = string.Empty;
        try
        {
            dsCityCategoryId = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SelectCityCategoryId",
                                 new SqlParameter("@sMapCityId", sCityID), new SqlParameter("@sMonth", sMonth), new SqlParameter("@sYear", sYear));
            dt = objUtility.GenericReplace(dsCityCategoryId.Tables[0]);

            if (dt != null && dt.Rows.Count > 0)
            {
                sCityCategoryId = dt.Rows[0]["CityCategoryID"].ToString();
            }
            else
            {
                sCityCategoryId = "";
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return sCityCategoryId;


    }
    /// <summary>
    /// Method Name   : GetStateDealerCategoryID
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 3 July 2015
    /// Description   :Service to get the dealer categoryId
    /// with respect to stateid. 
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sStateID">State ID</param>
    /// <returns>string</returns>
    public string GetStateDealerCategoryID(int usercode, string sStateID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsStateDealerCategoryId = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        string stateDealerCategoryID = string.Empty;
        try
        {
            dsStateDealerCategoryId = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SelectStateDealerCategoryID", new SqlParameter("@StateID", sStateID));
            dt = objUtility.GenericReplace(dsStateDealerCategoryId.Tables[0]);

            if (dt != null && dt.Rows.Count > 0)
            {
                stateDealerCategoryID = objUtility.GetCommaSepratedValue(dt, "DealerCategoryID");
            }
            else
            {
                stateDealerCategoryID = "301";
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return stateDealerCategoryID;
    }
    /// <summary>
    /// Method Name   : GetDealerCategory
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 3 July 2015
    /// Description   :Service to get the dealer category. 
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sDealerCode">Dealer Code</param>
    /// <returns>DataTable</returns>
    public DataTable GetDealerCategory(int usercode, string sDealerCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsStateDealerCategoryId = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsStateDealerCategoryId = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetDealerCategory", new SqlParameter("@DealerCode", sDealerCode));
            dt = objUtility.GenericReplace(dsStateDealerCategoryId.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }
    /// <summary>
    /// Method Name   : GetListOfSchemAnnouncement
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 3 July 2015
    /// Description   :Service to get scheme data.
    /// Changes for SPP Nepal 22 feb 2022 Amandeep start [SPP_Nepal_Mearge]
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sSchemeType">Scheme Type</param>
    /// <param name="sCategoryIDList">Category ID</param>
    /// <param name="sZoneIDList">zone ID</param>
    /// <param name="sDealerCategoryIDs">Dealer Category ID</param>
    /// <param name="iMonth">Month</param>
    /// <param name="iYear">Year</param>
    /// <returns>DataTable</returns>
    public DataTable GetListOfSchemAnnouncement(int usercode, string sSchemeType, string sCategoryIDList, string sZoneIDList, string sDealerCategoryIDs, string iMonth, string iYear, string userid, string countrycode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemeData = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            //Changes for SPP Nepal 25 feb 2022 Amandeep start
            // removed sDealerCategoryIDs values becouse in other countries we are not showing category value other than India [SPP_Nepal_Mearge]
            if (countrycode != "IND")
            {
                sDealerCategoryIDs = "";
            }
            dsSchemeData = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SelectScheme"
                            , new SqlParameter("@SchemeType", sSchemeType), new SqlParameter("@CategoryIDList", sCategoryIDList)
                            , new SqlParameter("@ZoneIDList", sZoneIDList), new SqlParameter("@DelalerCategoryIDList", sDealerCategoryIDs)
                            , new SqlParameter("@Year", iYear), new SqlParameter("@Month", iMonth), new SqlParameter("@UserCode", userid)
                             , new SqlParameter("@CountryCode", countrycode));//[SPP_Nepal_Mearge]

            dt = objUtility.GenericReplace(dsSchemeData.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;
    }

    /// <summary>
    /// Method Name   : GetSchemeAnnouncementDetails
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 6 July 2015
    /// Description   :Service to get scheme data with respect to schemeid.
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="SchemeID">Scheme ID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSchemeAnnouncementDetails(int usercode, string sSchemeID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemeDetail = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemeDetail = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSchemeAnnouncementDetails"
                              , new SqlParameter("@SchemeID", sSchemeID));

            dt = objUtility.GenericReplace(dsSchemeDetail.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }

    #endregion

    #region Special Announcements

    /// <summary>
    /// Function to Get Special Announcement List by Criteria
    /// Changes made by Manoj Kumar on 06-July-2015
    /// </summary>
    /// <param name="usercode"> usercode </param>
    /// <param name="sCategoryIDList"> CategoryIDList</param>
    /// <param name="sZoneIDList"> ZoneIDList</param>
    /// <param name="sDealerCategoryIDs"> DealerCategoryIDs</param>
    /// <param name="FromDate"> FromDate</param>
    /// <param name="ToDate"> ToDate</param>
    /// <returns></returns>
    public DataTable SPPGetSpecialAnnouncementsList(int usercode, string sCategoryIDList, string sZoneIDList, string sDealerCategoryIDs, string FromDate, string ToDate, string userid)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsSpaList = null;
        DataTable dtSpaList = null;
        try
        {
            dsSpaList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spGetSpecialAnnouncementsList",
                new SqlParameter("@CategoryIDList", sCategoryIDList),
                new SqlParameter("@ZoneIDList", sZoneIDList),
                new SqlParameter("@DelalerCategoryIDList", sDealerCategoryIDs),
                new SqlParameter("@FromDate", FromDate),
                new SqlParameter("@ToDate", ToDate),
                new SqlParameter("@UserCode", userid)
                );
            dtSpaList = objUtility.GenericReplace(dsSpaList.Tables[0]);
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSpaList;
    }

    /// <summary>
    /// Function to get Special Announcement Detail by Announcement ID
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="AnnouncementID">Announcement ID</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetSpecialAnnouncementDetails(int usercode, string AnnouncementID)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsSpaList = null;
        DataTable dtSpaList = null;
        try
        {
            dsSpaList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spGetSpecialAnnouncementDetails",
                new SqlParameter("@AnnouncementID", Convert.ToInt32(AnnouncementID))
                );
            dtSpaList = objUtility.GenericReplace(dsSpaList.Tables[0]);
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSpaList;
    }

    #endregion Special Announcements

    #region Price Protection Payout
    /// <summary>
    /// Function to get SPP Get Price Protection Payout Data
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="SUserid">Userid</param>
    /// <param name="sFromDate">FromDate</param>
    /// <param name="sToDate">ToDate</param>
    /// <param name="sDateType">DateType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetPriceProtectionPayoutData(int usercode, string sUserid, string sFromDate, string sToDate, string sDateType, string sLotID)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsPPPList = null;
        DataTable dtPPPList = null;

        try
        {
            dsPPPList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "SP_Select_SAM_CC_PD_SellInPayout_Data",
                new SqlParameter("@UserCode", sUserid),

                new SqlParameter("@FromDate", sFromDate),
                new SqlParameter("@ToDate", sToDate),
                new SqlParameter("@DateType", sDateType),
                new SqlParameter("@LotID", Convert.ToInt32(sLotID))
                );
            dtPPPList = objUtility.GenericReplace(dsPPPList.Tables[0]);
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtPPPList;
    }
    #region code written by Deepika Bhatia on 19-April-2016 to get various Reports(SPD Login)

    /// <summary>
    /// Method Name   : GetSPDLoginDealerWiseReport
    /// Createdby     : Deepika Bhatia
    /// Created On    : 19 April 2016
    /// Description   :Service to get Dealer Wise Report(SPD Login)
    /// data.
    /// </summary>
    /// /// <param name="sUserID">UserID type</param>
    /// <param name="sUserType">UserType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSPDLoginDealerWiseReport(string sUserID, string sUserType, string sLotID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_UserTypeWiseHierarchyPDPayout",
                 new SqlParameter("@UserID", sUserID),
                 new SqlParameter("@UserType", sUserType),
                  new SqlParameter("@LotID", sLotID)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }

    /// <summary>
    /// Method Name   : GetSPDLoginDealerReport
    /// Createdby     : Deepika Bhatia
    /// Created On    : 19 April 2016
    /// Description   : Service to get Dealer Payout Report(SPD Login)
    /// data.
    /// </summary>
    /// /// <param name="sDealerCode">DealerCode</param>
    /// <param name="sFromDate">FromDate</param>
    /// <param name="sToDate">ToDate</param>
    /// <param name="sDateType">DateType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSPDLoginDealerWiseReport(string sDealerCode, string sFromDate, string sToDate, string sDateType, string sLotID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_SAM_CC_PD_SellInPayout_Data",
                 new SqlParameter("@UserCode", sDealerCode),
                 new SqlParameter("@FromDate", sFromDate),
                 new SqlParameter("@ToDate", sToDate),
                 new SqlParameter("@DateType", sDateType),
                  new SqlParameter("@LotID", sLotID)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }





    /// <summary>
    /// Method Name   : GetSPDLoginSRDWiseDealerReport
    /// Createdby     : Deepika Bhatia
    /// Created On    : 19 April 2016
    /// Description   :Service to get Dealer Wise Report(SPD Login)
    /// data.
    /// </summary>
    /// /// <param name="sUserID">UserID type</param>
    /// <param name="sUserType">UserType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSPDLoginSRDWiseDealerReport(string sUserID, string sUserType, string sLotID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;
        DataTable dtuser = new DataTable();


        try
        {
            dtuser = GetUserDetails(sUserID);
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_UserTypeWiseHierarchyPDPayout",
                 new SqlParameter("@UserID", dtuser.Rows[0]["UserId"].ToString()),
                 new SqlParameter("@UserType", sUserType),
                  new SqlParameter("@LotID", sLotID)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }




    /// <summary>
    /// Method Name   : GetSPDLoginDealerReport
    /// Createdby     : Deepika Bhatia
    /// Created On    : 19 April 2016
    /// Description   : Service to get Dealer Payout Report(SPD Login)
    /// data.
    /// </summary>
    /// /// <param name="sDealerCode">DealerCode</param>
    /// <param name="sFromDate">FromDate</param>
    /// <param name="sToDate">ToDate</param>
    /// <param name="sDateType">DateType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSPDLoginDealerReport(string sDealerCode, string sFromDate, string sToDate, string sDateType, string sLotID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_SAM_CC_PD_SellInPayout_Data",
                 new SqlParameter("@UserCode", sDealerCode),
                 new SqlParameter("@FromDate", sFromDate),
                 new SqlParameter("@ToDate", sToDate),
                 new SqlParameter("@DateType", sDateType),
                  new SqlParameter("@LotID", sLotID)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }

    /// <summary>
    /// Method Name   : GetSPDLoginPDWiseReport
    /// Createdby     : Deepika Bhatia
    /// Created On    : 20 April 2016
    /// Description   :Service to get Dealer Wise Report(SPD Login)
    /// data.
    /// </summary>
    /// /// <param name="sUserID">UserID type</param>
    /// <param name="sUserType">UserType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSPDLoginPDWiseReport(string sUserID, string sUserType, string sLotID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;
        DataTable dtuser = new DataTable();


        try
        {
            dtuser = GetUserDetails(sUserID);
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_UserTypeWiseHierarchyPDPayout",
                 new SqlParameter("@UserID", dtuser.Rows[0]["UserId"].ToString()),
                 new SqlParameter("@UserType", sUserType),
                  new SqlParameter("@LotID", sLotID)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }

    /// <summary>
    /// Method Name   : GetSPDLoginSRDWiseDealerReport
    /// Createdby     : Deepika Bhatia
    /// Created On    : 19 April 2016
    /// Description   :Service to get Dealer Wise Report(SPD Login)
    /// data.
    /// </summary>
    /// /// <param name="sUserID">UserID type</param>
    /// <param name="sUserType">UserType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSPDLoginPDWiseReport(string sUserID, string sFromDate, string sToDate, string sDateType, string sUserType, string sHierarchyType)
    {


        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;



        try
        {

            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_SAM_CC_PD_ListUniquePriceDrops",
                 new SqlParameter("@UserID", sUserID),
                 new SqlParameter("@FromDate", sFromDate),
                  new SqlParameter("@ToDate", sToDate),
                   new SqlParameter("@DateType", sDateType),
                  new SqlParameter("@UserType", sUserType),
                  new SqlParameter("@HierarchyType", sHierarchyType)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }


    #endregion

    #region code written by Deepika Bhatia on 25-April-2016 to get SPD Payout (HO Login)
    /// <summary>
    /// Method Name   : GetHOLoginSPDPayout
    /// Createdby     : Deepika Bhatia
    /// Created On    : 25 April 2016
    /// Description   :Service to get SPD Payout(HO Login)
    /// data.
    /// </summary>
    /// /// <param name="sFromDate">From Date</param>
    /// <param name="sToDate">To Date</param>
    /// <param name="sDateType">Date Type</param>
    /// <returns>DataTable</returns>
    public DataTable GetHOLoginSPDPayout(string sFromDate, string sToDate, string sDateType)
    {


        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;
        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_SAM_CC_PDHO_SellInPayout_Data",
               new SqlParameter("@FromDate", sFromDate),
                 new SqlParameter("@ToDate", sToDate),
                  new SqlParameter("@DateType", sDateType)
                );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }
    #endregion
    #region code written by Ajit  Kumar on 20-April- 2016 to SRD Login
    /// <summary>
    /// Method Name   : GetSRDLoginYourPayoutReport
    /// Createdby     : Ajit Kumar
    /// Created On    : 19 April 2016
    /// Description   : Service to get Your Payout Report(SRD Login)
    /// data.
    /// Changes for SPP Nepal 17 feb 2022 Amandeep start [SPP_Nepal_Mearge]
    /// </summary>
    /// /// <param name="sDealerCode">sUserCode</param>
    /// <param name="sFromDate">FromDate</param>
    /// <param name="sToDate">ToDate</param>
    /// <param name="sDateType">DateType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSRDLoginYourPayoutReport(string sUserCode, string sFromDate, string sToDate, string sDateType, string sLotID, string CountryCode)

    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_SAM_CC_PD_SellInPayout_Data",
                 new SqlParameter("@UserCode", sUserCode),
                 new SqlParameter("@FromDate", sFromDate),
                 new SqlParameter("@ToDate", sToDate),
                 new SqlParameter("@DateType", sDateType),
                 new SqlParameter("@LotID", sLotID),
                 new SqlParameter("@CountryCode", CountryCode) //[SPP_Nepal_Mearge]
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }


    /// <summary>
    /// Method Name   : GetSRDLoginDealerWiseReport
    /// Createdby     : Ajit Kumar
    /// Created On    : 20 April 2016
    /// Description   :Service to get Dealer Wise Report(SRD Login)
    /// data.
    /// </summary>
    /// /// <param name="sUserID">UserID type</param>
    /// <param name="sUserType">UserType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSRDLoginDealerWiseReport(string sUserID, string sUserType, string sLotID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_UserTypeWiseHierarchyPDPayout",
                 new SqlParameter("@UserID", sUserID),
                 new SqlParameter("@UserType", sUserType),
                  new SqlParameter("@LotID", sLotID)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }



    /// <summary>
    /// Method Name   : GetSRDLoginDealerWiseReport
    /// Createdby     : Ajit Kumar
    /// Created On    : 20 April 2016
    /// Description   :Service to get Dealer Wise Report(SRD Login)
    /// data.
    /// </summary>
    /// /// <param name="sUserID">UserID type</param>
    /// <param name="sUserType">UserType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSRDLoginPDWiseReportDealer(string sUserID, string sUserType, string sLotID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;
        DataTable dtuser = new DataTable();
        try
        {
            dtuser = GetUserDetails(sUserID);

            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_UserTypeWiseHierarchyPDPayout",
                 new SqlParameter("@UserID", dtuser.Rows[0]["UserId"].ToString()),
                 new SqlParameter("@UserType", sUserType),
                  new SqlParameter("@LotID", sLotID)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }

    /// <summary>
    /// Method Name   : GetSRDLoginModelWiseDealerReport
    /// Createdby     : Ajit Kumar
    /// Created On    : 20 April 2016
    /// Description   : Service to get Dealer Payout Report(SRD Login) Model wise
    /// data.
    /// </summary>
    /// /// <param name="sDealerCode">DealerCode</param>
    /// <param name="sFromDate">FromDate</param>
    /// <param name="sToDate">ToDate</param>
    /// <param name="sDateType">DateType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable GetSRDLoginModelWiseDealerReport(string sDealerCode, string sFromDate, string sToDate, string sDateType, string sLotID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_SAM_CC_PD_SellInPayout_Data",
                 new SqlParameter("@UserCode", sDealerCode),
                 new SqlParameter("@FromDate", sFromDate),
                 new SqlParameter("@ToDate", sToDate),
                 new SqlParameter("@DateType", sDateType),
                 new SqlParameter("@LotID", sLotID)
                   );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }





    /// <summary>
    /// Method Name   : ListUniquePriceDropsForSRD
    /// Createdby     : Ajit Kumar
    /// Created On    : 19 April 2016
    /// Description   : Service to get Your Payout Report(PDP Wise SRD Login) Level-1
    /// data.
    /// </summary>
    /// /// <param name="sDealerCode">sUserCode</param>
    /// <param name="sFromDate">FromDate</param>
    /// <param name="sToDate">ToDate</param>
    /// <param name="sDateType">DateType</param>
    /// <param name="sUserType">UserType</param>
    /// <param name="sHierarchyType">HierarchyType</param>
    /// <returns>DataTable</returns>
    public DataTable ListUniquePriceDropsForSRD(string sUserID, string sFromDate, string sToDate, string sDateType, string sUserType, string sHierarchyType)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_SAM_CC_PD_ListUniquePriceDrops",
                 new SqlParameter("@UserID", sUserID),
                 new SqlParameter("@FromDate", sFromDate),
                 new SqlParameter("@ToDate", sToDate),
                 new SqlParameter("@DateType", sDateType),
                 new SqlParameter("@UserType", sUserType),
                  new SqlParameter("@HierarchyType", sHierarchyType)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }


    /// <summary>
    /// Method Name   : ListUserTypeWiseHierarchyPDPayout
    /// Createdby     : Ajit Kumar
    /// Created On    : 19 April 2016
    /// Description   :Service to get PDP Hierarchy wise(SRD Login)
    /// data.
    /// </summary>
    /// /// <param name="sUserID">UserID type</param>
    /// <param name="sUserType">UserType</param>
    /// <param name="sLotID">LotID</param>
    /// <returns>DataTable</returns>
    public DataTable ListUserTypeWiseHierarchyPDPayout(string sUserID, string sUserType, string sLotID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemePayoutDetails = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_UserTypeWiseHierarchyPDPayout",
                 new SqlParameter("@UserID", sUserID),
                 new SqlParameter("@UserType", sUserType),
                  new SqlParameter("@LotID", sLotID)
                 );
            dtSchemePayoutDetails = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }


        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemePayoutDetails;
    }


    #endregion




    #endregion Price Protection Payout

    #region "Scheme Payout"

    /// <summary>
    /// Method Name   : SPPGetSchemeReportType
    /// Createdby     : Ajit Kr
    /// Created On    : 08 Mar 2016
    /// Description    :To get Scheme Report Type.
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable SPPGetSchemeReportType(string UserTypeId, string SubUserTypeId, string RefReportId, string ReportType)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemeReportType = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSchemeReportType = null;
        try
        {
            dsSchemeReportType = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPAppListSchemeReportType", new SqlParameter("@UserTypeID", UserTypeId), new SqlParameter("@SubUserTypeID", SubUserTypeId), new SqlParameter("@RefReportID", RefReportId), new SqlParameter("@ReportType", ReportType));
            dtSchemeReportType = objUtility.GenericReplace(dsSchemeReportType.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSchemeReportType;
    }

    /// <summary>
    /// Method Name   : GetSchemePayoutDetails
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 7 July 2015
    /// Description   :Service to get scheme payout data.
    /// Changes for spp Nepal 17 feb 2022 Amandeep Singh start [SPP_Nepal_Mearge]
    /// </summary>
    /// <param name="sDealerCode">Dealer Code</param>
    /// <param name="sFromDate">From Date</param>
    /// <param name="sToDate">To Date</param>
    /// <param name="sDateType">Date Type</param>
    /// <param name="CountryCode">CountryCode [SPP_Nepal_Mearge]</param>
    /// <returns>DataTable</returns>
    public DataTable GetSchemePayoutDetails(int usercode, string sDealerCode, string sFromDate, string sToDate, string sDateType, string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_SAM_CC_SellInPayout_Data",
                                 new SqlParameter("@DealerCode", sDealerCode), new SqlParameter("@FromDate", sFromDate), new SqlParameter("@ToDate", sToDate),
                                  new SqlParameter("@DateType", sDateType), new SqlParameter("@CountryCode", CountryCode)); //[SPP_Nepal_Mearge]
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }

    public DataTable SDGetSchemePayoutDetails(int usercode, string sDealerCode, string sFromDate, string sToDate, string sDateType, string sReportType)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SD_DealerSellInPayout_Data",
                                 new SqlParameter("@DealerCode", sDealerCode), new SqlParameter("@FromDate", sFromDate), new SqlParameter("@ToDate", sToDate),
                                  new SqlParameter("@DateType", sDateType),
                                  new SqlParameter("@ReportType", sReportType));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }

    #region code written by Anil Verma on 9- March- 2016 to get report of HO level(SPD to dealer) payout by scheme type


    /// <summary>
    /// Method Name   : GetSchemePayoutDetailsBySchemtype
    /// Createdby     : Anil Verma
    /// Created On    : 9 March 2016
    /// Description   :Service to get scheme payout details beased on scheme type
    /// data.
    /// </summary>
    /// /// <param name="schemetype">Scheme type</param>
    /// <param name="sDealerCode">Dealer Code</param>
    /// <param name="sFromDate">From Date</param>
    /// <param name="sToDate">To Date</param>
    /// <param name="sDateType">Date Type</param>
    /// <returns>DataTable</returns>
    public DataTable GetSchemePayoutDetailsBySchemtype(string schemetype, int usercode, string sFromDate, string sToDate, string sDateType)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ListUniquePayoutSchemes",
                 new SqlParameter("@SchemeType", schemetype),
                 new SqlParameter("@DateType", sDateType),
                 new SqlParameter("@FromDate", sFromDate),
                 new SqlParameter("@ToDate", sToDate),
                 new SqlParameter("@UserID", usercode));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }

    /// <summary>
    /// Method Name   : GetNDPayout
    /// Createdby     : Anil Verma
    /// Created On    : 9 March 2016
    /// Description   : Service to get HO Level ND To Dealer Payout
    /// data.
    /// </summary>
    /// <param name="schemecode">Scheme Code</param>    
    /// <returns>DataTable</returns>
    public DataTable GetNDPayout(string schemecode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWise_HOLevel_NDPayout",
                 new SqlParameter("@SchemeCode", schemecode));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }


    /// <summary>
    /// Method Name   : GetNDSDealerSchemePayout
    /// Createdby     : Anil Verma
    /// Created On    : 9 March 2016
    /// Description   : Service to get HO Level Unique Payout Schemes for ND to Dealers
    /// data.
    /// </summary>
    /// <param name="schemecode">Scheme Code</param>    
    /// /// <param name="ndcode">Nd Code</param> 
    /// <returns>DataTable</returns>
    public DataTable GetNDSDealerSchemePayout(string schemecode, string ndcode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_NDSDealerSchemePayout",
                 new SqlParameter("@SchemeCode", schemecode),
                 new SqlParameter("@UserID", ndcode)
                 );
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }

    #endregion


    #region code written by Anil Verma on 11- March- 2016 to get report of SRD Login  Dealer Wise Report

    /// <summary>
    /// Method Name   : GetRDWiseDealerPayout
    /// Createdby     : Anil Verma
    /// Created On    : 11 March 2016
    /// Description   :Service to get dealer wise report
    /// data.
    /// </summary>
    ///<param name="RDSID">RDSID</param>    
    /// <returns>DataTable</returns>
    public DataTable GetRDWiseDealerPayout(string RDSID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_RDWiseDealerPayout",
                 new SqlParameter("@RDID", RDSID));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }



    /// <summary>
    /// Method Name   : GetSchemePayoutDetailsBySchemtype
    /// Createdby     : Anil Verma
    /// Created On    : 11 March 2016
    /// Description   :Service to get scheme Sell in payout data based on dealer code
    /// data.
    /// </summary>    
    /// <param name="DealerCode">Dealer Code</param>
    /// <param name="sFromDate">From Date</param>
    /// <param name="sToDate">To Date</param>
    /// <param name="sDateType">Date Type</param>
    /// <returns>DataTable</returns>
    public DataTable GetSRDSellInPayoutData(string DealerCode, string sFromDate, string sToDate, string sDateType)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Select_SAM_CC_SellInPayout_Data",

                 new SqlParameter("@DateType", sDateType),
                 new SqlParameter("@FromDate", sFromDate),
                 new SqlParameter("@ToDate", sToDate),
                 new SqlParameter("@DealerCode", DealerCode));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }

    #endregion


    #region code written by Anil Verma on 14- March- 2016 to ZSM Login  Scheme Wise Report




    /// <summary>
    /// Method Name   : GetSalesHierarchyUniquePayoutSchemes
    /// Createdby     : Anil Verma
    /// Created On    : 11 March 2016
    /// Description   :Service to get scheme Sell in payout data based on dealer code    
    /// </summary>    
    /// <param name="DealerCode">Dealer Code</param>
    /// <param name="sFromDate">From Date</param>
    /// <param name="sToDate">To Date</param>
    /// <param name="sDateType">Date Type</param>
    /// <returns>DataTable</returns>
    public DataTable GetSalesHierarchyUniquePayoutSchemes1(string schemtype, string sDateType, string sFromDate, string sToDate, string zsmcode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ListSalesHierarchyUniquePayoutSchemes",


                new SqlParameter("@SchemeType", schemtype),
                 new SqlParameter("@DateType", sDateType),
                 new SqlParameter("@FromDate", sFromDate),
                 new SqlParameter("@ToDate", sToDate),
                 new SqlParameter("@UserName", zsmcode));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }


    /// <summary>
    /// Method Name   : GetSchemeWiseZSMWiseABMPayout
    /// Createdby     : Anil Verma
    /// Created On    : 14 March 2016
    /// Description   :Service to get Scheme Wise ZSM Wise ABMPayout
    /// data.
    /// </summary>
    ///<param name="zsmcode">zsmcode</param>    
    ///<param name="schemecode">schemecode</param>    
    /// <returns>DataTable</returns>
    public DataTable GetSchemeWiseZSMWiseABMPayout(string zsmcode, string schemecode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWiseZSMWiseABMPayout",

                new SqlParameter("@SchemeCode", schemecode),
                new SqlParameter("@ZSMCode", zsmcode));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }




    /// <summary>
    /// Method Name   : GetZSMSchemeWiseABMWiseDealerPayout
    /// Createdby     : Anil Verma
    /// Created On    : 14 March 2016
    /// Description   :Service to get ZSM Scheme Wise ABMWise DealerPayout
    /// data.
    /// </summary>
    ///<param name="zsmcode">zsmcode</param>    
    ///<param name="schemecode">schemecode</param>    
    /// <returns>DataTable</returns>
    public DataTable GetZSMSchemeWiseABMWiseDealerPayout(string abmcode, string schemecode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWiseABMWiseDealerPayout",

                new SqlParameter("@SchemeCode", schemecode),
                new SqlParameter("@UserName", abmcode));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }


    #endregion


    #region code written by Anil Verma on 15- March- 2016 to RSM Login  Scheme Wise Report




    /// <summary>
    /// Method Name   : GetSalesHierarchyUniquePayoutSchemesForRSM
    /// Createdby     : Anil Verma
    /// Created On    : 15 March 2016
    /// Description   : Service to get Sales Hierarchy Unique Payout Schemes 
    /// </summary>    
    /// <param name="schemtype">schemtype</param>
    /// <param name="DealerCode">Dealer Code</param>
    /// <param name="sFromDate">From Date</param>
    /// <param name="sToDate">To Date</param>
    /// <param name="sDateType">Date Type</param>
    /// <returns>DataTable</returns>
    public DataTable GetSalesHierarchyUniquePayoutSchemesForRSM(string schemtype, string sDateType, string sFromDate, string sToDate, string RSMCODE)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ListSalesHierarchyUniquePayoutSchemes",


            new SqlParameter("@SchemeType", schemtype),
            new SqlParameter("@DateType", sDateType),
            new SqlParameter("@FromDate", sFromDate),
            new SqlParameter("@ToDate", sToDate),
            new SqlParameter("@UserName", RSMCODE));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }


    /// <summary>
    /// Method Name   : GetSchemeWiseRSMWiseZSMPayoutRSM
    /// Createdby     : Anil Verma
    /// Created On    : 15 March 2016
    /// Description   : Service to get RSM Wise ZSM Payout
    /// data.
    /// </summary>
    ///<param name="zsmcode">zsmcode</param>    
    ///<param name="schemecode">schemecode</param>    
    /// <returns>DataTable</returns>
    public DataTable GetSchemeWiseRSMWiseZSMPayoutRSM(string rsmcode, string schemecode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWiseRSMwiseZSMPayout",

                new SqlParameter("@SchemeCode", schemecode),
                new SqlParameter("@RSMCode", rsmcode));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }


    /// <summary>
    /// Method Name   : GetSchemeWiseZSMWiseABMPayoutRSM
    /// Createdby     : Anil Verma
    /// Created On    : 15 March 2016
    /// Description   :Service to get ZSM Wise ABMPayout data.    
    /// </summary>
    ///<param name="zsmcode">zsmcode</param>    
    ///<param name="schemecode">schemecode</param>    
    /// <returns>DataTable</returns>
    public DataTable GetSchemeWiseZSMWiseABMPayoutRSM(string zsmcode, string schemecode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWiseZSMWiseABMPayout",

                new SqlParameter("@SchemeCode", schemecode),
                new SqlParameter("@ZSMCode", zsmcode));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }


    /// <summary>
    /// Method Name   : GetZSMSchemeWiseABMWiseDealerPayoutonRSMLogin
    /// Createdby     : Anil Verma
    /// Created On    : 15 March 2016
    /// Description   :Service to get ZSM Wise ABMPayout data.    
    /// </summary>
    ///<param name="abmcode">abmcode</param>    
    ///<param name="schemecode">schemecode</param>    
    /// <returns>DataTable</returns>
    public DataTable GetZSMSchemeWiseABMWiseDealerPayoutonRSMLogin(string abmcode, string schemecode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWiseABMWiseDealerPayout",

                new SqlParameter("@SchemeCode", schemecode),
                new SqlParameter("@UserName", abmcode));
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }

    #endregion

    #region Shyam Sunder Kumar
    /// <summary>
    /// Method Name   : GetSPDWisePayout
    /// Createdby     : Shyam Sunder Kumar
    /// Created On    : 09 Mar 2016
    /// Description   : Service to get SPD wise Payout [HO Login Level 1]
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable GetSPDWisePayout()
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_NDWisePayout");
            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }


    /// <summary>
    /// Method Name   : GetSPDWiseSRDPayout
    /// Createdby     : Shyam Sunder Kumar
    /// Created On    : 09 Mar 2016
    /// Description   : Service to get SPD wise Payout [HO Login Level 2]
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable GetSPDWiseSRDPayout(string vSPDCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = new DataTable();
        DataTable dtuser = new DataTable();

        try
        {
            dtuser = GetUserDetails(vSPDCode);

            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_NDWiseRDPayout",
                                 new SqlParameter("@NDID", dtuser.Rows[0]["UserId"].ToString()));

            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }

    /// <summary>
    /// Method Name   : GetSPDWiseSRDPayout
    /// Createdby     : Shyam Sunder Kumar
    /// Created On    : 09 Mar 2016
    /// Description   : Service to get SPD wise Payout [HO Login Level 2]
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable GetSPDSRDWiseDealerPayout(string vSRDCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = new DataTable();
        DataTable dtuser = new DataTable();

        try
        {
            dtuser = GetUserDetails(vSRDCode);

            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_RDWiseDealerPayout",
                                 new SqlParameter("@RDID", dtuser.Rows[0]["UserId"].ToString()));

            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }


    /// <summary>
    /// Method Name   : GetSalesHierarchyUniquePayoutSchemes
    /// Createdby     : Shyam Sunder Kumar
    /// Created On    : 11 Mar 2016
    /// Description   : Service to get Scheme Wise Report [ABM Login Level 1]
    /// </summary>
    /// <param name="vSchemeType">Scheme Type</param>
    /// <param name="vDateType">Date Type</param>
    /// <param name="vFromDate">From Date</param>
    /// <param name="vToDate">To Date</param>
    /// <param name="vUserName">User Name</param>
    /// <returns>DataTable</returns>
    public DataTable GetSalesHierarchyUniquePayoutSchemes(string vSchemeType, string vDateType, string vFromDate, string vToDate, string vUserName)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = new DataTable();
        try
        {

            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ListSalesHierarchyUniquePayoutSchemes",
                 new SqlParameter("@SchemeType", vSchemeType),
                 new SqlParameter("@DateType", vDateType),
                 new SqlParameter("@FromDate", vFromDate),
                 new SqlParameter("@ToDate", vToDate),
                 new SqlParameter("@UserName", vUserName));

            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }

    /// <summary>
    /// Method Name   : SP_SchemeWiseABMWiseDealerPayout
    /// Createdby     : Shyam Sunder Kumar
    /// Created On    : 14 Mar 2016
    /// Description   : Service to get Scheme Wise Report [ABM Login Level 1]
    /// </summary>
    /// <param name="vSchemeCode">Scheme Code</param>
    /// <param name="vABMCode">ABM Code</param>
    /// <returns>DataTable</returns>
    public DataTable GetSchemeWiseABMWiseDealerPayout(string vSchemeCode, string vABMCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemePayoutDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = new DataTable();
        try
        {

            dsSchemePayoutDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWiseABMWiseDealerPayout",
                 new SqlParameter("@SchemeCode", vSchemeCode),
                 new SqlParameter("@UserName", vABMCode)
                 );

            dt = objUtility.GenericReplace(dsSchemePayoutDetails.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }
    #endregion

    #region  Code written By Ajit Kumar dated:09-Mar-2016 for Schemwise Report(SRD To Dealer) Scheme Payout [HO Login]
    /// <summary>
    /// Method Name       : SPPGetRDSchemes
    /// Createdby         : Ajit Kr
    /// /// Created On    : 09 Mar 2016
    /// Description       :Service to get SRD Scheme wise Payout [HO Login Level 1]
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable SPPGetRDSchemes(string sUserScheme, string sDateType, string sFromDate, string sToDate, string sUserID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsRDSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtRDSchemes = null;
        try
        {
            dsRDSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ListUniquePayoutSchemes",
                new SqlParameter("@SchemeType", sUserScheme), new SqlParameter("@DateType", sDateType),
                new SqlParameter("@FromDate", sFromDate), new SqlParameter("@ToDate", sToDate), new SqlParameter("@UserID", sUserID));
            //  if(dtRDSchemes!=null && dsRDSchemes.Tables.Count>0)
            dtRDSchemes = objUtility.GenericReplace(dsRDSchemes.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtRDSchemes;
    }
    /// <summary>
    /// Method Name     : SPPGetSchemeWiseNDPayout
    /// Createdby       : Ajit Kr
    /// /// Created On  : 09 Mar 2016
    /// Description     :Service to get Scheme Wise SPD Payout [HO Login Level 2]
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable SPPGetSchemeWiseNDPayout(string SchemeCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsRDSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtRDSchemes = null;
        try
        {
            dsRDSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWiseNDPayout",
                new SqlParameter("@SchemeCode", SchemeCode));
            dtRDSchemes = objUtility.GenericReplace(dsRDSchemes.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtRDSchemes;
    }

    /// <summary>
    /// Method Name   : SPPGetHOSchemeWiseNDWiseRDPayout
    /// Createdby     : Ajit Kr
    /// Created On    : 09 Mar 2016
    /// Description    :Service to get   Scheme Wise SRD  Payout [HO Login Level 3]
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable SPPGetHOSchemeWiseNDWiseRDPayout(string vSchemeCode, string vSPDCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsRDSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtRDSchemes = null;
        DataTable dtuser = null;
        string vSPDID = "0";
        try
        {
            dtuser = GetUserDetails(vSPDCode);
            if (dtuser != null && dtuser.Rows.Count > 0)
            {
                vSPDID = dtuser.Rows[0]["UserID"].ToString();
            }

            dsRDSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWiseNDWiseRDPayout",
                new SqlParameter("@SchemeCode", vSchemeCode), new SqlParameter("@NDID", vSPDID));

            dtRDSchemes = objUtility.GenericReplace(dsRDSchemes.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtRDSchemes;
    }

    /// <summary>
    /// Method Name   : SPPGetSchemeWiseDealerPayout
    /// Createdby     : Ajit Kr
    /// /// Created On : 09 Mar 2016
    /// Description    :Service to get Scheme Wise Dealer Payout [HO Login Level 4]
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable SPPGetSchemeWiseDealerPayout(string vSchameCode, string vSRDCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsRDSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtRDSchemes = null;
        DataTable dtuser = null;
        string vSRDID = "0";
        try
        {
            dtuser = GetUserDetails(vSRDCode);
            if (dtuser != null && dtuser.Rows.Count > 0)
            {
                vSRDID = dtuser.Rows[0]["UserID"].ToString();
            }

            dsRDSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_SchemeWiseRDWiseDealerPayout",
                new SqlParameter("@SchemeCode", vSchameCode), new SqlParameter("@UserID", vSRDID));
            dtRDSchemes = objUtility.GenericReplace(dsRDSchemes.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtRDSchemes;
    }


    #endregion
    #region Sandeep Kaur
    /// <summary>
    /// Method Name   : GetABMZSMRSMWiseRDList
    /// Createdby     : Sandeep Kaur
    /// Created On    : 11 Mar 2016
    /// Description   : Service to get SRD wise Payout [ABM Login Level 1]
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable GetABMZSMRSMWiseRDList(string sHierarchyType, string sUserName)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsRDSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtRDSchemes = null;
        try
        {
            dsRDSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ABMZSMRSMwiseRDList",
                new SqlParameter("@HierarchyType", sHierarchyType), new SqlParameter("@UserName", sUserName));
            dtRDSchemes = objUtility.GenericReplace(dsRDSchemes.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtRDSchemes;
    }
    #endregion

    #region "Dealer Wise Report Deepika"
    public DataTable GetABMWiseDealerPayout(string sUserName)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsRDSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtABMWiseDealerPayout = null;

        try
        {

            dsRDSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ListABMDealers",
           new SqlParameter("@UserName", sUserName));
            dtABMWiseDealerPayout = objUtility.GenericReplace(dsRDSchemes.Tables[0]);
        }
        catch (Exception ex)
        {

            throw ex;
        }
        return dtABMWiseDealerPayout;
    }

    #endregion "Dealer Wise Report"

    #region Code written By Ajit For ABM Wise Report Scheme Payout [ZSM Login]
    /// <summary>
    /// Method Name   : GetZSMABMWisePayout
    /// Createdby     : Ajit Kumar
    /// Created On    : 14 March 2016
    /// Description   :Service to get ABM Wise Report
    /// data.
    /// </summary>
    /// /// <param name="sUserName">sUserName</param>
    /// <returns>DataTable</returns>
    public DataTable GetZSMABMWisePayout(string sUserName)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsABMSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtABMSchemes = null;
        try
        {
            dsABMSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ListZSMwiseABM",
                 new SqlParameter("@UserName", sUserName));
            dtABMSchemes = objUtility.GenericReplace(dsABMSchemes.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtABMSchemes;
    }
    /// <summary>
    /// Method Name   : GetZSMABMWiseDealerPayout
    /// Createdby     : Ajit Kumar
    /// Created On    : 14 March 2016
    /// Description   :Service to get ABM Wise Dealer Report
    /// data.
    /// </summary>
    /// /// <param name="sUserName">sUserName</param>
    /// <returns>DataTable</returns>
    public DataTable GetZSMABMWiseDealerPayout(string sUserName)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsABMSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtABMSchemes = null;
        try
        {
            dsABMSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ABMWiseDealerPayout",
                 new SqlParameter("@UserName", sUserName));
            dtABMSchemes = objUtility.GenericReplace(dsABMSchemes.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtABMSchemes;
    }
    #endregion

    #region Code written By Ajit For ZSM Wise Report Scheme Payout [RSM Login]
    /// <summary>
    /// Method Name   : GetRSMZSMWisePayout
    /// Createdby     : Ajit Kumar
    /// Created On    : 14 March 2016
    /// Description   :Service to get ZSM Wise Report
    /// data.
    /// </summary>
    /// /// <param name="sUserName">sUserName</param>
    /// <returns>DataTable</returns>
    public DataTable GetRSMZSMWisePayout(string sUserName)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsRSMSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtRSMSchemes = null;
        try
        {
            dsRSMSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ListRSMwiseZSM",
                 new SqlParameter("@UserName", sUserName));
            dtRSMSchemes = objUtility.GenericReplace(dsRSMSchemes.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtRSMSchemes;
    }
    /// <summary>
    /// Method Name   : GetRSMZSMWiseABMPayout
    /// Createdby     : Ajit Kumar
    /// Created On    : 14 March 2016
    /// Description   :Service to get ZSM Wise Report
    /// data.
    /// </summary>
    /// /// <param name="sUserName">sUserName</param>
    /// <returns>DataTable</returns>
    public DataTable GetRSMZSMWiseABMPayout(string zSMCode)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsRSMSchemes = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtRSMSchemes = null;
        try
        {
            dsRSMSchemes = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_ZSMwiseABMPayout",
                 new SqlParameter("@ZSMCode", zSMCode));
            dtRSMSchemes = objUtility.GenericReplace(dsRSMSchemes.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtRSMSchemes;
    }
    #endregion

    #endregion

    /// <summary>
    /// DataLayer to Get Policy and Guideline
    /// Added by Shyam Sunder Kumar as on 09-12-2020
    /// </summary>
    /// <returns>DataSet</returns>
    public DataSet GetPolicyandGuideline()
    {
        DataLayer objDataLayer = new DataLayer();
        try
        {
            return SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetSPGViewableContent");
        }
        catch (Exception ex)
        {
            throw new Exception("Error in GetPolicyandGuideline. Error Details : " + ex.Message);
        }
        finally
        {
            objDataLayer = null;
        }

    }
    #endregion Channel Corner

    #region "EDM/SMS"


    #region Count UnRead Inbox SMSMessages 21-Mar-2016 Ajit Kumar
    /// <summary>
    /// Method Name   : UnReadInboxMessage
    /// Createdby     : Ajit Kr 
    /// Created On    : 22 July 2015
    /// Description   :Function to Get UnRead Inbox Message
    /// data.
    /// </summary>
    /// <param name="sCategoryIDList">Category IDs</param>
    /// <param name="sZoneIDList">ZoneIDs</param>
    /// <param name="sDealerCategoryIDList">DealerCategoryIDs</param>
    /// <param name="sUserID">User ID</param>
    /// <returns>string</returns>
    public string CountUnReadInboxMessage(string sCategoryIDList, string sZoneIDList, string sDealerCategoryIDList, string sUserID, string sfromDate, string stoDate)
    {
        DataLayer objDataLayer = new DataLayer();
        string inboxMessageCount = "0";
        SPPUtility objUtility = new SPPUtility();
        try
        {

            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@UnReadCount";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;



            inboxMessageCount = Convert.ToString(SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMessageCountUnreadMessage",
                                 new SqlParameter("@CategoryIDList", sCategoryIDList), new SqlParameter("@ZoneIDList", sZoneIDList), new SqlParameter("@DealerCategoryIDList", sDealerCategoryIDList),
                                  new SqlParameter("@UserID", sUserID), new SqlParameter("@IsSMS", "N"), new SqlParameter("@FromDate", sfromDate), new SqlParameter("@ToDate", stoDate), outPutParameter));
            inboxMessageCount = Convert.ToString(outPutParameter.Value);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return inboxMessageCount;

    }
    /// <summary>
    /// Method Name   : UnReadSMSMessage
    /// Createdby     : Ajit Kr 
    /// Created On    : 22 July 2015
    /// Description   :Function to Get UnRead SMS Message
    /// data.
    /// </summary>
    /// <param name="sCategoryIDList">Category IDs</param>
    /// <param name="sZoneIDList">ZoneIDs</param>
    /// <param name="sDealerCategoryIDList">DealerCategoryIDs</param>
    /// <param name="sUserID">User ID</param>
    /// <returns>string</returns>
    public string CountUnReadSMSMessage(string sCategoryIDList, string sZoneIDList, string sDealerCategoryIDList, string sUserID, string sfromDate, string stoDate)
    {
        DataLayer objDataLayer = new DataLayer();
        string inboxSMSMessageCount = "0";
        SPPUtility objUtility = new SPPUtility();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@UnReadCount";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;


            inboxSMSMessageCount = Convert.ToString(SqlHelper.ExecuteScalar(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMessageCountUnreadMessage",
                                 new SqlParameter("@CategoryIDList", sCategoryIDList), new SqlParameter("@ZoneIDList", sZoneIDList), new SqlParameter("@DealerCategoryIDList", sDealerCategoryIDList),
                                  new SqlParameter("@UserID", sUserID), new SqlParameter("@IsSMS", "Y"), new SqlParameter("@FromDate", sfromDate), new SqlParameter("@ToDate", stoDate), outPutParameter));
            inboxSMSMessageCount = Convert.ToString(outPutParameter.Value);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return inboxSMSMessageCount;

    }



    #endregion


    /// <summary>
    /// Method Name   : GetInboxMessage
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 22 July 2015
    /// Description   :Function to Get Inbox Message
    /// data.
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sCategoryIDList">Category IDs</param>
    /// <param name="sZoneIDList">ZoneIDs</param>
    /// <param name="sDealerCategoryIDList">DealerCategoryIDs</param>
    /// <param name="sUserID">User ID</param>
    /// <param name="sfromDate">From Date</param>
    /// <param name="stoDate">To Date</param>
    /// <returns>DataTable</returns>
    public DataTable GetInboxMessage(int usercode, string sCategoryIDList, string sZoneIDList, string sDealerCategoryIDList, string sUserID, string sfromDate, string stoDate)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsInboxMessage = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsInboxMessage = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMessageGetInboxMessage",
                                 new SqlParameter("@CategoryIDList", sCategoryIDList), new SqlParameter("@ZoneIDList", sZoneIDList), new SqlParameter("@DealerCategoryIDList", sDealerCategoryIDList),
                                  new SqlParameter("@UserID", sUserID), new SqlParameter("@FromDate", sfromDate), new SqlParameter("@ToDate", stoDate));
            dt = objUtility.GenericReplace(dsInboxMessage.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;

    }



    /// <summary>
    /// Method Name   : UpdateMessageReadStatus
    /// Createdby     : Ajit Kumar
    /// Created On    : 23 Mar 2016
    /// Description   :Function to Update Status of Read message
    /// details.      
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sMessageID">Message ID</param>
    /// <param name="sRefUserID">User ID</param>
    /// <param name="sReadOn">Read On</param>
    /// <returns>DataTable</returns>
    public int UpdateMessageReadStatus(int usercode, string sMessageID, string sReadOn)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        int ReadStatus;
        SqlParameter outPutParameter = new SqlParameter();
        outPutParameter.ParameterName = "@OutPut";
        outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
        outPutParameter.Direction = System.Data.ParameterDirection.Output;
        outPutParameter.Size = 4;
        try
        {
            ReadStatus = SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SPP_UpdateMessageReadStatus",
                                 new SqlParameter("@sMessageID", sMessageID), new SqlParameter("@sRefUserID", usercode), new SqlParameter("@sReadOn", sReadOn), outPutParameter);
            ReadStatus = Convert.ToInt32(outPutParameter.Value);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return ReadStatus;

    }

    /// <summary>
    /// Method Name   : GetInboxMessageDetails
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 23 July 2015
    /// Description   :Function to Get Inbox Message
    /// details.
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sMessageID">Message ID</param>
    /// <param name="sRefUserID">User ID</param>
    /// <param name="sReadOn">Read On</param>
    /// <returns>DataTable</returns>
    public DataTable GetInboxMessageDetails(int usercode, string sMessageID, string sReadOn)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsInboxMessageDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsInboxMessageDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SP_Inbox_ReadMessageDetails",
                                 new SqlParameter("@sMessageID", sMessageID), new SqlParameter("@sRefUserID", usercode), new SqlParameter("@sReadOn", sReadOn));
            dt = objUtility.GenericReplace(dsInboxMessageDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;

    }


    /// <summary>
    /// Method Name   : GetSMSMessage
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 24 July 2015
    /// Description   :Function to Get Sms Message
    /// data.
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sCategoryIDList">Category IDs</param>
    /// <param name="sZoneIDList">Zone IDs</param>
    /// <param name="sDealerCategoryIDList">Dealer Category Ids</param>
    /// <param name="sfromDate">From Date</param>
    /// <param name="stoDate">To Date</param>
    /// <returns>DataTable</returns>
    public DataTable GetSMSMessage(int usercode, string sCategoryIDList, string sZoneIDList, string sDealerCategoryIDList, string sfromDate, string stoDate)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSMsMessage = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSMsMessage = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMessageGetSMSMessage",
                                 new SqlParameter("@CategoryIDList", sCategoryIDList), new SqlParameter("@ZoneIDList", sZoneIDList), new SqlParameter("@DealerCategoryIDList", sDealerCategoryIDList),
                                  new SqlParameter("@UserID", Convert.ToString(usercode)), new SqlParameter("@FromDate", sfromDate), new SqlParameter("@ToDate", stoDate));
            dt = objUtility.GenericReplace(dsSMsMessage.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;

    }

    /// <summary>
    /// Method Name   : GetSMSMessage
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 24 July 2015
    /// Description   :Function to Get Message Read Status
    /// </summary>
    /// <param name="sMessageID">Autogenereted User ID</param>
    /// <param name="sUserID">UserID</param>
    /// <returns>string</returns>
    public string IsMessageRead(string sMessageID, int sUserID)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        string isRead = string.Empty;

        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@ReadStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMessageGetMessageReadStatus",
                                                                               new SqlParameter("@MessageID", sMessageID),
                                                                               new SqlParameter("@UserID", sUserID),
                                                                               outPutParameter
                                                                            );
            isRead = outPutParameter.Value.ToString();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }

        return isRead;
    }

    #endregion "EDM/SMS"

    #region Feedback Form

    /// <summary>
    /// Insert FeedBack form data
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="dMSCode">DMSCode</param>
    /// <param name="menuId">menuId</param>
    /// <param name="menuName">menuName</param>
    /// <param name="subMenuId">subMenuId</param>
    /// <param name="subMenuName">subMenuName</param>
    /// <param name="remark">remark</param>
    /// <param name="comment">comment</param>
    /// <param name="tokan">tokan</param>
    /// <returns>int</returns>
    public int SPPInsertFeedBack(int userCode, string dMSCode, int menuId, string menuName, int subMenuId, string subMenuName, string remark, string comment)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        int ires = 0;
        try
        {
            dMSCode = objUtility.Clean(dMSCode);
            menuName = objUtility.Clean(menuName);
            subMenuName = objUtility.Clean(subMenuName);
            remark = objUtility.Clean(remark);
            comment = objUtility.Clean(comment);

            ires = Convert.ToInt32(SqlHelper.ExecuteScalar(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spAppInsertFeedBack",
                      new SqlParameter("@DMSCode", dMSCode),
                      new SqlParameter("@MenuId", menuId),
                      new SqlParameter("@MenuName", menuName),
                      new SqlParameter("@SubMenuId", subMenuId),
                      new SqlParameter("@SubMenuName", subMenuName),
                      new SqlParameter("@Remark", remark),
                      new SqlParameter("@Comment", comment),
                      new SqlParameter("@InsertedBy", userCode)
                      ));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return ires;
    }

    /// <summary>
    /// to get the compliment list for feedback form
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetCompliment(int usercode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsComplimentList = null;
        DataTable dtComplimentList = null;

        try
        {
            dsComplimentList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "SPP_CC_GetHelpLineType");
            dtComplimentList = objUtility.GenericReplace(dsComplimentList.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtComplimentList;
    }

    #endregion

    #region Notification

    #region Notification ---- SPPGetNotificationCategoryList

    /// <summary>
    /// SPPGetNotificationCategoryList
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetNotificationCategoryList(int usercode, string userid)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsNotificationCategoryList = null;
        DataTable dtNotificationCategories = null;
        try
        {
            dsNotificationCategoryList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spAPPGetNotificationCategoryList", new SqlParameter("@DMSCode", userid));
            dtNotificationCategories = objUtility.GenericReplace(dsNotificationCategoryList.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dtNotificationCategories;
    }

    #endregion Notification ---- SPPGetNotificationCategoryList

    #region Notification ---- SPPGetNotificationList

    /// <summary>
    /// SPPGetNotificationList
    /// SPP changes Amandeep Singh 04 april march 2022 start [SPP_Nepal_Mearge]
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="dMSCode">DMSCode</param>
    /// <returns>DataSet</returns>
    public DataSet SPPGetNotificationList(int usercode, string dMSCode, string fromDate, string toDate, int categoryId, int pageIndex, int recsPerPage, string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsNotificationList = null;

        if (recsPerPage <= 0)
            recsPerPage = 10;

        try
        {
            dsNotificationList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
                System.Data.CommandType.StoredProcedure, "spAPPGetNotificationList",
                new SqlParameter("@DMSCode", dMSCode),
                new SqlParameter("@FromDate", fromDate),
                new SqlParameter("@ToDate", toDate),
                new SqlParameter("@CategoryId", categoryId),
                new SqlParameter("@PageIndex", pageIndex),
                new SqlParameter("@RecsPerPage", recsPerPage),
                new SqlParameter("@CountryCode", CountryCode)
                );
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsNotificationList;
    }

    #endregion Notification ---- SPPGetNotificationList

    #region Notification ---- SPPSaveNotificationIsRead

    /// <summary>
    /// To Save Notification Read Status
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="dMSCode">dMSCode</param>
    /// <param name="notificationId">notificationId</param>
    /// <returns>int</returns>
    public int SPPSaveNotificationIsRead(int usercode, string dMSCode, int notificationId)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        int isupdate = 0;
        try
        {
            isupdate = SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(),
                System.Data.CommandType.StoredProcedure, "spAPPSaveNotificationIsRead",
                new SqlParameter("@DMSCode", dMSCode),
                new SqlParameter("@NotificationID", notificationId));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return isupdate;
    }

    #endregion Notification ---- SPPGetNotificationList

    #region Device registration for notification


    /// <summary>
    /// to Device registration for notification
    /// </summary>
    /// <param name="userId">userId</param>
    /// <param name="IMEI">IMEI</param>
    /// <param name="registrationId">registrationId</param>
    /// <param name="isRegister">isRegister</param>
    /// <param name="countryCode">countryCode [SPP_Nepal_Mearge]</param> 
    /// <returns>int</returns>
    public int SPPUpdateDeviceRegistrationDetails(int usercode, string userId, string IMEI, string registrationId, bool isRegister, string countryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        int Rows = 0;
        try
        {
            Rows = Convert.ToInt32(SqlHelper.ExecuteScalar(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SPP_APP_UpdateUserDeviceRegistration",
                                                          new SqlParameter("@UserID", userId),
                                                          new SqlParameter("@IMEI", IMEI),
                                                          new SqlParameter("@DeviceRegistrationID", registrationId),
                                                          new SqlParameter("@Flag", isRegister),
                                                              new SqlParameter("@CountryCode", countryCode)));//[SPP_Nepal_Mearge]
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
                objDataLayer = null;
            if (objUtility != null)
                objUtility = null;
        }
        return Rows;

    }


    #endregion

    #endregion Notification

    #region Security Token
    /// <summary>
    /// Method Name   : SPPInsertToken
    /// Createdby     : Manoj Kr Maurya
    /// Created On    : 03 Aug 2015
    /// Description   :Function to save the generated token into database.
    /// </summary>
    /// <param name="userCode">Autogenrated User ID</param>
    /// <param name="suserID">User ID</param>
    /// <param name="stoken">Token</param>
    /// <returns>int</returns>
    public int SPPInsertToken(int userCode, string suserID, string stoken)
    {
        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spAPPInsertSecurityToken",
                new SqlParameter("@userID", suserID),
                new SqlParameter("@token", stoken),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return ires;
    }


    /// <summary>
    /// to check security token for insert
    /// Created by Manoj Kumar on 04-Aug-2015 
    /// </summary>
    /// <param name="userCode">userCode</param>
    /// <param name="userId">userId</param>
    /// <param name="token">token</param>
    /// <returns>bool</returns>
    public bool SPPIsValidTokenForInsert(int userCode, string userId, string token)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsToken = null;
        bool result = false;

        try
        {
            dsToken = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spAPPCheckSecurityTokenForInsert",
                new SqlParameter("@userID", userId),
                new SqlParameter("@token", token)
                );

            if (dsToken != null)
            {
                if (dsToken.Tables.Count > 0)
                {
                    if (dsToken.Tables[0] != null && dsToken.Tables[0].Rows.Count > 0)
                    {
                        if (dsToken.Tables[0].Rows[0][0] != null)
                            if (Convert.ToInt32(dsToken.Tables[0].Rows[0][0]) > 0)
                                result = true;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return result;
    }

    #endregion

    #region AppProfile
    /// <summary>
    /// Method Name   : SPPGetProfileDetails
    /// Createdby     : Manoo Rishi
    /// Created On    : 31 Dec 2015
    /// Description   : Function to Get Profile Details
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sDistCode">DistCode</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetProfileDetails(int usercode, string sDistCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsInboxMessageDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsInboxMessageDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPAppGetProfileDetails",
                                  new SqlParameter("@DistCode", sDistCode));
            dt = objUtility.GenericReplace(dsInboxMessageDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;

    }

    //Changed by Anil verma on 29 march-2016 to save info in database of these fields  (state,city,pincode)

    /// <summary>
    /// Method Name   : SPPSaveProfileDetails
    /// Createdby     : Manoo Rishi
    /// Created On    : 31 Dec 2015
    /// Description   : Function to save Profile Details
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="sDistCode">DistCode</param>
    /// <param name="sMobileNo">MobileNo</param>
    /// <param name="sEmailId">EmailId</param>
    /// <param name="sOfficeAdd">OfficeAdd</param>
    /// <param name="state">state</param>
    /// <param name="city">city</param>
    /// <param name="pincode">pincode</param>
    /// <returns>int</returns>


    public int SPPSaveProfileDetails(int usercode, string sDistCode, string sMobileNo, string sEmailId, string sOfficeAdd, int emailverificationstatus, string state, string city, string pincode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        int isupdate = 0;
        try
        {
            isupdate = SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spSPPAppSaveProfile",
            new SqlParameter("@DistCode", sDistCode),
            new SqlParameter("@MobileNo", sMobileNo),
            new SqlParameter("@EmailId", sEmailId),
            new SqlParameter("@OfficeAdd", sOfficeAdd),
            new SqlParameter("@UserIdCode", usercode),
            new SqlParameter("@emailverificationstatus", emailverificationstatus),
            new SqlParameter("@state", state),
            new SqlParameter("@city", city),
            new SqlParameter("@pincode", pincode)
            );
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return isupdate;
    }

    /// <summary>
    /// Method Name   : SPPSaveProfileDetails
    /// Createdby     : Sandeep Kaur
    /// Created On    : 18th Feb 2016
    /// Modified by   : Anil Verma on 30-may-2016 to save otp and get otp information
    /// Description   : Function to save OTP
    /// </summary>
    /// <param name="usercode">usercode</param>
    /// <param name="sDistCode">DistCode</param>
    /// <param name="sMobileNo">SMSOtp</param>

    /// <returns>int</returns>
    public DataSet SPPSaveOtp(string sDistCode, string sMobileNo, string sSMSOtp, int useridcode, out int otpverification)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataSet dsotpverification = new DataSet();

        int isupdate = 0;
        otpverification = 0;


        try
        {


            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            dsotpverification = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spSPPAppSaveOtp",
            new SqlParameter("@DistCode", sDistCode),
            new SqlParameter("@MobileNo", sMobileNo),
            new SqlParameter("@SMSOtp", sSMSOtp),
            new SqlParameter("@useridcode", useridcode),
           outPutParameter
            );
            if (outPutParameter.SqlValue.ToString() != null)
            {
                isupdate = int.Parse(outPutParameter.SqlValue.ToString());
            }


        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsotpverification;
    }


    /// <summary>
    /// Method Name   : SPPUpdateOtpStatus
    /// Createdby     : Anil Verma
    /// Created On    : 31 May 2016    
    /// Description   : Function to update OTP status
    /// </summary>
    /// <param name="usercode">sDistCode</param>
    /// <param name="sDistCode">mobileno</param>
    /// <param name="sMobileNo">useridcode</param>

    /// <returns>int</returns>
    public int SPPUpdateOtpStatus(string sDistCode, string mobileno, int useridcode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataSet dsotpverification = new DataSet();

        int isupdate = 0;

        try
        {

            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spSPPAppUpdateOtpStatus",
            new SqlParameter("@DistCode", sDistCode),
            new SqlParameter("@MobileNo", mobileno),
            new SqlParameter("@useridcode", useridcode),
           outPutParameter
            );
            if (outPutParameter.SqlValue.ToString() != null)
            {
                isupdate = int.Parse(outPutParameter.SqlValue.ToString());
            }


        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return isupdate;
    }


    /// <summary>
    /// Method Name   : SPPGetOTPInfo
    /// Createdby     : Shaif Rizvi
    /// Created On    : 02 Sep 2016    
    /// Description   : Get Otp Info from profile 
    /// </summary>
    /// <param name="usercode">sDistCode</param>
    /// <param name="sDistCode">mobileno</param>
    ///  /// <param name="sMobileNo">OtpValue</param>
    /// <param name="sMobileNo">OutputStatus</param>

    /// <returns>DataTable</returns>
    public DataTable SPPGetOTPInfo(string sDistCode, string mobileno, string otpvalue, out int Status)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataSet dsgetotpinfo = new DataSet();
        DataTable dt = null;
        int isupdate = 0;

        try
        {

            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            dsgetotpinfo = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
              System.Data.CommandType.StoredProcedure, "spSPPAppCheckOtp",
              new SqlParameter("@DistCode", sDistCode),
              new SqlParameter("@MobileNo", mobileno),
              new SqlParameter("@OtpValue", otpvalue),
             outPutParameter
              );
            if (dsgetotpinfo != null && dsgetotpinfo.Tables.Count > 0)
            {
                dt = dsgetotpinfo.Tables[0];
            }
            if (outPutParameter.SqlValue.ToString() != null)
            {
                isupdate = int.Parse(outPutParameter.SqlValue.ToString());
            }
            Status = isupdate;

        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }

    /// <summary>
    /// Method Name   : SPPGenerateOtp
    /// Createdby     : Sandeep Kaur
    /// Created On    : 18th Feb 2016
    /// Description   : Function to Get SMSOTP
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sDistCode">DistCode</param>
    /// <returns>DataTable</returns> 
    public DataTable SPPGetOtp(int usercode, string sDistCode, string sMobileno)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsInboxMessageDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsInboxMessageDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPAppGetOtp",
                                  new SqlParameter("@DistCode", sDistCode),
                                  new SqlParameter("@Mobileno", sMobileno));
            dt = objUtility.GenericReplace(dsInboxMessageDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;

    }

    /// <summary>
    /// Method Name   : SPPGenerateOtp
    /// Createdby     : Sandeep Kaur
    /// Created On    : 18th Feb 2016
    /// Description   : Function to Verify SMSOTP
    /// </summary>
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sDistCode">DistCode</param>
    /// <returns>DataTable</returns> 
    public DataTable SPPVerifyOtp(int usercode, string sDistCode, string sOtpvalue)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsInboxMessageDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsInboxMessageDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPAppVerifyOtp",
                                  new SqlParameter("@DistCode", sDistCode),
                                  new SqlParameter("@Otpvalue", sOtpvalue));
            dt = objUtility.GenericReplace(dsInboxMessageDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;

    }

    /// <summary>
    /// Method Name   : SPPSaveEmailVerificationCode
    /// Createdby     : Deepika Bhatia
    /// Created On    : 18 02 2016
    /// Description   : Function to save Email Verification Code
    /// </summary>
    /// <param name="usercode">RefDistCode</param>
    /// <param name="sDistCode">EmailVerificationCode</param>
    /// <param name="sEmail">EmailID</param>

    /// <returns>int</returns>
    public int SPPSaveEmailVerificationCode(string RefDistCode, string EmailID, string EmailVerificationCode, int usercode, string sMobileNo, string sOfficeAdd, int emailverificationstatus, int stateid, int cityid, string pincode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        int isupdate = 0;
        try
        {

            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spSPPSaveEmailVerificationCode",
            new SqlParameter("@RefDistCode", RefDistCode),
            new SqlParameter("@EmailID", EmailID),
            new SqlParameter("@EmailVerificationCode", EmailVerificationCode),
            new SqlParameter("@MobileNo", sMobileNo),
            new SqlParameter("@OfficeAdd", sOfficeAdd),
            new SqlParameter("@UserIdCode", usercode),
            new SqlParameter("@emailverificationstatus", emailverificationstatus),
            new SqlParameter("@stateid", stateid),
            new SqlParameter("@cityid", cityid),
            new SqlParameter("@pincode", pincode),
            outPutParameter);
            isupdate = Convert.ToInt16(outPutParameter.Value);
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return isupdate;
    }

    /// <summary>
    /// Method Name   : SPPProfileVerification
    /// Createdby     : Anil VermA
    /// Created On    : 23 march 2016
    /// Description   : Function to verify pROFILE 
    /// </summary>
    /// <param name="usercode">RefDistCode</param>
    /// <returns>int</returns>
    public DataTable SPPProfileVerification(string DistCode)
    {
        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        DataTable dtPverification = new DataTable();
        DataSet ds = new DataSet();
        try
        {

            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spSPPProfileVerification1", new SqlParameter("@DistCode", DistCode));
            if (ds != null && ds.Tables.Count > 0)
            {
                dtPverification = ds.Tables[0];
            }


        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }

        return dtPverification;
    }

    //Code by Sandeep kaur on 31 march 2016 to implement city and state

    /// <summary>
    /// Method Name   : SPPGetStateList
    /// Createdby     : Sandeep Kaur Sidhu
    /// Created On    : 30-March-2016
    /// Description   : To get state list
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable SPPGetStateList()
    {
        DataLayer objDataLayer = new DataLayer();
        DataTable dtVersion = new DataTable();
        try
        {
            dtVersion = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spSPPAppGetStateList").Tables[0];
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
        return dtVersion;
    }

    /// <summary>
    /// Method Name   : SPPGetCityList
    /// Createdby     : Sandeep Kaur Sidhu
    /// Created On    : 30-March-2016
    /// Description   : To get city list
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable SPPGetCityList(string sStateID)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsInboxMessageDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsInboxMessageDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPAppGetCityList",
                                  new SqlParameter("@StateID", sStateID));
            dt = objUtility.GenericReplace(dsInboxMessageDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;
    }




    #endregion

    #region "Latest Updates"
    /// <summary>
    /// Method Name   : GetListOfLatestUpdates
    /// Createdby     : Deepika Bhatia
    /// Created On    : 25 Feb 2016
    /// Description   :Service to get latest updates.
    /// Changes in procs name for getting latest from GMCS System
    /// </summary>Old Proc:SP_SelectLatestUpdates
    /// <param name="usercode">Autogenereted User ID</param>
    /// <param name="sCategoryIDList">Category ID</param>
    /// <param name="sZoneIDList">zone ID</param>
    /// <returns>DataTable</returns>
    public DataTable GetListOfLatestUpdates(int usercode, string sCategoryIDList, string sZoneIDList)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSchemeData = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsSchemeData = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "uspSAM_GMCS_SPPUpdates"
                            , new SqlParameter("@CategoryIDList", sCategoryIDList)
                            , new SqlParameter("@ZoneIDList", sZoneIDList)
                            , new SqlParameter("@Source", "A")
                           );

            dt = objUtility.GenericReplace(dsSchemeData.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;
    }

    #endregion "Latest Updates"


    #region Leadership Blog  Developed by Anil Verma on 13 April 2016


    /// <summary>
    /// To return Contact Program Articles
    /// Developed by Anil Verma on 13 April 2016
    /// </summary>
    /// <param name="usertypeid"></param>
    /// <param name="userid"></param>
    /// <param name="pageIndex"></param>
    /// <param name="recsPerPage"></param>
    /// <returns></returns>
    public DataSet SPPGetContactProgramArticles(string usertypeid, int useridcode, int pageIndex, int recsPerPage, out int pageCount)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsArticles = null;

        if (recsPerPage <= 0)
            recsPerPage = 10;
        pageCount = 0;

        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@PageCount";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            dsArticles = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpGetArticleList",
            new SqlParameter("@UserType", usertypeid),
            new SqlParameter("@LoggedUserID", useridcode),
            new SqlParameter("@PageIndex", pageIndex),
            new SqlParameter("@PageSize", recsPerPage),
           outPutParameter
            );
            if (outPutParameter.SqlValue.ToString() != null)
            {
                pageCount = int.Parse(outPutParameter.SqlValue.ToString());
            }

            objUtility.GenericReplace(dsArticles.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsArticles;
    }


    /// <summary>
    /// To get Leadership Blogs Articles details and comments based on Article ID.
    /// Developed by Anil Verma on 14 April 2016
    /// </summary>
    /// <param name="articleid"></param>
    /// <returns></returns>
    public DataSet GetContactProgramArticleByArticleID(int articleid)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsArticlesViewandComments = null;



        try
        {


            dsArticlesViewandComments = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpGetArticleDetailsByArticleID",
            new SqlParameter("@ArticleID", articleid)
            );

            objUtility.GenericReplace(dsArticlesViewandComments.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsArticlesViewandComments;
    }






    /// <summary>
    /// Function to Insert Article View Log
    /// Added by Anil Verma on 2 May 2016
    /// </summary>
    /// <param name="articleid"></param>
    /// <param name="userid"></param>
    /// <param name="isactive"></param>
    /// <param name="createdby"></param>
    /// <param name="createdon"></param>
    public int InsertArticleViewLog(int articleid, int userid, string isactive, int createdby, string createdon)
    {
        DataLayer dtLayer = new DataLayer();

        int pageCount = 0;

        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            SqlHelper.ExecuteNonQuery(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spLbcpInsertArticleViewLog"
                                                , new SqlParameter("@ArticleId", articleid)
                                                , new SqlParameter("@UserID", userid)
                                                , new SqlParameter("@IsActive", isactive)
                                                , new SqlParameter("@CreatedBy", createdby)
                                                , new SqlParameter("@CreatedOn", createdon)
                                                 , outPutParameter
            );
            if (outPutParameter.SqlValue.ToString() != null)
            {
                pageCount = int.Parse(outPutParameter.SqlValue.ToString());
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (dtLayer != null)
            {
                dtLayer = null;
            }
        }

        return pageCount;
    }

    /// <summary>
    /// To get Leadership Blogs Articles details HTML based on Article ID.
    /// Developed by Anil Verma on 18 April 2016
    /// </summary>
    /// <param name="articleid"></param>
    /// <returns></returns>
    public DataSet GetArticleDetailContentByArticleID(int articleid)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsArticlesHTMLcontents = null;



        try
        {


            dsArticlesHTMLcontents = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpGetArticleDetailContentByArticleID",
            new SqlParameter("@ArticleID", articleid)
            );

            objUtility.GenericReplace(dsArticlesHTMLcontents.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsArticlesHTMLcontents;
    }

    /// <summary>
    /// Function to Get Like/Unlike by Article ID and User ID
    /// Developed by Anil Verma on 26 April 2016
    /// </summary>
    /// <param name="articleid"></param>
    /// <returns></returns>
    public DataSet GetArticleLikeUnlikeByArticleIDAndUserID(int articleid, int useridcode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsArticleslikeunlike = null;


        try
        {


            dsArticleslikeunlike = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpGetArticleLikeUnlikeByArticleIDAndUserID",
            new SqlParameter("@ArticleID", articleid),
            new SqlParameter("@UserID", useridcode)
            );



        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsArticleslikeunlike;
    }



    /// <summary>
    /// To get Leadership Blogs Articles comments based on Article ID.
    /// Developed by Anil Verma on 14 April 2016
    /// </summary>
    /// <param name="articleid"></param>
    /// <returns></returns>
    public DataSet GetArticleCommentByArticleID(int articleid)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataSet dsArticlesViewandComments = null;

        try
        {

            dsArticlesViewandComments = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpGetArticleCommentByArticleID",
            new SqlParameter("@ArticleID", articleid)
            );

            objUtility.GenericReplace(dsArticlesViewandComments.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsArticlesViewandComments;
    }


    /// <summary>
    /// To get My Comments List
    /// Added by Anil Verma on 18-April-2016. 
    /// </summary>
    /// <param name="usertypeid"></param>
    /// <param name="userid"></param>
    /// <param name="pageIndex"></param>
    ///<param name="dateorder"></param>
    /// <param name="searchkeyword"></param>
    /// <param name="recsPerPage"></param>
    /// <returns></returns>
    public DataSet GetMyComments(int useridcode, string dateorder, string searchkeyword, int pageIndex, int recsPerPage, out int pageCount)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsArticles = null;

        if (recsPerPage <= 0)
            recsPerPage = 10;

        pageCount = 0;
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@PageCount";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            dsArticles = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpGetCommentPostedBySpecificUser",
            new SqlParameter("@UserID", useridcode),
            new SqlParameter("@DateOrder", dateorder),
            new SqlParameter("@SearchKeyWord", searchkeyword),
            new SqlParameter("@PageIndex", pageIndex),
            new SqlParameter("@PageSize", recsPerPage),
           outPutParameter
            );
            if (outPutParameter.SqlValue.ToString() != null)
            {
                pageCount = int.Parse(outPutParameter.SqlValue.ToString());
            }


            objUtility.GenericReplace(dsArticles.Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsArticles;
    }



    /// <summary>
    /// Method Name   : SPPPostArticleComments
    /// Createdby     : Anil verma
    /// Created On    : 21 April 2016
    /// Description   : Function to Post Article comment
    /// </summary>
    /// <param name="categoryid"></param>
    /// <param name="articleid"></param>
    /// <param name="userid"></param>
    /// <param name="userCode"></param>
    /// <param name="commentcontent"></param>
    /// <param name="emailid"></param>
    /// <param name="status"></param>
    /// <param name="commentdate"></param>
    /// <param name="month"></param>
    /// <param name="year"></param>
    /// <param name="isactive"></param>
    /// <param name="createdby"></param>
    /// <param name="createdon"></param>
    /// <returns></returns>
    public int SPPPostArticleComments(string categoryid, int articleid, string userid, int userCode, string commentcontent, string emailid, string status, string commentdate, string month, string year, string isactive, int createdby, string createdon)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        int isupdate = 0;
        try
        {

            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpInsertArticleComment",
            new SqlParameter("@CategoryId", categoryid),
            new SqlParameter("@ArticleId", articleid),
            new SqlParameter("@CommentBy", userCode),
            new SqlParameter("@CommentContent", commentcontent),
            new SqlParameter("@EmailId", emailid),
            new SqlParameter("@Status", status),
            new SqlParameter("@CommentDate", commentdate),
            new SqlParameter("@Month", month),
            new SqlParameter("@Year", year),
            new SqlParameter("@IsActive", isactive),
            new SqlParameter("@CreatedBy", createdby),
            new SqlParameter("@CreatedOn", createdon),
             outPutParameter
            );

            isupdate = Convert.ToInt32(outPutParameter.Value);
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return isupdate;
    }






    /// <summary>
    /// To get Archived Articles year and month. 
    /// Added by Anil Verma on 22-April-2016. 
    /// </summary>
    /// <param name="usertypeid"></param>
    /// <param name="useridcode"></param>
    /// <returns></returns>
    public DataTable SPPGetYearList(string usertypeid, int useridcode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataTable dtyear = null;


        try
        {
            dtyear = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpGetUserWiseArticleYearList",
            new SqlParameter("@UserType", usertypeid),
            new SqlParameter("@LoggedUserID", useridcode)
            ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtyear;
    }



    /// <summary>
    /// To get Archived Articles month list based on yearid. 
    /// Added by Anil Verma on 22-April-2016. 
    /// </summary>
    /// <param name="usertypeid"></param>
    /// <param name="useridcode"></param>
    /// <returns></returns>
    public DataTable SPPGetMonthList(string usertypeid, int useridcode, string year, out int latesmonth)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataTable dtyear = null;


        try
        {

            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@LatestMonth";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            dtyear = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpGetUserWiseArticleMonthListByYear",
            new SqlParameter("@UserType", usertypeid),
            new SqlParameter("@LoggedUserID", useridcode),
            new SqlParameter("@Year", year),
            outPutParameter

            ).Tables[0];

            latesmonth = Convert.ToInt32(outPutParameter.Value);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtyear;
    }



    /// <summary>
    /// To get Archived Articles based on month and year.
    /// Created by Anil Verma on 25-April-2016        
    /// </summary>
    /// <param name="usertypeid"></param>
    /// <param name="useridcode"></param>
    /// <param name="month"></param>
    /// <param name="year"></param>
    /// <param name="pageIndex"></param>
    /// <param name="recsPerPage"></param>
    /// <param name="pageCount"></param>
    /// <param name="RecordCount"></param>
    /// <returns></returns>
    public DataSet GetContactProgramArticlesByMonthAndYear(string usertypeid, int useridcode, string month, string year, int pageIndex, int recsPerPage, out int pageCount, out int RecordCount)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsArticles = null;

        if (recsPerPage <= 0)
        {
            recsPerPage = 10;
        }

        pageCount = 0;
        RecordCount = 0;

        try
        {
            SqlParameter outPutPageCount = new SqlParameter();
            outPutPageCount.ParameterName = "@PageCount";
            outPutPageCount.SqlDbType = System.Data.SqlDbType.Int;
            outPutPageCount.Direction = System.Data.ParameterDirection.Output;
            outPutPageCount.Size = 4;

            SqlParameter outPutRecordcount = new SqlParameter();
            outPutRecordcount.ParameterName = "@RecordCount";
            outPutRecordcount.SqlDbType = System.Data.SqlDbType.Int;
            outPutRecordcount.Direction = System.Data.ParameterDirection.Output;
            outPutRecordcount.Size = 4;

            dsArticles = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpGetArticleListByMonthAndYear",
            new SqlParameter("@UserType", usertypeid),
            new SqlParameter("@LoggedUserID", useridcode),
            new SqlParameter("@Month", month),
            new SqlParameter("@Year", year),
            new SqlParameter("@PageIndex", pageIndex),
            new SqlParameter("@PageSize", recsPerPage),
            outPutPageCount,
            outPutRecordcount
            );
            if (outPutPageCount.SqlValue.ToString() != null)
            {
                pageCount = int.Parse(outPutPageCount.SqlValue.ToString());
            }
            if (outPutRecordcount.SqlValue.ToString() != null)
            {
                RecordCount = int.Parse(outPutRecordcount.SqlValue.ToString());
            }


            objUtility.GenericReplace(dsArticles.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsArticles;
    }


    /// <summary>
    /// Code by Anil Verma on 26-April-2016
    /// Service to Update Article Likes
    /// </summary>
    /// <param name="articleid"></param>
    /// <param name="userCode"></param>
    /// <param name="mode"></param>
    /// <param name="modifiedby"></param>
    /// <param name="ModifiedOn"></param>
    /// <returns></returns>
    public int UpdateArticleLikeUnlike(int articleid, int userCode, string mode, int modifiedby, string ModifiedOn)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        int isupdate = 0;
        try
        {

            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(),
            System.Data.CommandType.StoredProcedure, "spLbcpInsertArticleLikeUnlike",

            new SqlParameter("@ArticleId", articleid),
            new SqlParameter("@UserID", userCode),
            new SqlParameter("@Mode", mode),
            new SqlParameter("@ModifiedBy", modifiedby),
            new SqlParameter("@ModifiedOn", ModifiedOn),
             outPutParameter
            );

            isupdate = Convert.ToInt32(outPutParameter.Value);
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return isupdate;
    }



    #endregion


    #region SRD Sikhar Card,SMD Program and Champions club  new task added by Anli verma on 29 April 2016

    /// <summary>
    /// Created by Qyam on 07-04-15.To get SRD,SMD and Champions club data.
    /// </summary>
    /// <param name="programid"></param>
    /// <returns></returns>
    public DataTable GetSRDSikharCard(int programid)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsTestList = new DataSet();
        try
        {

            dsTestList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SPPGetSRDSikharCard"
                                                                                      , new SqlParameter("@programid", programid)
                                                                                      );
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
        return dsTestList.Tables[0];
    }




    /// <summary>
    /// Created by Anil verma on 13-may-2016 To Check SCM and TSE. 
    /// </summary>
    /// <param name="userid"></param>
    /// <returns></returns>
    public DataTable GetTSESCM(string userid)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsTestList = new DataSet();
        try
        {

            dsTestList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SPPCheckSMDFOS"
                                                                                      , new SqlParameter("@userid", userid)
                                                                                      );
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
        return dsTestList.Tables[0];
    }
    #endregion

    #region Happy Partner

    /// Method Name   : GetRequestCategoryHappyPartner
    /// Createdby     : Ajit Kumar
    /// Created On    : 14 APR 2016
    /// <summary>
    /// Function to Get Request of Category List  for Happy Partner
    /// </summary>
    /// <returns></returns>
    public DataTable GetRequestCategoryHappyPartner(string UserType)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dtROC = null;
        try
        {
            dtROC = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spCCHDGetRequestCategory", new SqlParameter("@UserType", UserType)).Tables[0];
            dtROC = objUtility.GenericReplace(dtROC);
            return dtROC;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
            if (dtROC != null)
            {
                dtROC = null;
            }
        }

    }

    /// Method Name   : InsertHappyPartner
    /// Createdby     : Ajit Kumar
    /// Created On    : 18 APR 2016
    /// <summary>
    /// Function to Add  Happy Partner Partner
    /// </summary>
    /// <param name="sUserName">User Name</param>
    /// <param name="sDMSCode">DMS Code</param>
    /// <param name="sRefUserID">RefUser ID</param>
    /// <param name="sEmailID">Email ID</param>
    /// <param name="sContactNumber">Contact Number</param>
    /// <param name="sSubject">Subject</param>
    /// <param name="sRefRCID">Ref Request Caategory ID</param>
    /// <param name="sSummary">Summary</param>
    /// <param name="sIsActive">Is Active</param>
    /// <param name="sCreatedBy">Created By</param>
    /// <param name="sCreatedOn">Created On</param>
    /// <returns>string</returns>
    /// 
    public string InsertHappyPartner(string sUserName, string sDMSCode, string sRefUserID, string sEmailID, string sContactNumber,
      string sSubject, string sRefRCID, string sSummary, string sIsActive, string sCreatedBy, string sCreatedOn)
    {

        DataLayer objDataLayer = new DataLayer();
        string strRequestNo = "";
        SPPUtility objUtility = new SPPUtility();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@RequestNumber";
            outPutParameter.SqlDbType = System.Data.SqlDbType.VarChar;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 50;
            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spCCHDInsertHappyDealerRequest",
                                   new SqlParameter("@UserName", sUserName), new SqlParameter("@DMSCode", sDMSCode),
                                   new SqlParameter("@RefUserID", sRefUserID), new SqlParameter("@EmailID", sEmailID), new SqlParameter("@ContactNumber", sContactNumber),
                                    new SqlParameter("@Subject", sSubject), new SqlParameter("@RefRCID", sRefRCID), new SqlParameter("@Summary", sSummary),
                                      new SqlParameter("@IsActive", sIsActive), new SqlParameter("@CreatedBy", sCreatedBy), new SqlParameter("@CreatedOn", sCreatedOn), new SqlParameter("@IsApplicableFor", "A"), outPutParameter);
            strRequestNo = Convert.ToString(outPutParameter.Value);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return strRequestNo;
    }

    /// Method Name   : UpdateHappyPartnerStatus
    /// Createdby     : Ajit Kumar
    /// Created On    : 19 APR 2016
    /// <summary>
    /// Function to Update Email Receipt and Confirmation  Status
    /// </summary>
    /// <param name="sRequestNumber">Request Number</param>
    /// <param name="sEmailStatus">Email Status</param>
    /// <param name="sMode">Mode</param>
    /// <param name="sModifiedOn">Modified On</param>
    /// <param name="sModifiedBy">Modified By</param>
    /// <returns>string</returns>
    public bool UpdateHappyPartnerStatus(string sRequestNumber, string sEmailStatus, string sMode, string sModifiedOn, string sModifiedBy)
    {
        {
            DataLayer objDataLayer = new DataLayer();
            bool status = false;
            SPPUtility objUtility = new SPPUtility();
            try
            {

                SqlParameter outPutParameter = new SqlParameter();
                outPutParameter.ParameterName = "@OutPutStatus";
                outPutParameter.SqlDbType = System.Data.SqlDbType.VarChar;
                outPutParameter.Direction = System.Data.ParameterDirection.Output;
                outPutParameter.Size = 50;
                SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spCCHDUpdateHappyDealerRequestEmailStatus",
                                       new SqlParameter("@RequestNumber", sRequestNumber), new SqlParameter("@EmailStatus", sEmailStatus),
                                       new SqlParameter("@Mode", sMode), new SqlParameter("@ModifiedOn", sModifiedOn), new SqlParameter("@ModifiedBy", sModifiedBy)
                                        , outPutParameter);
                if (Convert.ToString(outPutParameter.Value) != "1")
                {
                    status = false;
                }
                else
                {
                    status = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objDataLayer != null)
                {
                    objDataLayer = null;
                }

                if (objUtility != null)
                {
                    objUtility = null;
                }

            }
            return status;
        }

    }

    /// Method Name   : SPPGetFeedbackList
    /// Createdby     : Ajit Kumar
    /// Created On    : 28 APR 2016
    /// <summary>
    /// Function to GetFeedbackList
    /// </summary>
    /// <param name="ScreenType">ScreenType</param>
    /// <param name="UserId">UserId</param>
    /// <param name="FromDate">FromDate</param>
    /// <param name="ToDate">ToDate</param>
    /// <param name="FromDate">RowsPerPage</param>
    /// <param name="ToDate">PageNumber</param>
    /// <param name="pageCount">pageCount</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetFeedbackList(string ScreenType, string UserId, string FromDate, string ToDate, int RowsPerPage, int PageNumber, string status, out int pageCount)
    {
        {
            DataLayer objDataLayer = new DataLayer();
            SPPUtility objUtility = new SPPUtility();
            DataTable dt = new DataTable();
            pageCount = 0;
            try
            {
                DataSet ds = new DataSet();
                SqlParameter outPutParameter = new SqlParameter();
                outPutParameter.ParameterName = "@OutPutStatus";
                outPutParameter.SqlDbType = System.Data.SqlDbType.VarChar;
                outPutParameter.Direction = System.Data.ParameterDirection.Output;
                outPutParameter.Size = 50;


                SqlParameter outPutPageCount = new SqlParameter();
                outPutPageCount.ParameterName = "@PageCount";
                outPutPageCount.SqlDbType = System.Data.SqlDbType.VarChar;
                outPutPageCount.Direction = System.Data.ParameterDirection.Output;
                outPutPageCount.Size = 50;

                ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPGetFeedbackListAndReply",
                      new SqlParameter("@TypeId", 1),
                     new SqlParameter("@ScreenType", ScreenType),
                     new SqlParameter("@UserId", UserId), new SqlParameter("@FromDate", FromDate), new SqlParameter("@ToDate", ToDate),
                     new SqlParameter("@RowsPerPage", RowsPerPage),
                     new SqlParameter("@PageNumber", PageNumber), new SqlParameter("@status", status), outPutParameter, outPutPageCount);
                if (Convert.ToString(outPutParameter.Value) != "1")
                {

                }
                else
                {
                    if (ds.Tables.Count > 0)
                        dt = ds.Tables[0];
                }

                if (outPutPageCount.SqlValue.ToString() != null)
                {
                    pageCount = int.Parse(outPutPageCount.SqlValue.ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objDataLayer != null)
                {
                    objDataLayer = null;
                }

                if (objUtility != null)
                {
                    objUtility = null;
                }

            }
            return dt;
        }

    }


    /// Method Name   : SPPSaveFeedbackReply
    /// Createdby     : Ajit Kumar
    /// Created On    : 28 APR 2016
    /// <summary>
    /// Function to Update Feedback Reply
    /// </summary>
    /// <param name="userId">userId</param>
    /// <param name="RequestNumber">RequestNumber</param>
    /// <param name="FeedbackReplyText">FeedbackReplyText</param>
    /// <returns>bool</returns>
    public bool SPPSaveFeedbackReply(string userId, string RequestNumber, string FeedbackReplyText)
    {

        {
            DataLayer objDataLayer = new DataLayer();
            bool status = false;
            SPPUtility objUtility = new SPPUtility();
            try
            {

                SqlParameter outPutParameter = new SqlParameter();
                outPutParameter.ParameterName = "@OutPutStatus";
                outPutParameter.SqlDbType = System.Data.SqlDbType.VarChar;
                outPutParameter.Direction = System.Data.ParameterDirection.Output;
                outPutParameter.Size = 50;


                SqlParameter outPutPageCount = new SqlParameter();
                outPutPageCount.ParameterName = "@PageCount";
                outPutPageCount.SqlDbType = System.Data.SqlDbType.VarChar;
                outPutPageCount.Direction = System.Data.ParameterDirection.Output;
                outPutPageCount.Size = 50;

                SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPGetFeedbackListAndReply",
                                       new SqlParameter("@TypeId", 2), new SqlParameter("@UserId", userId),
                                       new SqlParameter("@RequestNumber", RequestNumber), new SqlParameter("@FeedbackReplyText", FeedbackReplyText)
                                        , outPutParameter, outPutPageCount);
                if (Convert.ToString(outPutParameter.Value) != "1")
                {
                    status = false;
                }
                else
                {
                    status = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objDataLayer != null)
                {
                    objDataLayer = null;
                }

                if (objUtility != null)
                {
                    objUtility = null;
                }

            }
            return status;
        }

    }



    /// Method Name   : SPPGetFeedbackReplyDetails
    /// Createdby     : Ajit Kumar
    /// Created On    : 03 MAY 2016
    /// <summary>
    /// Function to Get Feedback Reply Details
    /// </summary>
    /// <param name="ScreenType">RequestNumber</param>
    /// <param name="UserId">UserId</param>
    /// <returns>DataTable</returns>
    public DataTable SPPGetFeedbackReplyDetails(string userId, string RequestNumber, string ScreenType)
    {
        {
            DataLayer objDataLayer = new DataLayer();
            SPPUtility objUtility = new SPPUtility();
            DataTable dt = new DataTable();
            try
            {
                DataSet ds = new DataSet();
                SqlParameter outPutParameter = new SqlParameter();
                outPutParameter.ParameterName = "@OutPutStatus";
                outPutParameter.SqlDbType = System.Data.SqlDbType.VarChar;
                outPutParameter.Direction = System.Data.ParameterDirection.Output;
                outPutParameter.Size = 50;


                SqlParameter outPutPageCount = new SqlParameter();
                outPutPageCount.ParameterName = "@PageCount";
                outPutPageCount.SqlDbType = System.Data.SqlDbType.VarChar;
                outPutPageCount.Direction = System.Data.ParameterDirection.Output;
                outPutPageCount.Size = 50;



                ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPGetFeedbackListAndReply",
                        new SqlParameter("@TypeId", 3),
                        new SqlParameter("@ScreenType", ScreenType),
                       new SqlParameter("@UserId", userId),
                       new SqlParameter("@RequestNumber", RequestNumber), outPutParameter, outPutPageCount);
                if (Convert.ToString(outPutParameter.Value) != "1")
                {
                    //dt = null;
                }
                else
                {
                    if (ds.Tables.Count > 0)
                        dt = ds.Tables[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (objDataLayer != null)
                {
                    objDataLayer = null;
                }

                if (objUtility != null)
                {
                    objUtility = null;
                }

            }
            return dt;
        }

    }

    /// Method Name   : SPPGetFeedbackListForNotification
    /// Createdby     : Ajit Kumar
    /// Created On    : 13 May 2016
    /// <summary>
    /// Function to Get Request of Feedback and MyQuery For Notification
    /// </summary>
    /// <returns></returns>
    public DataSet SPPGetFeedbackListForNotification(string screentype, int useridcode, int hdid)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataSet ds = null;
        try
        {
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPGetFeedbackAndReplyInNotification",
                new SqlParameter("@ScreenType", screentype), new SqlParameter("@HDID", hdid), new SqlParameter("@UserId", useridcode));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return ds;

    }


    #endregion

    #region My Galaxy & Reglobe on 13 Jan 2016 by Prashant

    /// <summary>
    /// Save user Bid detail into MyGalaxyBidMaster and MyGalaxyBidDetail
    /// </summary>
    /// <param name="objBidInput"></param>
    /// <returns></returns>
    public int PostUserBid(MGBidDetailsDTO objBidInput, List<MyGalaxyConfigurationSetting> objConfigSettings)
    {
        int result = 0;
        int serresult = 0;
        SPPUtility objUtility = new SPPUtility();
        bool reQuoteReglobePrice = false;
        string errorResponse = string.Empty;
        DataTable sIMEIDealer = null;
        try
        {
            lstConfigSettings = objConfigSettings;
            int DealerRadiusTypeID = GetConfigValue<int>(KEY_DEALERCITYRADIUS, (int)ConfigType.Internal);
            int DealerRadius = GetConfigValue<int>(KEY_DEALERRADIUS, (int)ConfigType.Internal);
            int ReglobeBidExpiryDays = GetConfigValue<int>(KEY_REGLOBEBIDVALIDITYDAYS, (int)ConfigType.Internal);
            int TopDealerCount = GetConfigValue<int>(KEY_TOPDEALERCOUNT, (int)ConfigType.Internal);
            int RadiusType = GetConfigValue<int>(KEY_Radius, (int)ConfigType.Internal);
            int BuyBackSingleDealer = GetConfigValue<int>(KEY_BUYBACKSINGLEDEALER, (int)ConfigType.Internal);
            SamsungPortalEntitiesDB objDbContext = null;
            List<SPGetDealerList_Result> dealersList = new List<SPGetDealerList_Result>();

            #region shaif applaying single dealer
            if (BuyBackSingleDealer == 1)
            {
                string IMEI_No = string.Empty;
                if (objBidInput.IMEI_No.Contains(","))
                    IMEI_No = objBidInput.IMEI_No.Split(',')[0];
                else
                    IMEI_No = objBidInput.IMEI_No;
                sIMEIDealer = GetActivationDetailsToS2P2(IMEI_No);
            }
            #endregion
            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions
            {
                IsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted
            }))
            {
                using (objDbContext = new SamsungPortalEntitiesDB())
                {
                    if (objBidInput != null && objDbContext.MyGalaxyBidMasters.FirstOrDefault(x => x.TransactionId == objBidInput.TransactionId) == null)
                    {
                        MyGalaxyBidMaster objBidMaster = new MyGalaxyBidMaster();
                        objBidMaster.TransactionId = objBidInput.TransactionId;
                        objBidMaster.DateOfCreation = Convert.ToDateTime(objBidInput.DateOfCreation);
                        objBidMaster.ConfigurationHours = GetConfigValue<int>(KEY_CONFIGHOURS, (int)ConfigType.Internal); //Convert.ToInt32(ConfigurationManager.AppSettings[KEY_CONFIGHOURS].ToString()); //Bid config hours From app config
                        // Here in case the market name is blank then we are finding the market name in our table.
                        if (string.IsNullOrEmpty(objBidInput.ModelName))
                        {
                            if (objDbContext.MyGalaxyOfferProducts.FirstOrDefault(x => x.ProductCode.Contains(objBidInput.ModelCode)) != null)
                            {
                                var modelname = objDbContext.MyGalaxyOfferProducts.FirstOrDefault(x => x.ProductCode.Contains(objBidInput.ModelCode)).MarketName;
                                objBidMaster.ModelName = modelname;
                            }
                            else
                            {
                                objBidMaster.ModelName = objBidInput.ModelCode;
                            }
                        }
                        else
                        {
                            objBidMaster.ModelName = objBidInput.ModelName;//Customer mobile name 
                        }
                        objBidMaster.ModelCode = objBidInput.ModelCode;//Customer mobile Code 
                        objBidMaster.IMEI_No = objBidInput.IMEI_No;//Customer mobile Imei no 
                        objBidMaster.ReGlobePrice = objBidInput.ReGlobePrice;
                        objBidMaster.ReGlobePercentage = GetConfigValue<int>(KEY_REGLOBEPERCENT, (int)ConfigType.Internal); //Convert.ToInt32(ConfigurationManager.AppSettings[KEY_REGLOBEPERCENT].ToString());//Reglobe price percentage From app config
                        objBidMaster.CurrentLatitude = objBidInput.CurrentLatitude;
                        objBidMaster.CurrentLongitude = objBidInput.CurrentLongitude;
                        objBidMaster.Radius = Convert.ToString(DealerRadius);
                        //====================Added by shaif ============ 6-25-2016
                        //objBidMaster.DealerRadiusTypeID = Convert.ToString(DealerRadiusTypeID);
                        //=========================================================
                        //objBidMaster.PhoneCondition = System.Web.HttpUtility.HtmlEncode(objBidInput.PhoneCondition);//Re-globe diagnostics
                        objBidMaster.PhoneCondition = string.Empty;//changes on 08 feb 2016 by prashant 
                        objBidMaster.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.NewBid); //objBidInput.CurrentStatus;
                        objBidMaster.SubmittedDate = DateTime.Now;
                        objBidMaster.BidCount = 0; //Initial value                    
                        objBidMaster.ReglobeBidValidity = DateTime.Now.AddDays(ReglobeBidExpiryDays); //Adding number of days to expire 
                        objBidMaster.refCode = objBidInput.refCode.Trim();// aUcJQgqVbirdDP1IiRfoMmCf1XNUVlf
                        foreach (var item in objBidInput.UpgradeProductDetails)
                        {
                            objBidMaster.MyGalaxyBidDetails.Add(new MyGalaxyBidDetail
                            {
                                ModelCode = item.ModelCode,//Upgrade mobile name 
                                ModelName = item.ModelName,//Upgrade mobile Code 
                                TransactionId = objBidInput.TransactionId,
                                CreatedDate = DateTime.Now
                            });
                        }
                        //list of phone condition added on 08 feb 2016 by prashant
                        foreach (var item in objBidInput.lstPhoneCondition)
                        {
                            objBidMaster.MyGalaxyPhoneConditions.Add(new MyGalaxyPhoneCondition
                            {
                                TransactionId = objBidInput.TransactionId,
                                Key = item.Key,
                                Label = item.Label,
                                Value = item.Value
                            });
                        }
                        objDbContext.MyGalaxyBidMasters.Add(objBidMaster);
                        objDbContext.Entry<MyGalaxyBidMaster>(objBidMaster).State = System.Data.EntityState.Added;
                        result = objDbContext.SaveChanges();

                        //Get the list of dealers within 5 km radius from spp db 
                        //Call geolocation Services for get location : shaif 6 may 2016
                        //string Address_locality;
                        //SPPGeoLocationDTO.GeoCity(objBidMaster.CurrentLongitude, objBidMaster.CurrentLatitude, out Address_locality);
                        //dealersList = objDbContext.SPGetDealerList(Convert.ToDecimal(DealerRadius), Convert.ToDecimal(objBidInput.CurrentLatitude), Convert.ToDecimal(objBidInput.CurrentLongitude), "", TopDealerCount).ToList();
                        if (RadiusType > 0)
                        {

                            string pincode = string.Empty;
                            reQuoteReglobePrice = ReQuoteReglobePrice(objBidInput.refCode.Trim(), out errorResponse);
                            if (reQuoteReglobePrice == false)
                            {
                                serresult = -2;
                            }
                            if (serresult != -2)// for logging error made changes 
                            {
                                JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                                MGReQuoteResponseDTO requote_list =
                                        json_serializer.Deserialize<MGReQuoteResponseDTO>(errorResponse);
                                foreach (var item in requote_list.pin)
                                {
                                    pincode = item.ToString();
                                }
                            }

                            //string pincode = string.Empty;
                            //string URL = "http://samsungotex.test.reglobe.in/otex/details?oid=" + objBidInput.refCode.Trim();
                            //string response= getPinCodebyrefid_reglobe(URL, "");
                            //JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                            //Dictionary<string, object> res = (Dictionary<string, object>)json_serializer.DeserializeObject(response);
                            //if (res.ContainsKey("error") ==true)
                            //{
                            //    pincode = "";
                            //}
                            //else if (res.ContainsKey("pin") == true)
                            //{

                            //    pincode = res["pin"].ToString();
                            //}
                            //else
                            //{
                            //    pincode = "";
                            //}


                            System.Data.Objects.ObjectResult<int?> redius = objDbContext.spMyGalaxyGetRadiusbycity(pincode, RadiusType.ToString());

                            foreach (int? ired in redius)
                            {
                                if (ired != null)
                                {
                                    dealersList = objDbContext.SPGetDealerList(Convert.ToDecimal(ired), Convert.ToDecimal(objBidInput.CurrentLatitude), Convert.ToDecimal(objBidInput.CurrentLongitude), "", TopDealerCount).ToList();
                                }
                                //else
                                //{
                                //    //Get the list of dealers within 5 km radius from spp db 
                                //    dealersList = objDbContext.SPGetDealerList(Convert.ToDecimal(DealerRadius), Convert.ToDecimal(objBidInput.CurrentLatitude), Convert.ToDecimal(objBidInput.CurrentLongitude), "", TopDealerCount).ToList();
                                //}
                            }
                        }
                        //else
                        //{
                        //    //Get the list of dealers within 5 km radius from spp db 
                        //    dealersList = objDbContext.SPGetDealerList(Convert.ToDecimal(DealerRadius), Convert.ToDecimal(objBidInput.CurrentLatitude), Convert.ToDecimal(objBidInput.CurrentLongitude), "", TopDealerCount).ToList();
                        //}
                        if (dealersList.Count == 0)
                        {
                            dealersList = objDbContext.SPGetDealerList(Convert.ToDecimal(DealerRadius), Convert.ToDecimal(objBidInput.CurrentLatitude), Convert.ToDecimal(objBidInput.CurrentLongitude), "", TopDealerCount).ToList();
                        }
                        if (BuyBackSingleDealer == 1)
                        {

                            // DataTable sIMEIDealer = GetActivationDetailsToS2P2(IMEI_No);
                            if (sIMEIDealer.Rows.Count > 0)
                            {
                                string dealer = sIMEIDealer.Rows[0]["Tertiary_buyer_code"].ToString();
                                SaveBidForDealersIEMI(dealer, objBidInput.TransactionId, objDbContext);
                            }
                            else // if there are no any dealer info related to IEMI No
                            {
                                SaveBidForDealers(dealersList, objBidInput.TransactionId, objDbContext);
                            }
                        }
                        else
                        {
                            SaveBidForDealers(dealersList, objBidInput.TransactionId, objDbContext);
                        }



                        // for sending to notification to dealer we need to call this function with status 9
                        SendNotifications("9");
                    }
                    else
                    {
                        result = -2;

                    }

                }
                scope.Complete();
            }
        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("PostUserBid - MyGalaxyBidMaster", ex.Message, "My Galaxy MCS",
                                Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 0);
        }
        return result;
    }

    /// <summary>
    /// SaveBidForDealers into MyGalaxyDealerBidRequest
    /// </summary>
    /// <param name="dealers"></param>
    /// <param name="objDbContext"></param>
    /// <returns></returns> 
    public int SaveBidForDealers(List<SPGetDealerList_Result> dealers, string TransactionId, SamsungPortalEntitiesDB objDbContext)
    {
        int result = 0;
        foreach (var item in dealers)
        {
            var objDealer = new MyGalaxyDealerBidRequest();
            objDealer.DealerCode = item.partnercode;
            objDealer.TransactionId = TransactionId;
            objDealer.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.Initialize);//default value 0
            objDealer.CreatedDate = DateTime.Now;
            //Add Dealer Latitude and Longitude if required already return in the list 
            objDbContext.MyGalaxyDealerBidRequests.Add(objDealer);
            objDbContext.Entry<MyGalaxyDealerBidRequest>(objDealer).State = System.Data.EntityState.Added;
        }
        result = objDbContext.SaveChanges();
        return result;


    }

    /// <summary>
    /// SaveBidForDealers into MyGalaxyDealerBidRequest
    /// </summary>
    /// <param name="dealers"></param>
    /// <param name="objDbContext"></param>
    /// <returns></returns> 
    public int SaveBidForDealersIEMI(string dealers, string TransactionId, SamsungPortalEntitiesDB objDbContext)
    {
        int result = 0;

        var objDealer = new MyGalaxyDealerBidRequest();
        objDealer.DealerCode = dealers;
        objDealer.TransactionId = TransactionId;
        objDealer.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.Initialize);//default value 0
        objDealer.CreatedDate = DateTime.Now;
        //Add Dealer Latitude and Longitude if required already return in the list 
        objDbContext.MyGalaxyDealerBidRequests.Add(objDealer);
        objDbContext.Entry<MyGalaxyDealerBidRequest>(objDealer).State = System.Data.EntityState.Added;

        result = objDbContext.SaveChanges();
        return result;


    }

    /// <summary>
    /// Get user Bid 
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public List<MGDealerBidDetailDTO> GetUserBid(MGUserBidDTO JsonUserBid)
    {
        List<MGDealerBidDetailDTO> bidDetails = new List<MGDealerBidDetailDTO>();
        SPPUtility objUtility = new SPPUtility();
        try
        {
            InitializeConfigSettings();
            int BidHistoryDuration = GetConfigValue<int>(KEY_BIDHISTORYVISIBILITY, (int)ConfigType.Internal);
            DateTime expiryDate = DateTime.Now.AddDays(-BidHistoryDuration);

            using (SamsungPortalEntitiesDB objDbContext = new SamsungPortalEntitiesDB())
            {
                //changes Added for BidHistoryVisibility by prashant on 4th feb 2016
                var bids = objDbContext.MyGalaxyDealerBidRequests.Where(x => x.DealerCode.ToLower() == JsonUserBid.DealerCode.ToLower() && x.MyGalaxyBidMaster.DateOfCreation >= expiryDate && (string.IsNullOrEmpty(JsonUserBid.TransactionId) || x.TransactionId == JsonUserBid.TransactionId));
                //  var bids = objDbContext.MyGalaxyDealerBidRequests.Where(x => x.DealerCode.ToLower() == JsonUserBid.DealerCode.ToLower() );
                foreach (var bid in bids)
                {
                    MGDealerBidDetailDTO bidObj = new MGDealerBidDetailDTO();
                    bidObj.TransactionId = bid.TransactionId;
                    bidObj.DateOfCreation = bid.MyGalaxyBidMaster.DateOfCreation.ToString();
                    bidObj.ModelCode = bid.MyGalaxyBidMaster.ModelCode;
                    bidObj.ModelName = String.IsNullOrEmpty(bid.MyGalaxyBidMaster.ModelName) ? bid.MyGalaxyBidMaster.ModelCode : bid.MyGalaxyBidMaster.ModelName;
                    bidObj.ReGlobePercentage = bid.MyGalaxyBidMaster.ReGlobePercentage;
                    //----------------------------Bid Amount -----------------------------------
                    bidObj.BidMaxAmount = GetConfigValue<int>(KEY_BIDMAXAMOUNT, (int)ConfigType.Internal);
                    bidObj.BidMinAmount = GetConfigValue<int>(KEY_BIDMINAMOUNT, (int)ConfigType.Internal);
                    bidObj.BidMaxPercentage = GetConfigValue<int>(KEY_BIDMAXPERCENTAGET, (int)ConfigType.Internal);
                    bidObj.BidMinPercentage = GetConfigValue<int>(KEY_BIDMINPERCENTAGET, (int)ConfigType.Internal);
                    bidObj.MinFlag = GetConfigValue<string>(KEY_MINFLAG, (int)ConfigType.Internal);
                    bidObj.MaxFlag = GetConfigValue<string>(KEY_MAXFLAG, (int)ConfigType.Internal);
                    //-------------------------------------------------------------------------
                    bidObj.ReGlobePrice = bid.MyGalaxyBidMaster.ReGlobePrice;
                    bidObj.PhoneCondition = System.Web.HttpUtility.HtmlDecode(bid.MyGalaxyBidMaster.PhoneCondition);
                    bidObj.CurrentServerTime = DateTime.Now.ToString();
                    bidObj.ReglobeBidValidity = bid.MyGalaxyBidMaster.ReglobeBidValidity.ToString();
                    bidObj.IMEI_No = bid.MyGalaxyBidMaster.IMEI_No;
                    bidObj.refCode = bid.MyGalaxyBidMaster.refCode.Trim();

                    //User has accepted the bid

                    //var acceptedBid = bid.MyGalaxyBidMaster.MyGalaxyBidOfferDetails.FirstOrDefault(x => x.MyGalaxyBidOffer.DealerCode == JsonUserBid.DealerCode);
                    //if (acceptedBid != null)
                    //{
                    //    MGUserAcceptanceBidDataDTO acceptedBidObj = new MGUserAcceptanceBidDataDTO();
                    //    acceptedBidObj.UserName = acceptedBid.CustomerName;
                    //    acceptedBidObj.UserMobile = acceptedBid.CustomerMoblie;
                    //    acceptedBidObj.OfferID = Convert.ToInt64(acceptedBid.OfferId);
                    //    acceptedBidObj.InterestdateTime = acceptedBid.InterestdateTime.ToString();
                    //    bidObj.UserAcceptanceDetails = acceptedBidObj;
                    //}

                    //User details who did bid 5/27/2016
                    if (bid.MyGalaxyBidMaster.MyGalaxyBidOfferDetails.Count > 0)
                    {
                        bidObj.UserEmail = bid.MyGalaxyBidMaster.MyGalaxyBidOfferDetails.ElementAt(0).CustomerEmail;
                        bidObj.UserName = bid.MyGalaxyBidMaster.MyGalaxyBidOfferDetails.ElementAt(0).CustomerName;
                        bidObj.UserMobile = bid.MyGalaxyBidMaster.MyGalaxyBidOfferDetails.ElementAt(0).CustomerMoblie;
                    }
                    // send user acceptance in list ----- changes on 03 Feb 2016 by prashant  
                    var acceptedBids = bid.MyGalaxyBidMaster.MyGalaxyBidOfferDetails.Where(x => x.MyGalaxyBidOffer.DealerCode.ToLower() == JsonUserBid.DealerCode.ToLower()).ToList();
                    if (acceptedBids.Count > 0)
                    {
                        List<MGUserAcceptanceBidDataDTO> lstAcceptedBid = new List<MGUserAcceptanceBidDataDTO>();
                        foreach (var item in acceptedBids)
                        {
                            //bool ReQuoteRequested = false;
                            DataTable dt = new DataTable();
                            dt = SPGetRequoteStatus(item.TransactionId);

                            MGUserAcceptanceBidDataDTO acceptedBidObj = new MGUserAcceptanceBidDataDTO();
                            acceptedBidObj.UserName = item.CustomerName;
                            acceptedBidObj.UserMobile = item.CustomerMoblie;
                            acceptedBidObj.UserEmail = System.Web.HttpUtility.HtmlDecode(item.CustomerEmail);//Added on 4 feb 2016 by prashant
                            acceptedBidObj.OfferID = item.OfferId.Value;
                            acceptedBidObj.InterestdateTime = item.InterestdateTime.ToString();
                            if (dt.Rows.Count > 0)
                            {
                                if (!string.IsNullOrEmpty(dt.Rows[0].ToString()))
                                {
                                    if (Int16.Parse(dt.Rows[0]["TotalRecords"].ToString()) > 0)
                                    {
                                        acceptedBidObj.ReQuoteRequested = true;
                                    }
                                    else
                                    {
                                        acceptedBidObj.ReQuoteRequested = false;
                                    }
                                }
                            }
                            lstAcceptedBid.Add(acceptedBidObj);
                        }
                        bidObj.ListUserAcceptanceDetails = lstAcceptedBid;
                    }

                    var dealerBids = bid.MyGalaxyBidMaster.MyGalaxyBidOffers.Where(x => x.DealerCode.ToLower() == JsonUserBid.DealerCode.ToLower()).ToList();
                    if (dealerBids.Count > 0)//Dealer has placed a bid
                    {
                        List<MGBidProductDetailsDTO> productDetailsList = new List<MGBidProductDetailsDTO>();
                        decimal OldPhonePrice = 0;
                        foreach (var product in dealerBids)
                        {
                            MGBidProductDetailsDTO productDetailsObj = new MGBidProductDetailsDTO();
                            productDetailsObj.OfferID = product.OfferId;
                            productDetailsObj.ModelCode = product.UpgradeModelCode;
                            productDetailsObj.ModelName = product.UpgradeModelName;
                            productDetailsObj.Price = product.UpgradeModelPrice.Value;
                            productDetailsObj.TransactionId = product.TransactionId;
                            productDetailsObj.TopUpOffer = System.Web.HttpUtility.HtmlDecode(product.TopUpOffer);
                            OldPhonePrice = product.OldPhonePrice.Value;
                            productDetailsList.Add(productDetailsObj);
                        }
                        bidObj.UpgradeProductDetails = productDetailsList;
                        bidObj.OldPhoneBidPrice = OldPhonePrice;
                    }
                    else
                    {
                        List<MGBidProductDetailsDTO> productDetailsList = new List<MGBidProductDetailsDTO>();
                        foreach (var product in bid.MyGalaxyBidMaster.MyGalaxyBidDetails)
                        {
                            MGBidProductDetailsDTO productDetailsObj = new MGBidProductDetailsDTO();
                            productDetailsObj.ModelCode = product.ModelCode;
                            productDetailsObj.ModelName = product.ModelName;
                            productDetailsObj.Price = 0;
                            productDetailsObj.TransactionId = product.TransactionId;
                            productDetailsObj.OfferID = 0;
                            productDetailsObj.TopUpOffer = string.Empty;
                            productDetailsList.Add(productDetailsObj);
                        }
                        bidObj.UpgradeProductDetails = productDetailsList;
                        bidObj.OldPhoneBidPrice = 0;
                    }
                    bidObj.DisplayTopUp = GetConfigValue<string>(KEY_DISPLAYTOPUP, (int)ConfigType.Internal);  //To show dealer offer or not
                    // Logic to check the current status of the bid.
                    DateTime bidExpiryTime = Convert.ToDateTime(bid.MyGalaxyBidMaster.DateOfCreation);
                    int ConfigurationHours = bid.MyGalaxyBidMaster.ConfigurationHours.Value;//Dealer ConfigurationHours value from DB BidMaster
                    int BidCountLimit = GetConfigValue<int>(KEY_BIDCOUNTLIMIT, (int)ConfigType.Internal); // Dealer Bid count limit per transaction 
                    bidExpiryTime = bidExpiryTime.AddHours(ConfigurationHours);
                    bidObj.ConfigurationHours = ConfigurationHours;

                    DateTime ReglobeBidValidity = bid.MyGalaxyBidMaster.ReglobeBidValidity.Value;

                    //Closed Bid : A bid is set as closed bid incase reglobe bid time has elapsed or bid is closed by dealer
                    if (DateTime.Now > ReglobeBidValidity && bid.MyGalaxyBidMaster.CurrentStatus != Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested))//|| bid.MyGalaxyBidMaster.CurrentStatus == Convert.ToInt32(SPPUtility._BidStatus.Closed))
                    {
                        bidObj.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.Closed);
                    }
                    //BidPlaced : A bid is set as Dealer bid in case dealer has placed the bid for same and bid requested time is less than ConfiguredHours or bid is not expired.
                    // else if (bid.MyGalaxyBidMaster.CurrentStatus != Convert.ToInt32(SPPUtility._BidStatus.Expired) && dealerBids.Count > 0 && (DateTime.Now < dateofcreation))
                    else if (dealerBids.Count > 0)
                    {
                        //bidObj.CurrentStatus = Convert.ToInt32(SPPUtility._BidStatus.BidPlaced);
                        //if (bid.MyGalaxyBidMaster.CurrentStatus == 3 || bid.MyGalaxyBidMaster.CurrentStatus == 2)
                        //    bidObj.CurrentStatus = Convert.ToInt32(SPPUtility._BidStatus.ReglobePickupRequested);
                        bidObj.CurrentStatus = bid.MyGalaxyBidMaster.CurrentStatus;
                        if (bid.MyGalaxyBidMaster.CurrentStatus == Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested) && (!acceptedBids.Any(x => x.CurrentStatus == Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested))))//Reglobe initiated by other: if current bid is requested for pickup and offer is below this dealer
                            bidObj.CurrentStatus = (int)SPPUtility._BidMasterStatus.ReglobePickupRequestedByOther;

                    }
                    //Expired : A bid is set as Expired bid incase requested time is greater than ConfiguredHours or bid count is more than limit set.
                    //else if (DateTime.Now >= dateofcreation || bid.MyGalaxyBidMaster.BidCount >= BidCountLimit || bid.MyGalaxyBidMaster.CurrentStatus == Convert.ToInt32(SPPUtility._BidStatus.Expired))
                    else if (DateTime.Now > bidExpiryTime || bid.MyGalaxyBidMaster.BidCount >= BidCountLimit || bid.MyGalaxyBidMaster.CurrentStatus == Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested))
                    {
                        //bidObj.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.Expired);
                        bidObj.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.NewBid);
                        bidObj.BidTimeOut = true;
                    }
                    else
                    {
                        bidObj.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.NewBid);

                    }
                    if (bid.MyGalaxyBidMaster.CurrentStatus == Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested))
                        bidObj.PickupStatus = true;
                    else
                        bidObj.PickupStatus = false;

                    bidDetails.Add(bidObj);
                }
            }
        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("GetUserBid", ex.Message, "My Galaxy MCS",
                                Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), Convert.ToInt32(JsonUserBid.useridcode));
        }
        return bidDetails;
    }

    /// <summary>
    /// Get user Bid 
    /// </summary>
    /// <param name="input"></param>
    /// <returns></returns>
    public List<Bid> GetAllUsersBid()
    {
        List<Bid> bidDetails = new List<Bid>();
        SPPUtility objUtility = new SPPUtility();
        MGEmailExcelDTO mgEmailExcelDTO;
        BidStatus bidStatus = new BidStatus();
        Bid bid;

        try
        {
            InitializeConfigSettings();
            int BidHistoryDuration = GetConfigValue<int>(KEY_BIDHISTORYVISIBILITY, (int)ConfigType.Internal);
            DateTime expiryDate = DateTime.Now.AddDays(-BidHistoryDuration);

            using (SamsungPortalEntitiesDB objDbContext = new SamsungPortalEntitiesDB())
            {
                var bids = objDbContext.MyGalaxyDealerBidRequests.Where(x => !string.IsNullOrEmpty(x.DealerCode));
                foreach (var bd in bids)
                {
                    string offerIdsString = "";
                    string[] offerIds;
                    mgEmailExcelDTO = new MGEmailExcelDTO();
                    if (bd.MyGalaxyBidMaster.MyGalaxyBidDetails.Count > 0)
                    {
                        if (bd.MyGalaxyBidMaster.MyGalaxyBidOffers.Count > 0)
                        {
                            foreach (MyGalaxyBidOfferDetail myGalaxyBidOfferDetail in bd.MyGalaxyBidMaster.MyGalaxyBidOfferDetails)
                            {
                                if (string.IsNullOrEmpty(offerIdsString))
                                {
                                    if (myGalaxyBidOfferDetail.CurrentStatus.Value == 3)
                                    {
                                        offerIdsString = offerIdsString + "|Y" + "," + myGalaxyBidOfferDetail.OfferId.Value + "|Y";
                                    }
                                    else
                                    {
                                        offerIdsString = offerIdsString + "|N" + "," + myGalaxyBidOfferDetail.OfferId.Value + "|N";
                                    }
                                }
                                else
                                {
                                    if (myGalaxyBidOfferDetail.CurrentStatus.Value == 3)
                                    {
                                        offerIdsString = offerIdsString + "," + myGalaxyBidOfferDetail.OfferId.Value + "|Y";
                                    }
                                    else
                                    {
                                        offerIdsString = offerIdsString + "," + myGalaxyBidOfferDetail.OfferId.Value + "|N";
                                    }
                                }

                            }
                            offerIds = offerIdsString.Split(',');

                            foreach (MyGalaxyBidOffer mbo in bd.MyGalaxyBidMaster.MyGalaxyBidOffers)
                            {
                                bid = new Bid();
                                bid.DealerCode = bd.DealerCode;
                                bid.Status = bd.MyGalaxyBidMaster.CurrentStatus.Value.ToString();
                                bid.TransactionId = bd.TransactionId;
                                bid.DateOfCreation = bd.CreatedDate.ToString();
                                bid.ModelName = bd.MyGalaxyBidMaster.ModelName;
                                bid.ModelCode = bd.MyGalaxyBidMaster.ModelCode;
                                bid.IMEI = bd.MyGalaxyBidMaster.IMEI_No;
                                bid.ReGlobePrice = bd.MyGalaxyBidMaster.ReGlobePrice.ToString();
                                bid.ReGlobeValidity = bd.MyGalaxyBidMaster.ReglobeBidValidity.ToString();
                                bid.UpgradeOfferModelCode = mbo.UpgradeModelCode;
                                bid.UpgradeOfferModelName = mbo.UpgradeModelName;
                                bid.BidOfferPrice = mbo.UpgradeModelPrice.ToString();
                                bid.NetPrice = (mbo.UpgradeModelPrice - bd.MyGalaxyBidMaster.ReGlobePrice).ToString();
                                bid.OfferId = mbo.OfferId.ToString();
                                bid.BidCount = bd.MyGalaxyBidMaster.BidCount.Value;
                                bid.ConfigurationHour = bd.MyGalaxyBidMaster.ConfigurationHours.Value;
                                bid.ConfigBidCount = int.Parse(ConfigurationManager.AppSettings["BidCountLimit"]);

                                TimeSpan diff = DateTime.Now - bd.CreatedDate.Value;
                                double hours = diff.TotalHours;
                                if (hours > bd.MyGalaxyBidMaster.ConfigurationHours.Value)
                                {
                                    bid.TimeElapsed = "Y";
                                }

                                if (mbo.DealerCode.ToLower() == bd.DealerCode.ToLower())
                                    bid.ThisUser = "Y";
                                else
                                    bid.ThisUser =
                                        "N";

                                foreach (string offerId in offerIds)
                                {
                                    if (!string.IsNullOrEmpty(offerId))
                                    {
                                        if (mbo.OfferId.ToString() == offerId.Split('|')[0] && mbo.DealerCode.ToLower() == bd.DealerCode.ToLower())
                                        {
                                            bid.UserInterest = "Y";
                                        }
                                        if (offerId.Split('|')[1] == "Y" && mbo.DealerCode.ToLower() == bd.DealerCode.ToLower() && mbo.OfferId.ToString() == offerId.Split('|')[0])
                                        {
                                            bid.ReGlobePickUp = "Y";
                                        }
                                    }
                                }

                                bidDetails.Add(bid);
                            }
                        }
                        else
                        {
                            foreach (MyGalaxyBidDetail mbd in bd.MyGalaxyBidMaster.MyGalaxyBidDetails)
                            {
                                bid = new Bid();
                                bid.DealerCode = bd.DealerCode;
                                bid.Status = bd.MyGalaxyBidMaster.CurrentStatus.Value.ToString();
                                bid.TransactionId = bd.TransactionId;
                                bid.DateOfCreation = bd.CreatedDate.ToString();
                                bid.ModelName = bd.MyGalaxyBidMaster.ModelName;
                                bid.ModelCode = bd.MyGalaxyBidMaster.ModelCode;
                                bid.IMEI = bd.MyGalaxyBidMaster.IMEI_No;
                                bid.ReGlobePrice = bd.MyGalaxyBidMaster.ReGlobePrice.ToString();
                                bid.ReGlobeValidity = bd.MyGalaxyBidMaster.ReglobeBidValidity.ToString();
                                bid.UpgradeOfferModelCode = mbd.ModelCode;
                                bid.UpgradeOfferModelName = mbd.ModelName;
                                bid.ThisUser = "NA";
                                bidDetails.Add(bid);
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("GetAllUsersBid - GetAllUsersBid", ex.Message, "My Galaxy MCS",
                                   Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 1);
        }
        return bidDetails;
    }



    /// <summary>
    /// Post Dealer Bid into MyGalaxyBidOffers
    /// </summary>
    /// <param name="listBidOffersInput"></param>
    /// <returns></returns>
    public int PostDealerBid(PostBidOfferCheckDTO objbidoffercheck, List<MyGalaxyConfigurationSetting> objConfigSettings)
    {
        int result = 0;
        int bidcount = 0;
        SPPUtility objUtility = new SPPUtility();
        string errorResponse = string.Empty;
        try
        {
            lstConfigSettings = objConfigSettings;
            int Maxbidcount = GetConfigValue<int>(KEY_BIDCOUNTLIMIT, (int)ConfigType.Internal); //Convert.ToInt32(ConfigurationManager.AppSettings[KEY_BIDCOUNTLIMIT].ToString());
            string IsPostBidOffer = GetConfigValue<string>(KEY_SENDPOSTBIDOFFER, (int)ConfigType.External); //Convert.ToString(ConfigurationManager.AppSettings[KEY_SENDPOSTBIDOFFER].ToString());

            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions
            {
                IsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted
            }))
            {
                using (SamsungPortalEntitiesDB objDbContext = new SamsungPortalEntitiesDB())
                {
                    MyGalaxyBidOffer objBidOffer = null;

                    if (objbidoffercheck.listBidOffersInput != null && objbidoffercheck.listBidOffersInput.Count > 0)
                    {
                        var uniqueTransaction = objbidoffercheck.listBidOffersInput.FirstOrDefault().TransactionId;
                        MyGalaxyBidMaster bidmaster = objDbContext.MyGalaxyBidMasters.FirstOrDefault(x => x.TransactionId == uniqueTransaction);
                        if (bidmaster != null)
                        {
                            // Logic to check the validity of the bid.
                            DateTime bidExpiryTime = Convert.ToDateTime(bidmaster.DateOfCreation);
                            int ConfigurationHours = bidmaster.ConfigurationHours.Value;//Dealer ConfigurationHours value from DB BidMaster
                            bidExpiryTime = bidExpiryTime.AddHours(ConfigurationHours);

                            if (DateTime.Now < bidExpiryTime)
                            {
                                bidcount = bidmaster.BidCount ?? 0;

                                if (bidcount < Maxbidcount)//check bid count from config table
                                {
                                    foreach (var item in objbidoffercheck.listBidOffersInput)
                                    {
                                        objBidOffer = new MyGalaxyBidOffer();
                                        {
                                            objBidOffer.TransactionId = item.TransactionId;
                                            objBidOffer.DealerCode = objbidoffercheck.userid;//userid=dealercode
                                            objBidOffer.UpgradeModelCode = item.UpgradeModelCode;
                                            objBidOffer.UpgradeModelName = item.UpgradeModelName;
                                            objBidOffer.UpgradeModelPrice = item.UpgradeModelPrice;
                                            objBidOffer.OldPhonePrice = item.OldPhonePrice;
                                            objBidOffer.TopUpOffer = System.Web.HttpUtility.HtmlEncode(item.TopUpOffer);
                                            objBidOffer.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.Initialize);//default value 0
                                            //objBidOffer.NotificationServiceId = null;
                                            objBidOffer.CreatedDate = DateTime.Now;
                                            objDbContext.MyGalaxyBidOffers.Add(objBidOffer);
                                            objDbContext.Entry<MyGalaxyBidOffer>(objBidOffer).State = System.Data.EntityState.Added;
                                        }
                                    }
                                    bidcount++;
                                    bidmaster.BidCount = bidcount;
                                    bidmaster.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.BidPlaced);
                                    //objDbContext.MyGalaxyBidMasters.Add(bidmaster);
                                    objDbContext.Entry<MyGalaxyBidMaster>(bidmaster).State = System.Data.EntityState.Modified;
                                    result = objDbContext.SaveChanges();
                                }
                                else
                                {
                                    result = -1;
                                }
                            }
                            else
                            {
                                result = -3; //bidExpired

                            }

                        }
                        else
                        {
                            result = -1;
                        }
                    }
                    if (result > 0)
                    {

                        List<MyGalaxyBidOffer> dealerBids = objDbContext.MyGalaxyBidOffers.Local.ToList();
                        bool myGalaxyIsSuccess = true;
                        //IsPostBidOffer = "0";// To be remove before commit
                        if (IsPostBidOffer == "1")//call to my galaxy
                            myGalaxyIsSuccess = PostMyGalaxy(objbidoffercheck, dealerBids, objDbContext, out errorResponse);

                        if (myGalaxyIsSuccess == false)//fail to post my galaxy bid offer
                            //return result = -2;  change on 04 feb 2016
                            result = -2;

                        if (result != -2)// for logging error made changes 
                        {
                            foreach (var item in dealerBids)
                            {
                                item.CurrentStatus = 1; //submitted and send                               
                            }
                            objDbContext.SaveChanges();
                            scope.Complete();
                        }
                    }
                }
                // scope.Complete();

                //if (errorResponse.Contains("\"ErrCode\": 1,"))

            }
            if (result == -2)// for logging error made changes                         
            {
                objUtility.InsertintoErrorLog("PostMyGalaxy - SendHttpRequest", "Error In Post My Galaxy BidOffer : " + errorResponse, "My Galaxy MCS",
                      Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 0);
            }

        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("PostDealerBid - MyGalaxyBidOffer", ex.Message, "My Galaxy MCS",
                                Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), Convert.ToInt32(objbidoffercheck.useridcode));
        }
        return result;
    }

    /// <summary>
    /// Calling My galaxy service send dealerbids and get response isSuccess
    /// </summary>
    /// <param name="dealerBids"></param>
    /// <returns></returns>
    public bool PostMyGalaxy(PostBidOfferCheckDTO objbidoffercheck, List<MyGalaxyBidOffer> dealerBids, SamsungPortalEntitiesDB objDbContext, out string errorResponse)
    {
        //return true;     
        SPPUtility objUtility = new SPPUtility();
        SPGetDealerList_Result dealersDetail = new SPGetDealerList_Result();
        string jsonBody = null;
        bool status = false;
        try
        {
            InitializeConfigSettings();
            string useridcode = GetConfigValue<string>(KEY_POSTUSERIDCODE, (int)ConfigType.External);
            string apikey = GetConfigValue<string>(KEY_POSTAPIKEY, (int)ConfigType.External);
            string apitoken = GetConfigValue<string>(KEY_POSTAPITOKEN, (int)ConfigType.External);
            string MyGalaxyServiceBaseURL = GetConfigValue<string>(KEY_MYGALAXYSERVICE_URL, (int)ConfigType.External);

            //Add BidExpirytime on 04 feb 2016
            //int expiryhours = GetConfigValue<int>(KEY_CONFIGHOURS, (int)ConfigType.Internal);
            //DateTime BidExpiryTime = DateTime.Now.AddHours(expiryhours);

            //Add ReglobeBidValidityDays to current datetime and send this as expiry time to MyGalaxy.
            int expiryDays = GetConfigValue<int>(KEY_REGLOBEBIDVALIDITYDAYS, (int)ConfigType.External);
            DateTime BidExpiryTime = DateTime.Now.AddDays(expiryDays);


            //get dealer detail from spp server and send it to MyGalaxy   
            dealersDetail = objDbContext.SPGetDealerList(0, 0, 0, objbidoffercheck.userid, 0).FirstOrDefault();//changes for TopDealerCount

            //Code to send data to MYGalaxy

            string ContentType = "application/json";//json ContentType for MyGalaxy 
            var jsonOffers = string.Empty;
            string txtID = string.Empty;
            int counter = 0;
            //json body creation 
            foreach (var item in dealerBids)
            {
                counter++;
                if (counter == 1)//Start of offers
                    jsonOffers = ",\"offers\":[";
                txtID = item.TransactionId;

                jsonOffers = jsonOffers + "{\"UpgradeModelCode\":\"" + item.UpgradeModelCode + "\",\"UpgradeModelName\":\"" + item.UpgradeModelName + "\",\"UpgradeModelMarketPrice\":\"" + "00" + "\",\"UpgradeModelPrice\":\"" + item.UpgradeModelPrice + "\",\"OldPhonePrice\":\"" + item.OldPhonePrice + "\",\"BidExpiryTime\":\"" + BidExpiryTime + "\",\"TopUpOffer\":\"" + item.TopUpOffer + "\",\"OfferID\":\"" + item.OfferId + "\"}";
                if (counter == dealerBids.Count)
                    jsonOffers = jsonOffers + "]";
                else
                    jsonOffers = jsonOffers + ",";
            }

            if (dealersDetail != null)
            {
                if (dealersDetail.OwnerMobileNumber.Length < 10)
                    dealersDetail.OwnerMobileNumber = "9999999999";
                jsonBody = "{\"TransactionID\":\"" + txtID + "\",\"DealerCode\":\"" + objbidoffercheck.userid + "\",\"DealerName\":\"" + dealersDetail.PartnerName + "\",\"useridcode\":\"" + useridcode + "\",\"apikey\":\"" + apikey + "\",\"apitoken\":\"" + apitoken + "\",\"DealerAddress\":\"" + dealersDetail.Address + "\",\"DealerContact\":\"" + dealersDetail.OwnerMobileNumber + "\",\"DealerLat\":\"" + dealersDetail.Latitude + "\",\"DealerLong\":\"" + dealersDetail.Longitude + "\"";
            }
            jsonBody = jsonBody + jsonOffers + "}";
            ////send http request to MyGalaxy
            string response = SendHttpRequest(MyGalaxyServiceBaseURL, jsonBody, ContentType);
            errorResponse = response;
            if (response.Contains("\"ErrCode\":0,"))
                status = true;

        }
        catch (Exception ex)
        {
            status = false;
            errorResponse = "PostMyGalaxy error: " + ex.Message + "JsonBody : " + jsonBody;
        }
        return status;
    }

    /// <summary>
    /// Insert User Bid interest into MyGalaxyBidOfferDetail
    /// </summary>
    /// <param name="objBidOffersDetail"></param>
    /// <returns></returns>
    public int PostUserInterest(MGBidOffersDetailDTO objBidOffersDetail)
    {
        SPPUtility objUtility = new SPPUtility();
        int result = 0;
        try
        {
            //List<MyGalaxyBidOfferDetail> lstAllOffer=null;
            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions
            {
                IsolationLevel = System.Transactions.IsolationLevel.ReadUncommitted
            }))
            {
                using (SamsungPortalEntitiesDB objDbContext = new SamsungPortalEntitiesDB())
                {
                    if (objBidOffersDetail != null)
                    {
                        MyGalaxyBidOffer availableOffer = objDbContext.MyGalaxyBidOffers.FirstOrDefault(x => x.TransactionId == objBidOffersDetail.TransactionId && x.OfferId == objBidOffersDetail.OfferId);
                        if (availableOffer != null)
                        {
                            if (availableOffer.MyGalaxyBidMaster.CurrentStatus != Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested))
                            {
                                if (Convert.ToDateTime(objBidOffersDetail.CreatedDate) > availableOffer.CreatedDate)//check interest date should be greater than bid placed date
                                {
                                    //changes for same offerid 
                                    MyGalaxyBidOfferDetail userinterest = objDbContext.MyGalaxyBidOfferDetails.FirstOrDefault(x => x.OfferId == objBidOffersDetail.OfferId);
                                    if (userinterest == null)
                                    {
                                        MyGalaxyBidOfferDetail objBidOfferdetail = new MyGalaxyBidOfferDetail();
                                        {
                                            //User Post interest for a mobile 
                                            objBidOfferdetail.OfferId = objBidOffersDetail.OfferId;
                                            objBidOfferdetail.TransactionId = objBidOffersDetail.TransactionId;
                                            objBidOfferdetail.CustomerName = objBidOffersDetail.CustomerName;
                                            objBidOfferdetail.CustomerMoblie = objBidOffersDetail.CustomerMobile;
                                            objBidOfferdetail.CustomerEmail = System.Web.HttpUtility.HtmlEncode(objBidOffersDetail.CustomerEmail);
                                            objBidOfferdetail.CurrentStatus = 0; // 0: Accepted 
                                            objBidOfferdetail.NotificationServiceId = null;
                                            objBidOfferdetail.InterestdateTime = Convert.ToDateTime(objBidOffersDetail.CreatedDate);//check parameter name
                                            objBidOfferdetail.CreatedDate = DateTime.Now;
                                            objDbContext.MyGalaxyBidOfferDetails.Add(objBidOfferdetail);
                                            objDbContext.Entry<MyGalaxyBidOfferDetail>(objBidOfferdetail).State = System.Data.EntityState.Added;

                                        }
                                        result = objDbContext.SaveChanges();
                                        scope.Complete();
                                        SendNotifications("10");
                                    }
                                    else
                                    {
                                        result = -1;
                                    }
                                }
                                else
                                {
                                    result = -3;
                                }
                            }
                            else
                            {
                                result = -4;
                            }
                        }
                        else
                        {
                            result = -2;
                        }
                    }
                }

            }
            // for sending to notification to dealer for user interest in the bid need to call this function with status 10

        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("PostUserInterest - MyGalaxyBidOfferDetail", ex.Message, "My Galaxy MCS",
                               Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 0);
        }
        return result;
    }

    /// <summary>
    /// Update status in MyGalaxyBidMaster for PostBidCloser
    /// </summary>
    /// <param name="objPostBidClose"></param>
    /// <returns></returns>
    public int PostBidCloser(PostBidCloseDTO objPostBidClose)
    {
        int result = 0;
        SPPUtility objUtility = new SPPUtility();
        string errorResponse = string.Empty;
        try
        {
            InitializeConfigSettings();
            string PostReglobePickup = GetConfigValue<string>(KEY_SENDREGLOBEPICKUP, (int)ConfigType.External); //Convert.ToString(ConfigurationManager.AppSettings[KEY_SENDREGLOBEPICKUP].ToString());
            //int reglobePickupStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested);
            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions
            {
                IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted
            }))
            {
                using (SamsungPortalEntitiesDB objDbContext = new SamsungPortalEntitiesDB())
                {
                    MyGalaxyBidOfferDetail objOfferDetail = null;
                    //check valid transaction and offer id 
                    MyGalaxyBidOffer validOffer = objDbContext.MyGalaxyBidOffers.FirstOrDefault(x => x.TransactionId == objPostBidClose.TransactionId && x.OfferId == objPostBidClose.OfferID);
                    if (validOffer != null)
                    {
                        //MyGalaxyBidMaster objBidMaster = objDbContext.MyGalaxyBidMasters.FirstOrDefault(k => k.TransactionId == objPostBidClose.TransactionId);
                        MyGalaxyBidMaster objBidMaster = validOffer.MyGalaxyBidMaster;
                        if (objBidMaster.CurrentStatus != (int)SPPUtility._BidMasterStatus.ReglobePickupRequested)//check if already reglobe pickup return -1
                        {
                            objOfferDetail = objBidMaster.MyGalaxyBidOfferDetails.FirstOrDefault(x => x.OfferId == objPostBidClose.OfferID);

                            bool reGlobePickupIsSuccess = true;
                            //PostReglobePickup = "0";// To be remove before commit
                            if (PostReglobePickup == "1")//call reglobe pickup
                                reGlobePickupIsSuccess = PostReGlobePickUpRequest(objPostBidClose, objDbContext, objBidMaster, out errorResponse);

                            if (reGlobePickupIsSuccess == false)//fail to post reglobepickup
                                //return result = -2;
                                result = -2; //change for error log

                            if (result != -2)// for logging error made changes 
                            {
                                //if (reGlobePickupIsSuccess == true && objBidMaster != null && objOfferDetail != null && objBidMaster.CurrentStatus != Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested))
                                //{
                                objOfferDetail.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested);
                                objBidMaster.CurrentStatus = Convert.ToInt32(SPPUtility._BidMasterStatus.ReglobePickupRequested);//status  should be Close and send (NEED TO CHANGE)
                                objBidMaster.ModifiedDate = System.DateTime.Now;

                                //Added by prashant on 9th feb 2016
                                string[] refIDData = errorResponse.Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
                                string refID = string.Empty;

                                if (refIDData.Length > 0)
                                {
                                    string[] refIDs = refIDData[1].Split(new char[] { '"' }, StringSplitOptions.RemoveEmptyEntries);
                                    if (refIDs.Length > 0)
                                    {
                                        refID = refIDs[0];
                                    }
                                }
                                objBidMaster.ReglobeRefId = refID;//to save Re-Globe Response need to split if required on  9th feb 2016 by prashant 
                                objDbContext.Entry<MyGalaxyBidMaster>(objBidMaster).State = System.Data.EntityState.Modified;
                                result = objDbContext.SaveChanges();
                                //}
                                scope.Complete();
                            }
                        }
                        else
                        {
                            result = -1;

                        }
                    }
                }
            }
            if (result == -2)// for logging error made changes                         
            {
                objUtility.InsertintoErrorLog("PostReGlobePickUpRequest - SendHttpRequest", "Error In PostReglobePickup 2 : " + errorResponse, "My Galaxy MCS",
                      Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 0);
            }
        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("PostBidCloser - MyGalaxyBidMaster", ex.Message, "My Galaxy MCS",
                               Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 0);
        }
        return result;
    }

    /// <summary>
    /// Calling My galaxy service send dealerbids and get response isSuccess
    /// </summary>
    /// <param name="dealerBids"></param>
    /// <returns></returns>
    public bool PostReGlobePickUpRequest(PostBidCloseDTO objPostBidClose, SamsungPortalEntitiesDB objDbContext, MyGalaxyBidMaster objBidMaster, out string errorResponse)
    {
        bool status = false;
        string response = string.Empty;
        string postdata = string.Empty;
        string ErrorLog = string.Empty;
        SPPUtility objUtility = new SPPUtility();
        SPGetDealerList_Result dealersList = new SPGetDealerList_Result();
        try
        {
            //get dealer detail from spp server and send it to reglobe       

            dealersList = objDbContext.SPGetDealerList(0, 0, 0, objPostBidClose.userid, 0).FirstOrDefault();//changes for TopDealerCount 
            ErrorLog = "Get Delear List";
            ////To get refCode from MyGalaxyBidMasters 
            //MyGalaxyBidMaster objBidMaster = objDbContext.MyGalaxyBidMasters.FirstOrDefault(k => k.TransactionId == objPostBidClose.TransactionId);

            //To get partnerRef (offerid) from MyGalaxyBidOfferDetails 
            MyGalaxyBidOfferDetail objBidOffer = objDbContext.MyGalaxyBidOfferDetails.FirstOrDefault(k => k.TransactionId == objPostBidClose.TransactionId);

            ErrorLog = "Get BidOffer";

            if (dealersList != null)
            //Code to send data to Reglobe
            {
                //string jsonBody = "{\"name\":\"" + dt.Rows[0]["CONTACT_PERSON"].ToString() + "\",\"mobile\":\"" + dt.Rows[0]["MOBILE_NO"].ToString() + "\",\"pincode\":\"" + dt.Rows[0]["POSTAL_CD"].ToString() + "\",\"email\":\"" + dt.Rows[0]["EMAIL"].ToString() + "\",\"address\":\"" + address + "\",\"refCode\":\"" + objPostBidClose.TransactionId + "\",\"partnerRef\":\"" + objPostBidClose.TransactionId + "\"}";

                NameValueCollection outgoingQueryString = HttpUtility.ParseQueryString(String.Empty);
                outgoingQueryString.Add("name", dealersList.PartnerName);
                if (dealersList.OwnerMobileNumber.Length < 10)
                    outgoingQueryString.Add("mobile", "9999999999");
                else
                    outgoingQueryString.Add("mobile", dealersList.OwnerMobileNumber);
                ErrorLog = "Assign Mobile No";

                // check pincode is null or not
                if (String.IsNullOrEmpty(dealersList.PinCode))
                    outgoingQueryString.Add("pincode", GetPinCodeByLatLong(dealersList.Latitude, dealersList.Longitude));  // id pincode is null or empty send default value 110044       
                else
                    outgoingQueryString.Add("pincode", dealersList.PinCode);
                ErrorLog = "GetPinCodeByLatLong";
                outgoingQueryString.Add("email", dealersList.EmailId);
                outgoingQueryString.Add("address", dealersList.Address);
                outgoingQueryString.Add("refCode", objBidMaster.refCode);//"J69YW4EH");
                outgoingQueryString.Add("partnerRef", Convert.ToString(objBidOffer.OfferId));//"Samsung Order id");
                postdata = outgoingQueryString.ToString();// form-data format and send it to reglobe

                string ReglobeServiceBaseURL = GetConfigValue<string>(KEY_REGLOBESERVICE_URL, (int)ConfigType.External); //Convert.ToString(ConfigurationManager.AppSettings[KEY_REGLOBESERVICE_URL]); //"http://samsungotex.test.reglobe.in/otex/request-pickup";//TODO AppCOnfig
                ReglobeServiceBaseURL = ReglobeServiceBaseURL + "/otex/request-pickup";   // change in 2nd phase for common url of Reglobe
                string ContentType = "application/x-www-form-urlencoded";//form-data ContentType for reglobe 

                //send http request to reglobe
                response = SendHttpRequest(ReglobeServiceBaseURL, postdata, ContentType);
                ErrorLog = "SendHttpRequest";
                if (response.Contains("sno") && response.Contains("oid"))//check responce -- change if get error 
                    status = true;
            }
            errorResponse = response;
        }
        catch (Exception ex)
        {
            errorResponse = "PostReGlobePickUpRequest error 1 : " + ex.Message + " transId: " + objPostBidClose.TransactionId + " response: " + response + " postdata: " + postdata + "ErrorLog:" + ErrorLog;
        }
        return status;
    }

    /// <summary>
    /// Method Name   : GetOfferProduct
    /// Createdby     : Manoo Rishi
    /// Created On    : 15 Jan 2016
    /// Description   : Function to Get Offer Productlist
    /// </summary>
    /// <param name="OfferProductRequest"></param>
    /// <returns>DataTable</returns>
    public DataTable GetOfferProduct(MGOfferProductRequestDTO OfferProductRequest)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsOfferProductList = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsOfferProductList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SPGetOfferProductList",
                                  new SqlParameter("@MobileCode", OfferProductRequest.MobileModelCode));
            if (dsOfferProductList.Tables.Count > 0)
            {
                dt = objUtility.GenericReplace(dsOfferProductList.Tables[0]);
            }
            else
            {
                dt = new DataTable();
            }
        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("GetOfferProduct - SPGetOfferProductList", ex.Message, "My Galaxy MCS",
                                 Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 0);
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;

    }

    /// <summary>
    /// Function to send Notifications
    /// </summary>
    public void SendNotifications(string notificationCategory)
    {
        SPPUtility objUtility = new SPPUtility();
        try
        {
            string argument = notificationCategory + ",0,0";
            System.Diagnostics.Process prc = new System.Diagnostics.Process();
            prc.StartInfo.FileName = HttpContext.Current.Server.MapPath("~") + "\\bin\\Notifications\\SamsungPortalWindows.AppNotifications.UI.exe";
            prc.StartInfo.Arguments = argument;
            prc.Start();
        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("Notification - SendNotifications", ex.Message, "My Galaxy MCS",
                                 Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 0);
        }
    }

    /// <summary>
    /// Create Http request for My galaxy and reglobe
    /// </summary>
    /// <param name="headers"></param>
    /// <param name="body"></param>
    /// <param name="servicename"></param>
    /// <returns></returns>
    private static string SendHttpRequest(string URL, string body, string ContentType)
    {
        try
        {
            WebHeaderCollection headers = new WebHeaderCollection();
            HttpWebRequest req = WebRequest.Create(URL) as HttpWebRequest;
            req.Method = "POST";
            // Create POST data and convert it to a byte array.
            string postData = body;
            byte[] byteArray = Encoding.UTF8.GetBytes(postData);
            req.Headers = headers;
            req.ContentType = ContentType; // "application/x-www-form-urlencoded";
            // Set the ContentLength property of the WebRequest.
            req.ContentLength = byteArray.Length;
            // Get the request stream.
            Stream dataStream = req.GetRequestStream();
            // Write the data to the request stream.
            dataStream.Write(byteArray, 0, byteArray.Length);
            // Close the Stream object.
            dataStream.Close();
            // Get the response.
            WebResponse wr = req.GetResponse();

            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(wr.GetResponseStream());
            // Read the content.
            string responseFromServer = reader.ReadToEnd();

            reader.Close();

            wr.Close();
            return responseFromServer;
        }
        catch (WebException wex)
        {
            var pageContent = new StreamReader(wex.Response.GetResponseStream())
                                  .ReadToEnd();
            return pageContent;
        }
    }

    /// <summary>
    /// Get Dealers list within vicinity
    /// </summary>
    /// <param name="objDealerListRequest"></param>
    /// <returns></returns>
    public List<MGDealerListResponseDTO> GetDealerListWithAddress(MGDealerListRequestDTO objDealerListRequest)
    {

        //string radius = GetConfigValue<string>(KEY_DEALERRADIUS, 0); 
        //radius is now send by my galaxy - change done on 04 feb 2016
        SamsungPortalEntitiesDB objDbContext = null;
        List<SPGetDealerList_Result> dealersList = new List<SPGetDealerList_Result>();
        List<MGDealerListResponseDTO> lstdealerList = new List<MGDealerListResponseDTO>();
        MGDealerListResponseDTO dealer = new MGDealerListResponseDTO();
        using (objDbContext = new SamsungPortalEntitiesDB())
        {
            var obj = objDbContext.MyGalaxyBidMasters.FirstOrDefault(x => x.TransactionId == objDealerListRequest.TransactionId);
            if (obj != null)
            {
                dealersList = objDbContext.SPGetDealerList(Convert.ToDecimal(objDealerListRequest.DealerRadius), Convert.ToDecimal(obj.CurrentLatitude), Convert.ToDecimal(obj.CurrentLongitude), "", objDealerListRequest.TopDealerCount).ToList();

                lstdealerList = (from SPGetDealerList_Result item in dealersList
                                 select new MGDealerListResponseDTO
                                 {
                                     DealerCode = item.partnercode,
                                     DealerName = item.PartnerName,
                                     DealerAddress = item.Address,
                                     DealerLat = item.Latitude,
                                     DealerLong = item.Longitude,
                                 }).ToList();

            }
        }
        return lstdealerList;
    }

    /// <summary>
    /// Get Configuration Settings
    /// </summary>
    /// <returns></returns>
    public List<ConfigurationSettingsResponseDTO> GetConfigurationSettings()
    {
        List<ConfigurationSettingsResponseDTO> ConfigList = new List<ConfigurationSettingsResponseDTO>();

        using (SamsungPortalEntitiesDB objDbContext = new SamsungPortalEntitiesDB())
        {
            var configEntries = objDbContext.MyGalaxyConfigurationSettings.Where(x => x.IsActive == true && x.IsDeleted == false && x.ConfigType == (int)ConfigType.External);
            foreach (var config in configEntries)
            {
                ConfigurationSettingsResponseDTO ConfigDetails = new ConfigurationSettingsResponseDTO();
                ConfigDetails.Key = config.ConfigKey;
                ConfigDetails.Value = config.ConfigValue;
                ConfigDetails.ConfigSettingId = config.ConfigSettingId.ToString();
                ConfigDetails.Max = config.MaxValue;
                ConfigDetails.Min = config.MinValue;
                ConfigDetails.Type = config.Type;
                ConfigList.Add(ConfigDetails);
            }
        }
        return ConfigList;
    }

    /// <summary>
    /// Save List Configuration Settings
    /// </summary>
    /// <param name="objConfigSettingsList"></param>
    /// <returns></returns>
    public string SaveConfigurationSettingsList(SaveConfigurationSettingsListRequestDTO objConfigSettingsList)
    {
        int result = 0;
        string message = string.Empty;
        using (TransactionScope scope = new TransactionScope())
        {
            using (SamsungPortalEntitiesDB objDbContext = new SamsungPortalEntitiesDB())
            {

                foreach (var objConfigSettings in objConfigSettingsList.ConfigurationSettingsList)
                {
                    int ConfigSettingId = Convert.ToInt32(objConfigSettings.ConfigSettingId);
                    MyGalaxyConfigurationSetting objSettings = objDbContext.MyGalaxyConfigurationSettings.FirstOrDefault(k => k.ConfigSettingId == ConfigSettingId && k.ConfigKey == objConfigSettings.Key);
                    if (objSettings != null)
                    {
                        message = ValidateConfigurationSettings(objSettings, objConfigSettings.Value);
                        if (message == string.Empty)
                        {
                            objSettings.ConfigValue = objConfigSettings.Value;
                            objSettings.ModifiedOn = System.DateTime.Now;
                            objDbContext.Entry<MyGalaxyConfigurationSetting>(objSettings).State = System.Data.EntityState.Modified;
                            result = objDbContext.SaveChanges();
                            if (result > 0)
                            {
                                message = string.Empty;
                            }
                            else
                            {
                                message = "Error saving data!, Key :" + objSettings.ConfigKey;
                                break;
                            }
                        }
                        else
                        {
                            message = message + ", Key :" + objSettings.ConfigKey;
                            break;
                        }
                    }
                    else
                    {
                        message = "Key does not exists!, Key :" + objSettings.ConfigKey;
                        break;
                    }
                }
            }
            scope.Complete();
        }
        return message;
    }

    /// <summary>
    /// Get Phone Condition
    /// </summary>
    /// <returns></returns>
    public List<MyGalaxyPhoneConditionResponseDTO> GetPhoneCondition(MyGalaxyPhoneConditionRequestDTO Jsoninput)
    {
        List<MyGalaxyPhoneConditionResponseDTO> phoneCondList = new List<MyGalaxyPhoneConditionResponseDTO>();

        using (SamsungPortalEntitiesDB objDbContext = new SamsungPortalEntitiesDB())
        {
            var phoneCond = objDbContext.MyGalaxyPhoneConditions.Where(x => x.TransactionId == Jsoninput.TransactionId);
            foreach (var phone in phoneCond)
            {
                MyGalaxyPhoneConditionResponseDTO phoneDetails = new MyGalaxyPhoneConditionResponseDTO();
                phoneDetails.Key = phone.Key;
                phoneDetails.Label = phone.Label;
                phoneDetails.Value = phone.Value;
                phoneCondList.Add(phoneDetails);
            }
        }
        return phoneCondList;
    }

    /// <summary>
    /// Get PinCode By LatLong
    /// </summary>
    /// <param name="Lat"></param>
    /// <param name="Long"></param>
    /// <returns></returns>
    public string GetPinCodeByLatLong(string Lat, string Long)
    {

        SPPUtility objUtility = new SPPUtility();
        string postal = "110044";  // id pincode is null or empty send default value 110044    

        string googleapi = ConfigurationManager.AppSettings[KEY_GOOGLEAPI].ToString(); // "http://maps.googleapis.com/maps/api/geocode/xml?latlng={0}&sensor=false";

        string latlog = Lat + "," + Long;
        var requestUri = string.Format(googleapi, Uri.EscapeDataString(latlog));
        var request = WebRequest.Create(requestUri);
        var response = request.GetResponse();
        var xdoc = XDocument.Load(response.GetResponseStream());
        var result = xdoc.Element("GeocodeResponse").Element("result");
        if (result != null)
        {
            XElement postalCode = (from nm in result.Elements("address_component")
                                   where (string)nm.Element("type") == "postal_code"
                                   select nm).FirstOrDefault();
            if (postalCode != null)
            {
                postal = postalCode.Element("long_name").Value;
            }
        }
        return postal;

    }

    /// <summary>
    /// Get Configuration value from MyGalaxyConfigurationSettings table 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="key"></param>
    /// <param name="Type"></param>
    /// <returns></returns>
    public T GetConfigValue<T>(string key, int Type = 0)
    {
        object value = lstConfigSettings.FirstOrDefault(x => x.IsActive == true && x.IsDeleted == false && x.ConfigKey == key).ConfigValue;
        return (T)Convert.ChangeType(value, typeof(T));
    }

    /// <summary>
    /// Initialize ConfigSettings with DB values.
    /// </summary>
    /// <returns></returns>
    public List<MyGalaxyConfigurationSetting> InitializeConfigSettings()
    {
        using (SamsungPortalEntitiesDB objDbContext = new SamsungPortalEntitiesDB())
        {
            lstConfigSettings = objDbContext.MyGalaxyConfigurationSettings.ToList();
        }

        return lstConfigSettings;
    }

    /// <summary>
    /// Validate Configuration Settings
    /// </summary>
    /// <param name="objConfigSettings"></param>
    /// <returns></returns>
    public string ValidateConfigurationSettings(MyGalaxyConfigurationSetting objSettings, string NewValue)
    {
        string message = string.Empty;
        try
        {
            if (objSettings.Type.ToLower() == "int")
            {

                int NewIntValue;
                if (int.TryParse(NewValue, out NewIntValue))
                {
                    if (NewIntValue >= Convert.ToInt32(objSettings.MinValue) && NewIntValue <= Convert.ToInt32(objSettings.MaxValue))
                    {
                        message = string.Empty;
                    }
                    else
                    {
                        message = "Does not satisfy specified range!";
                    }
                }
                else
                {
                    message = "Value provided for the key should be a number!";
                }

            }
            else if (objSettings.Type.ToLower() == "float")
            {

                float NewIntValue;
                if (float.TryParse(NewValue, out NewIntValue))
                {
                    if (NewIntValue >= Convert.ToSingle(objSettings.MinValue) && NewIntValue <= Convert.ToSingle(objSettings.MaxValue))
                    {
                        message = "true";
                    }
                    else
                    {
                        message = "Does not satisfy specified range!";
                    }
                }
                else
                {
                    message = "Value provided for the key should be a number!";
                }

            }
            else if (objSettings.Type.ToLower() == "string")
            {
                message = string.Empty;

            }
            else
            {
                message = "false";

            }

        }
        catch (Exception ex)
        {
            return message = ex.Message;
        }
        return message;
    }

    public enum ConfigType
    {
        External = 0,
        Internal = 1,
        NotInUse = 2
    }

    #endregion

    #region MyGalaxy second phase Added on 05 April 2016 by Prashant

    /// <summary>
    /// Save Dealer Requote Phone condition and update reglobe price in BidMaster table
    /// </summary>
    /// <param name="objDealerRequote"></param>
    /// <returns></returns>
    public int PostDealerRequote(MGDealerRequoteInputDTO objDealerRequote)
    {
        int result = 0;
        SamsungPortalEntitiesDB objDbContext;
        SPPUtility objUtility = new SPPUtility();
        bool reQuoteReglobePrice = false;
        string errorResponse = string.Empty;
        try
        {
            InitializeConfigSettings();
            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions
            {
                IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted
            }))
            {
                using (objDbContext = new SamsungPortalEntitiesDB())
                {
                    //get list of old phone condition to insert into new table 'MyGalaxyDealersPhoneCondition'
                    IList<MyGalaxyPhoneCondition> lstOldphonecondition = objDbContext.MyGalaxyPhoneConditions.Where(x => x.TransactionId == objDealerRequote.TransactionId).ToList();
                    MyGalaxyPhoneCondition lstOldphoneconditionWithNewOne = objDbContext.MyGalaxyPhoneConditions.FirstOrDefault(x => x.TransactionId == objDealerRequote.TransactionId);
                    //check  data exist or not if no - insert into new table
                    MyGalaxyDealersPhoneCondition dealersPhoneCondition = objDbContext.MyGalaxyDealersPhoneConditions.FirstOrDefault(x => x.TransactionId == objDealerRequote.TransactionId);
                    if (dealersPhoneCondition == null)
                    {
                        if (lstOldphonecondition.Count > 0)
                        {
                            foreach (var item in lstOldphonecondition)
                            {
                                var objDealer = new MyGalaxyDealersPhoneCondition();
                                objDealer.TransactionId = objDealerRequote.TransactionId;
                                objDealer.Key = item.Key;
                                objDealer.Label = item.Label;
                                objDealer.Value = item.Value;
                                objDbContext.Entry<MyGalaxyDealersPhoneCondition>(objDealer).State = System.Data.EntityState.Added;
                            }

                            reQuoteReglobePrice = ReQuoteReglobePrice(objDealerRequote.refCode, out errorResponse);
                            if (reQuoteReglobePrice == false)
                            {
                                result = -2;
                            }
                            if (result != -2)// for logging error made changes 
                            {
                                JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                                MGReQuoteResponseDTO requote_list =
                                        json_serializer.Deserialize<MGReQuoteResponseDTO>(errorResponse);

                                //Update Reglobe price from Requote price
                                MyGalaxyBidMaster objBidMaster = objDbContext.MyGalaxyBidMasters.FirstOrDefault(x => x.TransactionId == objDealerRequote.TransactionId);
                                objBidMaster.OldReGlobePrice = objBidMaster.ReGlobePrice;
                                objBidMaster.ReGlobePrice = Convert.ToDecimal(requote_list.a);

                                //update Phone condition table(lstOldphonecondition) from newlist(requote_list.c) 
                                foreach (var item in requote_list.c)
                                {
                                    lstOldphonecondition.Where(w => w.Key == item.k && w.TransactionId == objDealerRequote.TransactionId).ToList().ForEach(i => i.Key = item.k);
                                    lstOldphonecondition.Where(w => w.Key == item.k && w.TransactionId == objDealerRequote.TransactionId).ToList().ForEach(i => i.Label = item.l);
                                    lstOldphonecondition.Where(w => w.Key == item.k && w.TransactionId == objDealerRequote.TransactionId).ToList().ForEach(i => i.Value = item.t);
                                }

                                objDbContext.Entry<MyGalaxyBidMaster>(objBidMaster).State = System.Data.EntityState.Modified;
                                result = objDbContext.SaveChanges();
                                scope.Complete();
                            }
                        }
                    }
                    else
                    {
                        result = -3;
                    }
                }
            }
            if (result == -2)// for logging error made changes                         
            {
                objUtility.InsertintoErrorLog("ReQuoteReglobePrice - SendHttpRequest", "Error In ReQuoteReglobePrice  : " + errorResponse, "My Galaxy MCS",
                      Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 0);
            }
        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("SubmitDealersPhoneRequote - Error in Requote price: ", ex.Message, "My Galaxy MCS",
                                Convert.ToInt16(SPPUtility._Sections.MyGalaxtMCS), 0);
        }
        return result;
    }

    /// <summary>
    /// Response Requset from Reglobe for Reglobe price 
    /// </summary>
    /// <param name="refCode"></param>
    /// <param name="errorResponse"></param>
    /// <returns></returns>
    public bool ReQuoteReglobePrice(string refCode, out string errorResponse)
    {
        bool status = false;
        string response = string.Empty;
        string postdata = string.Empty;
        string ErrorLog = string.Empty;
        try
        {
            //status = true;
            NameValueCollection outgoingQueryString = HttpUtility.ParseQueryString(String.Empty);
            outgoingQueryString.Add("oid", refCode);

            string ReglobeServiceBaseURL = GetConfigValue<string>(KEY_REGLOBESERVICE_URL, (int)ConfigType.External); //Convert.ToString(ConfigurationManager.AppSettings[KEY_REGLOBESERVICE_URL]); //"http://samsungotex.test.reglobe.in/otex/request-pickup";//TODO AppCOnfig
            //ReglobeServiceBaseURL = "http://samsungotex.stage.reglobe.in";
            ReglobeServiceBaseURL = ReglobeServiceBaseURL + "/otex/details?oid=" + refCode;
            //send http request to reglobe
            response = GetResponse(ReglobeServiceBaseURL);
            ErrorLog = "GetResponse";
            if (response.Contains("oid"))//check responce -- change if get error 
                status = true;

            errorResponse = response;
        }
        catch (Exception ex)
        {
            errorResponse = "ReQuoteReglobePrice error 1 : " + ex.Message + " refCode: " + refCode + " response: " + response + " postdata: " + postdata + "ErrorLog:" + ErrorLog;
        }
        return status;
    }

    public string GetResponse(string URL)
    {
        string responseFromServer = string.Empty;
        try
        {
            Stream dataStream;
            HttpWebRequest request = WebRequest.Create(URL) as HttpWebRequest;
            request.Method = "GET";
            // Get the original response.
            WebResponse response = request.GetResponse();

            string Status = ((HttpWebResponse)response).StatusDescription;

            // Get the stream containing all content returned by the requested server.
            dataStream = response.GetResponseStream();

            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(dataStream);

            // Read the content fully up to the end.
            responseFromServer = reader.ReadToEnd();
            // Clean up the streams.
            reader.Close();

            dataStream.Close();

            response.Close();
        }
        catch (WebException wex)
        {
            var pageContent = new StreamReader(wex.Response.GetResponseStream())
                                  .ReadToEnd();
            return pageContent;
        }
        return responseFromServer;
    }

    public DataTable SPGetRequoteStatus(string TransactionId)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsInboxMessageDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsInboxMessageDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SPGetRequoteStatus",
                                  new SqlParameter("@TransactionId", TransactionId));
            dt = objUtility.GenericReplace(dsInboxMessageDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;

    }

    #endregion

    #region MyGalaxy second phase Added on 26 July 2016 by Shaif
    /// <summary>
    /// Used Get ActivationDate And Terciary Buyer Code On Behalf Of IMEI
    /// </summary>
    /// <param name="sUserID">sIMEI</param>
    /// <returns></returns>
    public DataTable GetActivationDetailsToS2P2(string sIMEI)
    {
        DataLayer dtLayer = null;
        try
        {
            dtLayer = new DataLayer();
            return SqlHelper.ExecuteDataset(dtLayer.GetMCSConnectionTest(), CommandType.StoredProcedure, "spActivationDetailsToS2P2",
                                                                                                new SqlParameter("@IMEI", sIMEI)).Tables[0];
        }
        catch (Exception ex)
        {
            //Custom Error Handling 
            DataTable errTab = new DataTable();

            DataColumn errCol = new DataColumn("ErrCol");
            errCol.DataType = System.Type.GetType("System.string");
            errTab.Columns.Add(errCol);

            DataRow rw = errTab.NewRow();
            rw["Error"] = ex.Message.ToString();


            errTab.Dispose();
            return errTab;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    public DataTable GetActivationDetailsToS2P2Inline(string sIMEI)
    {
        DataLayer dtLayer = null;
        try
        {
            string strcmd = "	SELECT Activation_Date,Tertiary_buyer_code,Source  FROM DBO.IMEITracker_IMEI_Transaction_Data (NOLOCK) WHERE IMEI1=" + sIMEI;
            dtLayer = new DataLayer();
            return SqlHelper.ExecuteDataset(dtLayer.GetMCSConnectionTest(), CommandType.Text, strcmd).Tables[0];
        }
        catch (Exception ex)
        {
            //Custom Error Handling 
            DataTable errTab = new DataTable();

            DataColumn errCol = new DataColumn("ErrCol");
            errCol.DataType = System.Type.GetType("System.string");
            errTab.Columns.Add(errCol);

            DataRow rw = errTab.NewRow();
            rw["Error"] = ex.Message.ToString();


            errTab.Dispose();
            return errTab;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }
    private string getPinCodebyrefid_reglobe(string URL, string DATA)
    {
        string response = string.Empty;
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
        request.Method = "GET";
        request.ContentType = "application/json";
        //request.ContentLength = DATA.Length;
        //using (Stream webStream = request.GetRequestStream())
        //using (StreamWriter requestWriter = new StreamWriter(webStream, System.Text.Encoding.ASCII))
        //{
        //    requestWriter.Write(DATA);
        //}

        try
        {
            WebResponse webResponse = request.GetResponse();
            using (Stream webStream = webResponse.GetResponseStream())
            {
                if (webStream != null)
                {
                    using (StreamReader responseReader = new StreamReader(webStream))
                    {
                        response = responseReader.ReadToEnd();
                        //Console.Out.WriteLine(response);
                    }
                }
            }
        }
        catch (Exception e)
        {

        }
        return response;
    }


    #endregion


    #region MyReward First phase Added on 17 Oct 2016 by Shaif
    /// <summary>
    /// Get My Reward details
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public MyRewardResponseDTO GetRewardDetials(string sPartnerCode)
    {
        MyRewardResponseDTO myRewardResponseDTO = new MyRewardResponseDTO();
        myRewardResponseDTO.modulelist = new List<Module>();
        myRewardResponseDTO.menulist = new List<Menu>();

        Module oModule = null;
        Menu oMenu = null;

        MyRewardResponseDTO oMyRewardResponseDTO = null;
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";
        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardGetRewardDetials",
                                                                                                new SqlParameter("@PartnerCode", sPartnerCode));
            while (dr.Read())
            {

                if (dr["WalletBalance"] != null)
                    myRewardResponseDTO.rewardpoint = dr["WalletBalance"].ToString();
                if (dr["openingBalance"] != null)
                    myRewardResponseDTO.openingbalance = dr["openingBalance"].ToString();

                //  myRewardResponseDTO.Reward.Add(omyreward);

            }
            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    oModule = new Module();
                    if (dr["ModuleID"] != null)
                        oModule.moduleid = Convert.ToInt32(dr["ModuleID"].ToString());

                    if (dr["Module"] != null)
                        oModule.modulename = dr["Module"].ToString();
                    if (dr["Moduleimg"] != null)
                        oModule.moduleimg = objUtility.GetFilePath(vImagePath + dr["Moduleimg"].ToString());


                    myRewardResponseDTO.modulelist.Add(oModule);

                }

            }



            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    oMenu = new Menu();
                    if (dr["MenuID"] != null)
                        oMenu.menuid = Convert.ToInt32(dr["MenuID"].ToString());

                    if (dr["MenuName"] != null)
                        oMenu.menuname = dr["MenuName"].ToString();


                    if (dr["IconImagePath"] != null)
                        oMenu.iconimagepath = objUtility.GetFilePath(vImagePath + dr["IconImagePath"].ToString());


                    myRewardResponseDTO.menulist.Add(oMenu);

                }

            }
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return myRewardResponseDTO;
    }

    /// <summary>
    /// Get My Reward details
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<MyRewardResponseCategoryDTO> GetRewardCategory(int ModuleID)
    {
        MyRewardResponseCategoryDTO myRewardcategory = null;
        List<MyRewardResponseCategoryDTO> myRewardcategoryList = new List<MyRewardResponseCategoryDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardGetCategory",
                                                                                                new SqlParameter("@ModuleID", ModuleID));


            while (dr.Read())
            {
                myRewardcategory = new MyRewardResponseCategoryDTO();
                if (dr["CategoryID"] != null)
                    myRewardcategory.categoryid = Convert.ToInt32(dr["CategoryID"].ToString());

                if (dr["CategoryName"] != null)
                    myRewardcategory.categoryname = dr["CategoryName"].ToString();
                if (dr["icon"] != null)

                    myRewardcategory.categoryimage = objUtility.GetFilePath(vImagePath + dr["icon"].ToString());


                myRewardcategoryList.Add(myRewardcategory);

            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return myRewardcategoryList;
    }

    /// <summary>
    /// Get My Reward details
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<MyRewardResponseTermConditionDTO> GetRewardConfig()
    {
        MyRewardResponseTermConditionDTO myRewardcategory = null;
        List<MyRewardResponseTermConditionDTO> myRewardcategoryList = new List<MyRewardResponseTermConditionDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardTermCondition");


            while (dr.Read())
            {
                myRewardcategory = new MyRewardResponseTermConditionDTO();
                if (dr["configid"] != null)
                    myRewardcategory.configid = Convert.ToInt32(dr["configid"].ToString());
                if (dr["Termandcondtion"] != null)
                    myRewardcategory.termandcondition = dr["Termandcondtion"].ToString();



                myRewardcategoryList.Add(myRewardcategory);

            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return myRewardcategoryList;
    }



    /// <summary>
    /// Get My Reward Product
    /// </summary>
    /// <param name="ModuleID">ModuleID</param>
    /// <returns></returns>
    public MyRewardResponseProductDTO GetRewardProduct(int ModuleID, int CategoryID, int StateID)
    {
        MyRewardResponseProductDTO myRewardResponseDTO = new MyRewardResponseProductDTO();
        myRewardResponseDTO.productlist = new List<Product>();
        List<voucherpoint> vlist = new List<voucherpoint>();
        voucherpoint ov = null;
        Product oProduct = null;
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";
        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardGetProduct",
                                                                                                new SqlParameter("@ModuleID", ModuleID),
                                                                                                new SqlParameter("@CategoryID", CategoryID),
                                                                                                new SqlParameter("@StateID", StateID));

            while (dr.Read())
            {
                oProduct = new Product();
                if (dr["ProductID"] != null)
                    oProduct.productid = Convert.ToInt32(dr["ProductID"].ToString());
                if (dr["BrandID"] != null)
                    oProduct.brandid = Convert.ToInt32(dr["BrandID"].ToString());

                if (dr["Producttitle"] != null)
                    oProduct.producttitle = dr["Producttitle"].ToString();

                if (dr["Description"] != null)
                    oProduct.description = dr["Description"].ToString();

                if (dr["Point"] != null)
                    oProduct.point = float.Parse(dr["Point"].ToString());
                if (dr["BrandName"] != null)
                    oProduct.brandname = dr["BrandName"].ToString();
                if (dr["Termandcondition"] != null)
                    oProduct.termandcondition = dr["Termandcondition"].ToString();

                if (dr["ProductThumImg"] != null)
                    oProduct.productthumimg = objUtility.GetFilePath(vImagePath + dr["ProductThumImg"].ToString());
                if (dr["ProductImg"] != null)
                    oProduct.productimg = objUtility.GetFilePath(vImagePath + dr["ProductImg"].ToString());
                if (dr["ModuleID"] != null)
                    oProduct.moduleid = Convert.ToInt32(dr["ModuleID"].ToString());

                myRewardResponseDTO.productlist.Add(oProduct);

            }
            if (dr.NextResult())
            {
                while (dr.Read())
                {

                    //Stuff will come here for next result
                    ov = new voucherpoint();
                    if (dr["MyRewardVoucherPoint"] != null)
                        ov.voucherid = Convert.ToInt32(dr["MyRewardVoucherPoint"].ToString());
                    if (dr["ProductID"] != null)
                        ov.productid = Convert.ToInt32(dr["ProductID"].ToString());
                    if (dr["Point"] != null)
                        ov.point = Convert.ToInt32(dr["point"].ToString());
                    vlist.Add(ov);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        if (myRewardResponseDTO.productlist != null && myRewardResponseDTO.productlist.Count > 0)
        {
            for (int i = 0; i < myRewardResponseDTO.productlist.Count; i++)
            {

                for (int j = 0; j < vlist.Count; j++)
                {
                    if (myRewardResponseDTO.productlist[i].productid == vlist[j].productid)
                    {
                        myRewardResponseDTO.productlist[i].voucherlist = vlist.Where(x => x.productid == myRewardResponseDTO.productlist[i].productid).ToList();

                    }

                }

            }

        }
        return myRewardResponseDTO;
    }

    /// <summary>
    /// Get My Reward Holidays Filters [Duration list and Destination List]
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public MyRewardResponseHolidayFilterDTO GetRewardHolidayFilters()
    {
        MyRewardResponseHolidayFilterDTO objHolidayDTO = new MyRewardResponseHolidayFilterDTO();
        objHolidayDTO.destinationlist = new List<Destination>();
        objHolidayDTO.durationlist = new List<Duration>();

        Destination oDestination = null;
        Duration oDuration = null;

        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.AppMenu.Replace("\\", "/") + "/";
        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardGetHolidaySearch");
            while (dr.Read())
            {
                oDestination = new Destination();
                if (dr["DestinationID"] != null)
                    oDestination.destinationid = dr["DestinationID"].ToString();
                if (dr["DestinationName"] != null)
                    oDestination.destinationname = dr["DestinationName"].ToString();

                objHolidayDTO.destinationlist.Add(oDestination);

            }
            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    oDuration = new Duration();
                    if (dr["DurationID"] != null)
                        oDuration.durationid = dr["DurationID"].ToString();
                    if (dr["DurationName"] != null)
                        oDuration.durationname = dr["DurationName"].ToString();

                    objHolidayDTO.durationlist.Add(oDuration);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return objHolidayDTO;
    }



    /// <summary>
    /// Get My Reward Holidays packages [on the basis of DurationID and DestinationID]
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<MyRewardHolidayPackagesResponseDTO> GetRewardHolidayPackages(string Destinationid, string Durationid)
    {
        List<MyRewardHolidayPackagesResponseDTO> objHolidayPackagesList = new List<MyRewardHolidayPackagesResponseDTO>();

        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardHolidayPackages"
                                                                                    , new SqlParameter("@DestinationID", Destinationid)
                                                                                    , new SqlParameter("@DurationID", Durationid));



            while (dr.Read())
            {
                MyRewardHolidayPackagesResponseDTO objHolidayDTO = new MyRewardHolidayPackagesResponseDTO();

                if (dr["Destination"] != null)
                    objHolidayDTO.destination = dr["Destination"].ToString();

                if (dr["Duration"] != null)
                    objHolidayDTO.duration = dr["Duration"].ToString();

                if (dr["Point"] != null)
                    objHolidayDTO.points = dr["Point"].ToString();

                if (dr["HolidayBackground"] != null)
                    objHolidayDTO.holidaybackgroundimg = objUtility.GetFilePath(vImagePath + dr["HolidayBackground"].ToString());

                if (dr["HolidayIcon"] != null)
                    objHolidayDTO.holidayiconimg = objUtility.GetFilePath(vImagePath + dr["HolidayIcon"].ToString());


                if (dr["Producttitle"] != null)
                    objHolidayDTO.producttitle = dr["Producttitle"].ToString();

                if (dr["ProductID"] != null)
                {
                    objHolidayDTO.productid = Convert.ToInt32(dr["ProductID"]);

                    SqlDataReader drExp = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardHolidayExperience"
                                                                                    , new SqlParameter("@ProductID", Convert.ToInt32(dr["ProductID"].ToString())));


                    List<Experience> objExpList = new List<Experience>();
                    while (drExp.Read())
                    {
                        Experience objExp = new Experience();
                        if (drExp["HolydayExperience"] != null)
                            objExp.experience = drExp["HolydayExperience"].ToString();

                        objExpList.Add(objExp);
                    }
                    objHolidayDTO.experiencelist = objExpList;

                }
                objHolidayPackagesList.Add(objHolidayDTO);
            }
        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("Function - MyRewardHolidayPackages", ex.Message, "HolidayPackage",
                   Convert.ToInt16(SPPUtility._Sections.MyRewardHolidayPackages), 1);
        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

        return objHolidayPackagesList;
    }

    public MyRewardPackageDetailsResponseDTO GetHolidayPackageDetails(int ProductID)
    {
        MyRewardPackageDetailsResponseDTO objHolidayDetailsDTO = new MyRewardPackageDetailsResponseDTO();

        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";

        int ParentFilterID = 3, action = 1;//We are using 3 to get Inclusion Summary all filters from DB

        try
        {
            //--TO CHECK AVAILABLE INCLUSION SUMMARY--
            dtLayer = new DataLayer();
            SqlDataReader drAllIncSummaryFilters = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardGetFilters"
                                                                                    , new SqlParameter("@ParentFilterID", ParentFilterID)
                                                                                    , new SqlParameter("@Action", action));
            //--END--

            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardPackageDetails"
                                                                                    , new SqlParameter("@ProductID", ProductID));
            string Mealinfo = GetRewardConfig().Where(x => x.configid == Convert.ToInt32(enummyreward.Meal)).ToList()[0].termandcondition;

            List<InclusionSummary> olstIncSummary = new List<InclusionSummary>();
            List<BordingPlace> olstBordingPlace = new List<BordingPlace>();
            while (dr.Read())
            {
                if (dr["Description"] != null)
                    objHolidayDetailsDTO.description = dr["Description"].ToString();

                if (dr["ItineraryDays"] != null)
                    objHolidayDetailsDTO.itinerarydays = dr["ItineraryDays"].ToString();

                if (dr["ProductImg"] != null)
                    objHolidayDetailsDTO.productimg = objUtility.GetFilePath(vImagePath + dr["ProductImg"].ToString());

                if (dr["TermandCondition"] != null)
                    objHolidayDetailsDTO.termandcondition = dr["TermandCondition"].ToString();


                if (dr["ProductID"] != null)
                {
                    objHolidayDetailsDTO.productid = Convert.ToInt32(dr["ProductID"]);

                    SqlDataReader drExp = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardHolidayExperience"
                                                                                   , new SqlParameter("@ProductID", Convert.ToInt32(dr["ProductID"].ToString())));


                    List<DaywiseExperience> oDaywiseExperienceList = new List<DaywiseExperience>();
                    while (drExp.Read())
                    {
                        DaywiseExperience objDWExp = new DaywiseExperience();
                        if (drExp["HolydayExperience"] != null)
                            objDWExp.holidayexperience = drExp["HolydayExperience"].ToString();

                        if (drExp["Moduleimg"] != null)
                            objDWExp.thumbimg = objUtility.GetFilePath(vImagePath + drExp["Moduleimg"].ToString());

                        if (drExp["DayNo"] != null)
                            objDWExp.dayno = drExp["DayNo"].ToString();

                        if (drExp["DayDescription"] != null)
                        {
                            objDWExp.daydescription = "<html>" + drExp["DayDescription"].ToString() + Mealinfo + "</html>";
                        }

                        if (drExp["DaywiseBanner"] != null)
                            objDWExp.daywisebanner = objUtility.GetFilePath(vImagePath + drExp["DaywiseBanner"].ToString());

                        oDaywiseExperienceList.Add(objDWExp);
                    }
                    objHolidayDetailsDTO.daywiseexperience = oDaywiseExperienceList;
                }
            }
            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    InclusionSummary oInclusionSummary = new InclusionSummary();

                    if (dr["Filter"] != null)
                        oInclusionSummary.incsummaryname = dr["Filter"].ToString();

                    if (dr["FilterImage"] != null)
                        oInclusionSummary.incsummaryimg = objUtility.GetFilePath(vImagePath + dr["FilterImage"].ToString());

                    olstIncSummary.Add(oInclusionSummary);
                }
                objHolidayDetailsDTO.inclusionsummary = olstIncSummary;
            }
            // bp.BordingPlaceID,BordingPlace,Point
            if (dr.NextResult())
            {
                while (dr.Read())
                {
                    BordingPlace oBordingPlace = new BordingPlace();

                    if (dr["BordingPlaceID"] != null)
                        oBordingPlace.bordingplaceid = Convert.ToInt32(dr["BordingPlaceID"].ToString());

                    if (dr["BordingPlace"] != null)
                        oBordingPlace.bordingplace = dr["BordingPlace"].ToString();
                    if (dr["Point"] != null)
                        oBordingPlace.point = dr["Point"].ToString();

                    olstBordingPlace.Add(oBordingPlace);
                }
                objHolidayDetailsDTO.bordingPlace = olstBordingPlace;
            }

        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("Function - GetHolidayPackageDetails", ex.Message, "HolidayPackage",
                   Convert.ToInt16(SPPUtility._Sections.MyRewardPackageDetails), 1);
        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return objHolidayDetailsDTO;

    }

    /// <summary>
    /// SaveRewardProductCart
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<MyRewardProductResponseCartDTO> SaveRewardProductCart(string OrderCode, string DealerCode, string cartlistxml, int ModuleID, string RequestID)
    {
        MyRewardProductResponseCartDTO oMyRewardProductResponseCartDTO = new MyRewardProductResponseCartDTO();
        List<MyRewardProductResponseCartDTO> list = new List<MyRewardProductResponseCartDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        object orderid = null;
        string retval = string.Empty;
        try
        {
            dtLayer = new DataLayer();
            orderid = SqlHelper.ExecuteScalar(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardFinalSave",
                new SqlParameter("@OrderCode", OrderCode),
                new SqlParameter("@DealerCode", DealerCode),
                new SqlParameter("@cartlist", cartlistxml),
                 new SqlParameter("@ModuleID", ModuleID),
                  new SqlParameter("@RequestID", RequestID));

            if (orderid != null)
            {
                retval = orderid.ToString();
                oMyRewardProductResponseCartDTO.Point = Convert.ToDouble(retval);
                list.Add(oMyRewardProductResponseCartDTO);
            }


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return list;
    }
    /// <summary>
    /// Estore Purchase Accessories Response
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public int SaveEstorePurchaseAccessoriesResponse(string paxml, string orgpaxml)
    {
        MyRewardProductResponseCartDTO oMyRewardProductResponseCartDTO = new MyRewardProductResponseCartDTO();
        List<MyRewardProductResponseCartDTO> list = new List<MyRewardProductResponseCartDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        object orderid = null;
        int retval = 0;

        try
        {
            dtLayer = new DataLayer();
            orderid = SqlHelper.ExecuteScalar(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spPA_EstorePurchaseAccessoriesResponse",
                new SqlParameter("@palist", paxml), new SqlParameter("@orgpaxml", orgpaxml));

            if (orderid != null)
            {
                retval = Convert.ToInt32(orderid.ToString());


            }


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return retval;
    }

    /// <summary>
    /// Estore Purchase Accessories Response
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public int SaveEstorePurchaseAccessoriesOrderdetailsResponse(string orderlist)
    {
        MyRewardProductResponseCartDTO oMyRewardProductResponseCartDTO = new MyRewardProductResponseCartDTO();
        List<MyRewardProductResponseCartDTO> list = new List<MyRewardProductResponseCartDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        object orderid = null;
        int retval = 0;

        try
        {
            dtLayer = new DataLayer();
            orderid = SqlHelper.ExecuteScalar(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spPA_EstorePurchaseAccessoriesOrderDetailsResponse",
                new SqlParameter("@orderlist", orderlist));

            if (orderid != null)
            {
                retval = Convert.ToInt32(orderid.ToString());
                objUtility.InsertintoLog("step 12:calling SaveEstorePurchaseAccessoriesOrderdetailsResponse sucess orderid " + orderid.ToString() + "  ", "", "get PurchaseAccessories History",
   Convert.ToInt16(SPPUtility._Sections.PurchaseAccessories), 0);

            }


        }
        catch (Exception ex)
        {
            objUtility.InsertintoLog("step 11:calling SaveEstorePurchaseAccessoriesOrderdetailsResponse error " + ex.Message + ex.InnerException + "  ", "", "get PurchaseAccessories History",
    Convert.ToInt16(SPPUtility._Sections.PurchaseAccessories), 0);

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return retval;
    }
    /// <summary>
    /// SaveRewardProductCart
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public DataSet SaveRewardValidateProductCart(string DealerCode, string cartlistxml)
    {
        MyRewardProductResponseCartDTO oMyRewardProductResponseCartDTO = new MyRewardProductResponseCartDTO();
        List<MyRewardProductResponseCartDTO> list = new List<MyRewardProductResponseCartDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        DataSet datavalidate = null;
        string retval = string.Empty;
        try
        {
            dtLayer = new DataLayer();
            datavalidate = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardValidateFinalSave",

                new SqlParameter("@DealerCode", DealerCode),
                new SqlParameter("@cartlist", cartlistxml)
             );




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return datavalidate;
    }

    public DataTable GetOrderProductbyRequestID(string RequestID)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsInboxMessageDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;

        try
        {
            dsInboxMessageDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardOrderProductbyRequestID",
                                  new SqlParameter("@RequestID", RequestID));
            dt = objUtility.GenericReplace(dsInboxMessageDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }

        }
        return dt;

    }

    public List<Cartlist> SeprateProduct(List<Cartlist> Cart)
    {
        Cartlist objCart = null;
        List<Cartlist> listCart = new List<Cartlist>();
        for (int i = 0; i < Cart.Count(); i++)
        {
            if (Cart[i].moduleid == 1 || Cart[i].moduleid == 2)//-- only case in product and vouchers
            {
                int Qty = Cart[i].quantity;
                for (int x = 0; x < Qty; x++)
                {
                    objCart = new Cartlist();
                    objCart.productID = Cart[i].productID;
                    objCart.quantity = 1;// Cart[i].quantity;
                    objCart.voucherID = Cart[i].voucherID;
                    objCart.point = Cart[i].point;
                    objCart.totalpoint = Cart[i].totalpoint;
                    objCart.moduleid = Cart[i].moduleid;
                    objCart.bordingplaceid = Cart[i].bordingplaceid;
                    objCart.TrasactionID = Cart[i].TrasactionID;
                    objCart.noofpax = Cart[i].noofpax;
                    objCart.pointremaining = Cart[i].pointremaining;
                    listCart.Add(objCart);
                }
            }

            if (Cart[i].moduleid == 3)//-- only case in holiday
            {

                objCart = new Cartlist();
                objCart.productID = Cart[i].productID;
                objCart.quantity = Cart[i].quantity;
                objCart.voucherID = Cart[i].voucherID;
                objCart.point = Cart[i].point;
                objCart.totalpoint = Cart[i].totalpoint;
                objCart.moduleid = Cart[i].moduleid;
                objCart.bordingplaceid = Cart[i].bordingplaceid;
                objCart.TrasactionID = Cart[i].TrasactionID;
                objCart.noofpax = Cart[i].noofpax;
                objCart.pointremaining = Cart[i].pointremaining;
                listCart.Add(objCart);

            }

        }

        return listCart;

    }



    public string convertxmltolist(List<Cartlist> list, int ModuleID)
    {

        string xmlcatlist = string.Empty;
        if (list != null && list.Count > 0)
        {
            List<Cartlist> lis = list.Where(x => x.moduleid == ModuleID).ToList();
            if (lis != null && lis.Count > 0)
            {
                var serializer = new XmlSerializer(typeof(List<Cartlist>),
                       new XmlRootAttribute("Cartlist"));
                using (var stream = new StringWriter())
                {
                    serializer.Serialize(stream, list.Where(x => x.moduleid == ModuleID).ToList());
                    xmlcatlist = stream.ToString();
                }
            }
        }
        return xmlcatlist;
    }

    public string convertxmltolist(List<Cartlist> list)
    {

        string xmlcatlist = string.Empty;
        if (list != null && list.Count > 0)
        {
            List<Cartlist> lis = list;
            if (lis != null && lis.Count > 0)
            {
                var serializer = new XmlSerializer(typeof(List<Cartlist>),
                       new XmlRootAttribute("Cartlist"));
                using (var stream = new StringWriter())
                {
                    serializer.Serialize(stream, list);
                    xmlcatlist = stream.ToString();
                }
            }
        }
        return xmlcatlist;
    }


    /// <summary>
    /// Get My Reward 
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<GetMyRewardResponseDTO> GetMyReward(string DealerCode)
    {
        GetMyRewardResponseDTO myReward = null;
        List<GetMyRewardResponseDTO> myRewardList = new List<GetMyRewardResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardGet",
                                                                                                new SqlParameter("@DealerCode", DealerCode));

            //   pm.productid,pm.productThumImg,pm.Producttitle,od.TotalPoint,od.ModuleID,m.Module
            while (dr.Read())
            {
                myReward = new GetMyRewardResponseDTO();
                if (dr["productid"] != null)
                    myReward.productid = Convert.ToInt32(dr["productid"].ToString());

                if (dr["Producttitle"] != null)
                    myReward.Producttitle = dr["Producttitle"].ToString();
                if (dr["productThumImg"] != null)
                    myReward.productthumimg = objUtility.GetFilePath(vImagePath + dr["productThumImg"].ToString());
                if (dr["TotalPoint"] != null)
                    myReward.totalpoint = Convert.ToDouble(dr["TotalPoint"].ToString());
                if (dr["ModuleID"] != null)
                    myReward.moduleid = Convert.ToInt32(dr["ModuleID"].ToString());
                if (dr["Module"] != null)
                    myReward.module = dr["Module"].ToString();
                if (dr["orderdate"] != null)
                    myReward.orderdate = String.Format("{0:d-MMM-yyyy}", Convert.ToDateTime(dr["orderdate"].ToString()));
                if (dr["TransactionID"] != null)
                    myReward.transactionid = dr["TransactionID"].ToString();

                if (dr["Description"] != null)
                    myReward.description = dr["Description"].ToString();
                if (dr["noofpax"] != null)
                    myReward.noofpax = dr["noofpax"].ToString();

                if (dr["additionalpoints"] != null)
                    myReward.additionalpoints = dr["additionalpoints"].ToString();

                if (dr["qty"] != null)
                    myReward.qty = dr["qty"].ToString();
                if (dr["pin"] != null)
                    myReward.pin = dr["pin"].ToString();

                //if (dr["expirydate"] != null)
                //   myReward.expirydate = dr["expirydate"].ToString();

                if (dr["expirydate"] is DBNull)
                {
                    if (!string.IsNullOrEmpty(dr["expirydate"].ToString()))
                        myReward.expirydate = String.Format("{0:d-MMM-yyyy}", Convert.ToDateTime(dr["expirydate"].ToString()));
                }


                if (dr["moduletype"] != null)
                    myReward.moduletype = dr["moduletype"].ToString();



                if (dr["VoucherNo"] != null)
                    myReward.voucherno = dr["VoucherNo"].ToString();
                if (dr["DateofGeneration"] is DBNull)
                    if (!string.IsNullOrEmpty(dr["DateofGeneration"].ToString()))
                        myReward.dateofgeneration = String.Format("{0:d-MMM-yyyy}", Convert.ToDateTime(dr["DateofGeneration"].ToString()));

                if (dr["DateofRedemption"] is DBNull)
                {
                    if (!string.IsNullOrEmpty(dr["DateofRedemption"].ToString()))
                        myReward.dateofredemption = String.Format("{0:d-MMM-yyyy}", Convert.ToDateTime(dr["DateofRedemption"].ToString()));
                }
                if (dr["StatusofDelivery"] != null)
                {
                    // if (!string.IsNullOrEmpty(dr["StatusofDelivery"].ToString()))
                    myReward.statusofdelivery = dr["StatusofDelivery"].ToString(); //String.Format("{0:d-MMM-yyyy}", Convert.ToDateTime(dr["StatusofDelivery"].ToString()));
                }
                if (dr["RequestID"] != null)
                    myReward.requestid = dr["RequestID"].ToString();
                myRewardList.Add(myReward);

            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return myRewardList;
    }

    /// <summary>
    /// Get My Reward partner details
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<GetMyRewardPartnerDetailsResponseDTO> GetMyRewardPartnerDetails(string DealerCode)
    {
        GetMyRewardPartnerDetailsResponseDTO myReward = null;
        List<GetMyRewardPartnerDetailsResponseDTO> myRewardList = new List<GetMyRewardPartnerDetailsResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardGetPartnerDetails",
                                                                                                new SqlParameter("@DealerCode", DealerCode));

            //   pm.productid,pm.productThumImg,pm.Producttitle,od.TotalPoint,od.ModuleID,m.Module
            while (dr.Read())
            {
                myReward = new GetMyRewardPartnerDetailsResponseDTO();
                if (dr["PartnerCode"] != null)
                    myReward.PartnerCode = dr["PartnerCode"].ToString();

                if (dr["PartnerName"] != null)
                    myReward.PartnerName = dr["PartnerName"].ToString();

                if (dr["PartnerMobile"] != null)
                    myReward.PartnerMobile = dr["PartnerMobile"].ToString();
                if (dr["PartnerEmail"] != null)
                    myReward.PartnerEmail = dr["PartnerEmail"].ToString();
                if (dr["OfficeAdd"] != null)
                    myReward.officeadd = dr["OfficeAdd"].ToString();

                myRewardList.Add(myReward);

            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return myRewardList;
    }

    /// <summary>
    /// Save detials gift point
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<GetMyRewardGiftPointResponseDTO> SaveMyRewardGiftPoint(string DealerCodeFrom, string DealerCodeTo, string GiftPoint)
    {
        GetMyRewardGiftPointResponseDTO myReward = null;
        List<GetMyRewardGiftPointResponseDTO> myRewardList = new List<GetMyRewardGiftPointResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "[dbo].[spGetMyRewardSaveGiftPoint]",
                                                                                                new SqlParameter("@DealerCodeFrom", DealerCodeFrom),
                                                                                                  new SqlParameter("@DealerCodeTo", DealerCodeTo),
                                                                                                    new SqlParameter("@GiftPoint", GiftPoint));

            //   pm.productid,pm.productThumImg,pm.Producttitle,od.TotalPoint,od.ModuleID,m.Module
            while (dr.Read())
            {
                myReward = new GetMyRewardGiftPointResponseDTO();
                if (dr["statuscode"] != null)
                    myReward.statuscode = dr["statuscode"].ToString();

                if (dr["status"] != null)
                    myReward.status = dr["status"].ToString();


                myRewardList.Add(myReward);

            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return myRewardList;
    }

    /// <summary>
    /// Get My Reward Faq
    /// </summary>
    /// <returns></returns>
    public List<GetMyRewardFaqResponseDTO> GetMyRewardFaq()
    {
        GetMyRewardFaqResponseDTO myReward = null;
        List<GetMyRewardFaqResponseDTO> myRewardList = new List<GetMyRewardFaqResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardFaq");

            //   pm.productid,pm.productThumImg,pm.Producttitle,od.TotalPoint,od.ModuleID,m.Module
            while (dr.Read())
            {
                myReward = new GetMyRewardFaqResponseDTO();
                if (dr["FaqQuestion"] != null)
                    myReward.faqquestion = dr["FaqQuestion"].ToString();

                if (dr["FaqAnswer"] != null)
                    myReward.faqanswer = dr["FaqAnswer"].ToString();


                myRewardList.Add(myReward);

            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return myRewardList;
    }

    /// <summary>
    /// Get My Reward Faq
    /// </summary>
    /// <returns></returns>
    public List<MyRewardSaveSarveyResponseDTO> GetMyRewardSaveSarvey(string DealerCode, int QuestionID, string Answer)
    {
        MyRewardSaveSarveyResponseDTO myReward = null;
        List<MyRewardSaveSarveyResponseDTO> MyRewardSaveSarveyResponseList = new List<MyRewardSaveSarveyResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();


        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "dbo.spMyRewardSaveAnswer",
                                                                                                new SqlParameter("@DealerCode", DealerCode),
                                                                                                new SqlParameter("@QuestionID", QuestionID),
                                                                                                 new SqlParameter("@Answer", Convert.ToByte(Answer)));
            while (dr.Read())
            {
                myReward = new MyRewardSaveSarveyResponseDTO();
                if (dr["Status"] != null)
                    myReward.status = dr["Status"].ToString();

                MyRewardSaveSarveyResponseList.Add(myReward);
            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return MyRewardSaveSarveyResponseList;
    }

    /// <summary>
    /// Function to Get Queation
    /// </summary>
    /// <param name="DealerCode">DealerCode</param>
    /// <returns></returns>
    public DataTable GetMyRewardSurvey(string DealerCode)
    {
        DataLayer dtLayer = null;
        try
        {
            dtLayer = new DataLayer();
            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardGetQueation",
                                                                                                new SqlParameter("@DealerCode", DealerCode),
                                                                                                new SqlParameter("@StartDate", DateTime.Now.ToString())).Tables[0];
        }
        catch (Exception ex)
        {
            //Custom Error Handling 
            DataTable errTab = new DataTable();

            DataColumn errCol = new DataColumn("ErrCol");
            errCol.DataType = System.Type.GetType("System.string");
            errTab.Columns.Add(errCol);

            DataRow rw = errTab.NewRow();
            rw["Error"] = ex.Message.ToString();


            errTab.Dispose();
            return errTab;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }
    /// <summary>
    /// Get My Reward history
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<GetMyRewardHistoryResponseDTO> GetMyRewardHistory(string DealerCode)
    {
        GetMyRewardHistoryResponseDTO myReward = null;
        List<GetMyRewardHistoryResponseDTO> myRewardList = new List<GetMyRewardHistoryResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.MyReward.Replace("\\", "/") + "/";

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMyRewardHistory",
                                                                                                new SqlParameter("@DealerCode", DealerCode));

            //   pm.productid,pm.productThumImg,pm.Producttitle,od.TotalPoint,od.ModuleID,m.Module
            while (dr.Read())
            {
                myReward = new GetMyRewardHistoryResponseDTO();

                if (dr["Producttitle"] != null)
                    myReward.producttitle = dr["Producttitle"].ToString();
                if (dr["Amount"] != null)
                    myReward.amount = Convert.ToDouble(dr["Amount"].ToString());
                if (dr["orderdate"] != null)
                    myReward.orderdate = String.Format("{0:d-MMM-yyyy}", Convert.ToDateTime(dr["orderdate"].ToString()));
                if (dr["type"] != null)
                    myReward.type = dr["type"].ToString();

                if (dr["moduletype"] != null)
                    myReward.moduletype = dr["moduletype"].ToString();
                if (dr["TrasactionID"] != null)
                    myReward.transactionid = dr["TrasactionID"].ToString();
                if (dr["RequestID"] != null)
                    myReward.requestid = dr["RequestID"].ToString();


                myRewardList.Add(myReward);

            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return myRewardList;
    }


    /// <summary>
    /// SaveRewardProductCart
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<MyRewardHolidayPaxResponseDTO> CheckHolidayPax(int productid, int noofpax, int bordingplaceid)
    {
        MyRewardHolidayPaxResponseDTO oMyRewardHolidayPaxResponseDTO = new MyRewardHolidayPaxResponseDTO();
        List<MyRewardHolidayPaxResponseDTO> list = new List<MyRewardHolidayPaxResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        object orderid = null;
        string retval = string.Empty;
        try
        {
            dtLayer = new DataLayer();
            orderid = SqlHelper.ExecuteScalar(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardCheckHolidayPax",
                new SqlParameter("@productid", productid),
                new SqlParameter("@noofpax", noofpax),
                new SqlParameter("@bordingplaceid", bordingplaceid));
            if (orderid != null)
            {
                retval = orderid.ToString();
                oMyRewardHolidayPaxResponseDTO.point = retval.ToString();
                list.Add(oMyRewardHolidayPaxResponseDTO);
            }


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return list;
    }



    #region Digital signature

    public string SaveDigitalSig_Images(Stream stream, string newfilename, DigitalSignatureModel oDigitalSignatureModel)
    {
        //*********VARIABLE INITIALIZE*********
        SPPUtility oSPPUtility = new SPPUtility();
        string imageExtension = string.Empty;

        byte[] imageByteArray = new byte[0];

        string result = string.Empty;

        string actualFileName = newfilename;

        string uploadDirectoryPath = ConfigurationManager.AppSettings["DSimgUrl"];
        SPPUtility objSPPUtility = new SPPUtility();
        const int numerofretries = 4;
        const int Delayonreties = 1000;
        try
        {
            Image image = null;
            decimal filesize = 0;

            char[] strBlackListChars = { ':', ';', '<', '>', '%', '\'', '$' };
            bool hasInvalidChar = false;
            //*********END*********


            if (actualFileName.IndexOfAny(strBlackListChars) >= 0)
                hasInvalidChar = true;

            //try
            //{
            imageExtension = actualFileName.Substring(actualFileName.Length - 3);
            imageByteArray = objSPPUtility.StreamToByteArray(stream);
            using (image = objSPPUtility.byteArrayToImage(imageByteArray))
            {
                filesize = decimal.Round(Convert.ToDecimal(stream.Position) / (1024 * 1024), 2, MidpointRounding.AwayFromZero);
                if (image != null && imageExtension.Equals("jpg", StringComparison.OrdinalIgnoreCase) && filesize <= 5 && (hasInvalidChar == false))
                {
                    for (int i = 1; i <= numerofretries; ++i)
                    {
                        try
                        {
                            result = objSPPUtility.UploadFileOnServer(actualFileName, imageByteArray, uploadDirectoryPath);

                            if (result.Contains("complete"))
                            {

                                int ret = SaveDigitalsignature(oDigitalSignatureModel);

                                result = ret.ToString();
                                stream.Close();
                                break;
                            }
                        }

                        catch (IOException ex)
                        {
                            if (i <= numerofretries)
                            {
                                Thread.Sleep(Delayonreties);
                                oSPPUtility.InsertintoErrorLog("Function - SaveDigitalSig_Images-ReTry", ex.Message, "FileName: " + newfilename,
                                                      Convert.ToInt32(SPPUtility._Sections.DigitalSignature), 0);

                            }
                        }
                    }
                }
            }

            //}
            //catch (Exception ex)
            //{
            //    string tsr = ex.Message;
            //    //stuff will come here
            //}

            //  if (image != null && ImageFormat.Jpeg.Equals(image.RawFormat) && imageExtension.Equals("jpg", StringComparison.OrdinalIgnoreCase) && filesize <= 5 && (hasInvalidChar == false))




        }
        catch (Exception ex)
        {
            oSPPUtility.InsertintoErrorLog("Function - SaveDigitalSig_Images", ex.Message, "FileName: " + newfilename,
                                  Convert.ToInt32(SPPUtility._Sections.DigitalSignature), 0);

        }
        return result;
    }
    /// <summary>
    /// Added by shaif on 19 sep 2016 to save PSUScheme
    /// </summary>
    /// <param name="oPSUSchemeModal"></param>

    public int SaveDigitalsignature(DigitalSignatureModel oDigitalSignatureModel)
    {

        DataLayer dtLayer = new DataLayer();
        object ds = null;

        int retval = 0;
        try
        {

            ds = SqlHelper.ExecuteScalar(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSaveDigitalsignature",
                                    new SqlParameter("@DigitalsignatureTemplateid", oDigitalSignatureModel.DigitalsignatureTemplateid),
                                    new SqlParameter("@Name", oDigitalSignatureModel.Name),
                                    new SqlParameter("@Digitalsignatureimg", oDigitalSignatureModel.Digitalsignatureimg),
                                    new SqlParameter("@Digitalsignaturepdf", oDigitalSignatureModel.Digitalsignaturepdf),
                                    new SqlParameter("@Termandconditionrowhtml", oDigitalSignatureModel.Termandconditionrowhtml),
                                    new SqlParameter("@Dealercode", oDigitalSignatureModel.Dealercode),
                                    new SqlParameter("@Mobile", oDigitalSignatureModel.Mobile),
                                     new SqlParameter("@CustomerEmail", oDigitalSignatureModel.CustomerEmail)


                                   );
        }
        catch (Exception exc)
        {
            //objexception.AddExceptionLog(sProjectName, sModuleName, "", sPageName, "SaveAuthorization", sAuthorName, sAuthorName, exc.Message, "S2P2 WCF Android Exception");
        }
        finally
        {
            if (dtLayer != null)
            {
                dtLayer = null;
            }

        }
        if (ds != null)
        {
            retval = Convert.ToInt32(ds);
        }
        return retval;
    }

    /// <summary>
    /// Function Created by Amit Kr Singh on 19-Oct-2016 to get Term & Condition
    /// </summary>
    /// <returns></returns>
    public DataTable SPPGetTermCondition()
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        DataSet dsTNC = null;
        DataTable dtTNC = null;
        try
        {
            dsTNC = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), System.Data.CommandType.StoredProcedure, "spDSGetTermCondition");
            dtTNC = objUtility.GenericReplace(dsTNC.Tables[0]);
        }
        catch (Exception ex)
        {

            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtTNC;
    }


    public void dsPDFandEmail(string newfilename, string Name, string pdffilename, string sDealerEmail, string sCustomerEmail)
    {
        SPPUtility oSPPUtility = new SPPUtility();
        DataTable dstandc = SPPGetTermCondition();
        string dsurl = System.Configuration.ConfigurationManager.AppSettings["DSURL"].ToString() + newfilename;
        // string DSUploadURL = System.Configuration.ConfigurationManager.AppSettings["DSUploadURL"].ToString();
        //Email Setting----------------
        string IsDSLocalEmail = System.Configuration.ConfigurationManager.AppSettings["IsDSLocalEmail"].ToString();
        string DSLocalEmail = System.Configuration.ConfigurationManager.AppSettings["DSLocalEmail"].ToString();
        string DSLocalEmailSubject = System.Configuration.ConfigurationManager.AppSettings["DSLocalEmailSubject"].ToString();
        string DSLocalEmailBody = "<html><body>Dear  " + Name + "</br></br>";

        DSLocalEmailBody = DSLocalEmailBody + "Thank you for accepting the terms & condition for the 4D VR Experience . We sincerely hope that you had an enjoyable experience & hope to see you soon again </br></br>";

        DSLocalEmailBody = DSLocalEmailBody + "Cheers ! </br></br>";

        DSLocalEmailBody = DSLocalEmailBody + "Samsung Experience Store </br></br>";

        DSLocalEmailBody = DSLocalEmailBody + "Star Mobitel </br></br>";

        DSLocalEmailBody = DSLocalEmailBody + "E-32 , South Ex Part 2 , New Delhi </br></br>";

        DSLocalEmailBody = DSLocalEmailBody + "contact : 011 - 46828282 </br></br>";
        DSLocalEmailBody = DSLocalEmailBody + "</body></html>";
        //System.Configuration.ConfigurationManager.AppSettings["DSLocalEmailBody"].ToString();
        //-------------------------------------------


        //  string RootPath = AppDomain.CurrentDomain.BaseDirectory;
        //  string AttachmentPath = String.Format("{0}{1}{2}", RootPath, DSUploadURL, newfilename);
        string DSimgUrl = System.Configuration.ConfigurationManager.AppSettings["DSpdfimgUrl"].ToString();
        string imgpath = String.Format("{0}{1}", DSimgUrl, newfilename);
        string imgsig = "<img height='170' width='384' src='" + imgpath + "'>";
        //string imgsig = "<img height='170' width='384' src='" + dsurl + "'>";
        string termandcondition = dstandc.Rows[0]["Termandcondition"].ToString().Replace("{sig}", imgsig).Replace("{name}", Name);
        string htmlterm = termandcondition;
        string filepath = convertToPDFByHTML(htmlterm, pdffilename, "");
        if (IsDSLocalEmail == "1")
        // oSPPUtility.SendFinalMail("md.shaif@partner.samsung.com", "digital sign", "PFA!!!!", uploadUrl);
        {
            oSPPUtility.SendFinalMail(DSLocalEmail, DSLocalEmailSubject, DSLocalEmailBody, filepath, "");
        }
        else
        {
            if (!string.IsNullOrEmpty(sDealerEmail))
                oSPPUtility.SendFinalMail(sDealerEmail, DSLocalEmailSubject, DSLocalEmailBody, filepath, "");
            if (!string.IsNullOrEmpty(sCustomerEmail))
                oSPPUtility.SendFinalMail(sCustomerEmail, DSLocalEmailSubject, DSLocalEmailBody, filepath, "");
        }

    }

    public void sendPDFandEmail(string newfilename, string Name, string pdffilename, string sDealerEmail, string sCustomerEmail, string delarname, string Mobile, string DealerCode)
    {

        SPPUtility oSPPUtility = new SPPUtility();
        DataTable dstandc = SPPGetTermCondition();

        // Get Dealer Code-----------------------------------

        DataTable dtStore = GetDealerStore(DealerCode);


        try
        {
            //---------------------------------------------------


            string dsurl = System.Configuration.ConfigurationManager.AppSettings["DSURL"].ToString() + newfilename;
            // string DSUploadURL = System.Configuration.ConfigurationManager.AppSettings["DSUploadURL"].ToString();
            //Email Setting----------------
            string IsDSLocalEmail = System.Configuration.ConfigurationManager.AppSettings["IsDSLocalEmail"].ToString();
            string DSLocalEmail = System.Configuration.ConfigurationManager.AppSettings["DSLocalEmail"].ToString();
            string DSLocalEmailSubject = System.Configuration.ConfigurationManager.AppSettings["DSLocalEmailSubject"].ToString();
            string DSLocalEmailBody = "<html><body>Dear  " + Name + "</br></br>";

            DSLocalEmailBody = DSLocalEmailBody + "Thank you for accepting the terms & condition for the 4D VR Experience . We sincerely hope that you had an enjoyable experience & hope to see you soon again </br></br>";

            DSLocalEmailBody = DSLocalEmailBody + "Cheers ! </br></br>";

            DSLocalEmailBody = DSLocalEmailBody + "Samsung Experience Store </br></br>";
            if (dtStore != null && dtStore.Rows.Count > 0)
            {
                DSLocalEmailBody = DSLocalEmailBody + dtStore.Rows[0]["DealerFirm"].ToString() + " </br></br>";

                DSLocalEmailBody = DSLocalEmailBody + dtStore.Rows[0]["StoreAddress"].ToString() + " </br></br>";

                DSLocalEmailBody = DSLocalEmailBody + "contact : " + dtStore.Rows[0]["Landline"].ToString() + " </br></br>";

            }

            //DSLocalEmailBody = DSLocalEmailBody + "Star Mobitel </br></br>";

            //DSLocalEmailBody = DSLocalEmailBody + "E-32 , South Ex Part 2 , New Delhi </br></br>";

            //DSLocalEmailBody = DSLocalEmailBody + "contact : 011 - 46828282 </br></br>";
            DSLocalEmailBody = DSLocalEmailBody + "</body></html>";
            //System.Configuration.ConfigurationManager.AppSettings["DSLocalEmailBody"].ToString();
            //-------------------------------------------



            ////  string RootPath = AppDomain.CurrentDomain.BaseDirectory;
            ////  string AttachmentPath = String.Format("{0}{1}{2}", RootPath, DSUploadURL, newfilename);
            //string DSimgUrl = System.Configuration.ConfigurationManager.AppSettings["DSpdfimgUrl"].ToString();
            //string imgpath = String.Format("{0}{1}", DSimgUrl, newfilename);
            //string imgsig = "<img height='170' width='384' src='" + imgpath + "'>";
            ////string imgsig = "<img height='170' width='384' src='" + dsurl + "'>";
            //string termandcondition = dstandc.Rows[0]["Termandcondition"].ToString().Replace("{sig}", imgsig).Replace("{name}", Name);
            //string htmlterm = termandcondition;
            string filepath = convertToPDF(pdffilename, newfilename, delarname, Mobile, Name);
            if (IsDSLocalEmail == "1")
            // oSPPUtility.SendFinalMail("md.shaif@partner.samsung.com", "digital sign", "PFA!!!!", uploadUrl);
            {
                if (dtStore != null && dtStore.Rows.Count > 0)
                {
                    oSPPUtility.SendFinalMail(DSLocalEmail, dtStore.Rows[0]["StoreEmail"].ToString(), dtStore.Rows[0]["DealerFirm"].ToString(), DSLocalEmailSubject, DSLocalEmailBody, filepath, "");
                }
                else
                {
                    oSPPUtility.SendFinalMail(DSLocalEmail, DSLocalEmailSubject, DSLocalEmailBody, filepath, "");
                }

            }
            else
            {
                if (dtStore != null && dtStore.Rows.Count > 0)
                {
                    if (!string.IsNullOrEmpty(sDealerEmail))
                        oSPPUtility.SendFinalMail(sDealerEmail, dtStore.Rows[0]["StoreEmail"].ToString(), dtStore.Rows[0]["DealerFirm"].ToString(), DSLocalEmailSubject, DSLocalEmailBody, filepath, "");
                    if (!string.IsNullOrEmpty(sCustomerEmail))
                        oSPPUtility.SendFinalMail(sCustomerEmail, dtStore.Rows[0]["StoreEmail"].ToString(), dtStore.Rows[0]["DealerFirm"].ToString(), DSLocalEmailSubject, DSLocalEmailBody, filepath, "");

                }
                else
                {

                    if (!string.IsNullOrEmpty(sDealerEmail))
                        oSPPUtility.SendFinalMail(sDealerEmail, DSLocalEmailSubject, DSLocalEmailBody, filepath, "");
                    if (!string.IsNullOrEmpty(sCustomerEmail))
                        oSPPUtility.SendFinalMail(sCustomerEmail, DSLocalEmailSubject, DSLocalEmailBody, filepath, "");
                }
            }
        }
        catch (Exception ex)
        {
            oSPPUtility.InsertintoErrorLog("Function - sendPDFandEmail", ex.Message, "FileName: " + newfilename + "pdffilename : " + pdffilename,
                                     Convert.ToInt32(SPPUtility._Sections.DigitalSignature), 0);

        }
    }

    public void SendSMSandEmail_MyReward(string Name, string mobile, string email, string dealercode, List<string> listRequestID)
    {


        SPPBusinessLayer sppobjBal = new SPPBusinessLayer();
        for (int y = 0; y < listRequestID.Count; y++)
        {

            DataTable dtOrderDetails = sppobjBal.GetOrderProductbyRequestID(listRequestID[y]);
            SendSMSandEmail(Name, mobile, email, dealercode, listRequestID[y], dtOrderDetails);

        }

    }

    public void SendSMSandEmail(string Name, string mobile, string email, string dealercode, string RequestID, DataTable dtcart)
    {

        SPPUtility oSPPUtility = new SPPUtility();
        DataTable dstandc = SPPGetTermCondition();
        //Email Setting----------------
        string IsDSLocalEmail = System.Configuration.ConfigurationManager.AppSettings["IsDSLocalEmail"].ToString();
        string DSLocalEmail = System.Configuration.ConfigurationManager.AppSettings["DSLocalEmail"].ToString();
        string DSLocalEmailSubject = System.Configuration.ConfigurationManager.AppSettings["DSLocalEmailSubject"].ToString();
        // string DSLocalEmailBody = System.Configuration.ConfigurationManager.AppSettings["DSLocalEmailBody"].ToString();
        string mailSubject = string.Empty;

        StringBuilder sb = new StringBuilder();
        sb.Append("<table cellspacing='0' cellpadding='0' width='800' align='center' border='0'>");
        sb.Append("<tbody>");
        sb.Append("<tr>");
        sb.Append("<td>&nbsp;</td></tr>");
        //sb.Append("<tr>");
        //sb.Append("<td><img alt='' src='https://shop.samsung.com/in/skin/frontend/ultimo/default/images/logo_email.jpg'> </td></tr>");
        sb.Append("<tr>");
        sb.Append("<td>&nbsp;</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td height='13'></td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; FONT: 12px/16px Arial, Helvetica, sans-serif; PADDING-LEFT: 10px; PADDING-RIGHT: 10px'>Dear Customer,</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td height='13'></td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; FONT: 12px/16px Arial, Helvetica, sans-serif; PADDING-LEFT: 10px; PADDING-RIGHT: 10px'>Thank you for placing your order with SPP MyReward.</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td height='13'></td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; FONT: 12px/16px Arial, Helvetica, sans-serif; PADDING-LEFT: 10px; PADDING-RIGHT: 10px'>Your Request ID is: <strong>" + RequestID + "</strong>. We have now started processing your order. The details of your order are as follows:</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td>&nbsp;</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; FONT: 12px/16px Arial, Helvetica, sans-serif; PADDING-LEFT: 10px; PADDING-RIGHT: 10px'>");
        sb.Append("<table cellspacing='0' cellpadding='0' width='100%' border='0'>");
        sb.Append("<thead style='BACKGROUND-COLOR: #f0f0f0'>");
        sb.Append("<tr>");

        sb.Append("<th>&nbsp;</th>");
        if (RequestID.Contains("V"))
        {
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Transaction Id</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Voucher Brand Name</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Item</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Type</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Point Value</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='center'>Qty</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='right'>Total Point Value</th></tr></thead>");
        }
        if (RequestID.Contains("P"))
        {
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Transaction Id</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Item/ Brand</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Type</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Category</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Point Value</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='center'>Qty</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='right'>Total Point Value</th></tr></thead>");
        }
        if (RequestID.Contains("H"))
        {
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Transaction Id</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Item</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Type</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='left'>Point Value</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='center'>No of Pax</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='right'>Total Point Value</th>");
            sb.Append("<th style='FONT-SIZE: 13px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' align='right'>Additional Due Points</th></tr></thead>");
        }
        sb.Append("<tbody>");


        for (int i = 0; i < dtcart.Rows.Count; i++)
        {
            sb.Append("<tr>");
            sb.Append("<td>&nbsp;</td>");

            if (RequestID.Contains("V"))
            {
                int totalpoint = System.Convert.ToInt32(dtcart.Rows[i]["Point"].ToString()) * System.Convert.ToInt32(dtcart.Rows[i]["Qty"].ToString());
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'><strong style='FONT-SIZE: 11px'>" + dtcart.Rows[i]["trasid"].ToString() + "</strong></td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'><strong style='FONT-SIZE: 11px'>" + dtcart.Rows[i]["BrandName"].ToString() + "</strong></td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'><strong style='FONT-SIZE: 11px'>" + dtcart.Rows[i]["Producttitle"].ToString() + "</strong></td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'>" + dtcart.Rows[i]["Type"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='center'>" + dtcart.Rows[i]["Point"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='center'>" + dtcart.Rows[i]["Qty"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='right'><span class='price'>" + totalpoint.ToString() + "</span> </td>");
            }
            if (RequestID.Contains("P"))
            {
                int totalpoint = System.Convert.ToInt32(dtcart.Rows[i]["Point"].ToString()) * System.Convert.ToInt32(dtcart.Rows[i]["Qty"].ToString());
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'><strong style='FONT-SIZE: 11px'>" + dtcart.Rows[i]["trasid"].ToString() + "</strong></td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'><strong style='FONT-SIZE: 11px'>" + dtcart.Rows[i]["Producttitle"].ToString() + "</strong></td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'>" + dtcart.Rows[i]["Type"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'>" + dtcart.Rows[i]["CategoryName"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='center'>" + dtcart.Rows[i]["Point"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='center'>" + dtcart.Rows[i]["Qty"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='right'><span class='price'>" + totalpoint.ToString() + "</span> </td>");
            }
            if (RequestID.Contains("H"))
            {
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'><strong style='FONT-SIZE: 11px'>" + dtcart.Rows[i]["trasid"].ToString() + "</strong></td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'><strong style='FONT-SIZE: 11px'>" + dtcart.Rows[i]["Producttitle"].ToString() + "</strong></td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='left'>" + dtcart.Rows[i]["Type"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='center'>" + dtcart.Rows[i]["Point"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='center'>" + dtcart.Rows[i]["noofpax"].ToString() + "</td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='right'><span class='price'>" + dtcart.Rows[i]["totalpoint"].ToString() + "</span> </td>");
                sb.Append("<td style='FONT-SIZE: 11px; FONT-FAMILY: arial; PADDING-BOTTOM: 3px; PADDING-TOP: 3px; PADDING-LEFT: 9px; PADDING-RIGHT: 9px' valign='top' align='right'><span class='price'>" + dtcart.Rows[i]["RemainingPoint"].ToString() + "</span> </td>");
            }
            sb.Append("</tr>");

        }

        sb.Append("</tbody>");

        sb.Append("</table>");

        sb.Append("</td>");

        sb.Append("</tr>");

        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; FONT: 12px/16px Arial, Helvetica, sans-serif'>&nbsp;</td></tr>");
        //sb.Append("<tr>");
        //sb.Append("<td style='COLOR: #454545; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; FONT: 12px/16px Arial, Helvetica, sans-serif; PADDING-LEFT: 10px; PADDING-RIGHT: 10px'>In case of any query, please call our Customer Care 8:00 AM to 8:00 PM at 1800-419-1918 (Toll Free) . You can also email us at <a style='TEXT-DECORATION: none; COLOR: #00a8e1' href='mailto:support.estore@samsung.com' target='_blank'>support.estore@samsung.com</a>. </td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; FONT: 12px/16px Arial, Helvetica, sans-serif'>&nbsp;</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; FONT: 12px/16px Arial, Helvetica, sans-serif; PADDING-LEFT: 10px; PADDING-RIGHT: 10px'>Thank you for shopping with Samsung MyReward.</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; FONT: 12px/16px Arial, Helvetica, sans-serif'>&nbsp;</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; FONT: 12px/16px Arial, Helvetica, sans-serif; PADDING-LEFT: 10px; PADDING-RIGHT: 10px'>Warm Regards,<br><span style='COLOR: #000'>Samsung MyReward Team</span> </td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; FONT: 12px/16px Arial, Helvetica, sans-serif'>&nbsp;</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; FONT: 12px/16px Arial, Helvetica, sans-serif'>&nbsp;</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td style='COLOR: #454545; PADDING-BOTTOM: 0px; PADDING-TOP: 0px; FONT: 12px/16px Arial, Helvetica, sans-serif; PADDING-LEFT: 10px; PADDING-RIGHT: 10px'>This is an automatically generated email, please do not reply directly to it.</td></tr>");
        sb.Append("<tr>");
        sb.Append("<td>&nbsp;</td></tr></tbody></table>");
        string emailbody = sb.ToString();

        string IsLocalSMS = System.Configuration.ConfigurationManager.AppSettings["IsLocalSMS"].ToString();
        string LocalMobile = System.Configuration.ConfigurationManager.AppSettings["LocalMobile"].ToString();
        string smobile = IsLocalSMS == "1" ? LocalMobile : mobile;
        string typeName = string.Empty;
        if (RequestID.Contains("P"))
            typeName = "Product";
        if (RequestID.Contains("V"))
            typeName = "Voucher";
        if (RequestID.Contains("H"))
            typeName = "Holiday Package";

        string smstxt = "Dear Customer," + "\n";
        smstxt += "Thank you for placing your " + typeName + " order with SPP MyReward." + "\n";
        smstxt += "Your Request ID is: " + RequestID + ".\n We have now started processing your order";



        if (SPPUtility.SendSMS("", smobile, smstxt))
        {


            mailSubject = typeName + " Order with SPP MyReward  # " + RequestID;
            string BCCEmail = ConfigurationSettings.AppSettings["bccemailmyreward"].ToString();
            string fromemail = ConfigurationSettings.AppSettings["MyRewardMAIL_SENDER_EMAIL"].ToString();
            string MAIL_FROM_NAME = ConfigurationSettings.AppSettings["MyRewardMAIL_FROM_NAME"].ToString();

            if (IsDSLocalEmail == "1")
            {

                oSPPUtility.SendFinalMail(DSLocalEmail, fromemail, MAIL_FROM_NAME, mailSubject, emailbody, "", BCCEmail);

            }
            else
            {

                oSPPUtility.SendFinalMail(email, fromemail, MAIL_FROM_NAME, mailSubject, emailbody, "", BCCEmail);

            }
        }



    }

    #endregion

    public DataTable GetDealerStore(string sDealerCode)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {


            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetDealerStoreDigitalsignature",
                  new SqlParameter("@DealerCode", sDealerCode)
                  ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }



    public DataTable MyRewardSaveOTP(string suserID, string stoken)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {
            //SqlParameter outPutParameter = new SqlParameter();
            //outPutParameter.ParameterName = "@OutputStatus";
            //outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            //outPutParameter.Direction = System.Data.ParameterDirection.Output;
            //outPutParameter.Size = 4;

            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardSaveOTP",
                  new SqlParameter("@RefDistCode", suserID),
                  new SqlParameter("@SMSOTP", stoken)
                  ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }

    public void MyRewardSendOTP(string userid, string token, DataTable dt)
    {
        SPPUtility objUtility = new SPPUtility();
        string IsDSLocalEmail = System.Configuration.ConfigurationManager.AppSettings["IsDSLocalEmail"].ToString();
        string DSLocalEmail = System.Configuration.ConfigurationManager.AppSettings["DSLocalEmail"].ToString();

        string IsLocalSMS = System.Configuration.ConfigurationManager.AppSettings["IsLocalSMS"].ToString();
        string LocalMobile = System.Configuration.ConfigurationManager.AppSettings["LocalMobile"].ToString();

        string emailbody = "My Rewards Order Verification OTP : " + token;
        string fromemail = ConfigurationSettings.AppSettings["MyRewardMAIL_SENDER_EMAIL"].ToString();
        string MAIL_FROM_NAME = ConfigurationSettings.AppSettings["MyRewardMAIL_FROM_NAME"].ToString();
        if (IsDSLocalEmail == "1")
        {
            objUtility.SendFinalMail(DSLocalEmail, fromemail, MAIL_FROM_NAME, "My Rewards Order Verification Code", emailbody, "", "");
        }
        else
        {
            objUtility.SendFinalMail(dt.Rows[0]["EmailId"].ToString(), fromemail, MAIL_FROM_NAME, "My Rewards Order Verification Code", emailbody, "", "");
        }
        string mobile = IsLocalSMS == "1" ? LocalMobile : dt.Rows[0]["MobileNo"].ToString();
        token = ConfigurationSettings.AppSettings["messageforotp"] + " " + token;
        SPPUtility.SendSMS(userid, mobile, token);


    }

    public void MyRewardSendSMSGiftPoints(string userid, string smsmsg, string smobile)
    {
        SPPUtility objUtility = new SPPUtility();


        string IsLocalSMS = System.Configuration.ConfigurationManager.AppSettings["IsLocalSMS"].ToString();
        string LocalMobile = System.Configuration.ConfigurationManager.AppSettings["LocalMobile"].ToString();

        string mobile = IsLocalSMS == "1" ? LocalMobile : smobile;
        SPPUtility.SendSMS(userid, mobile, smsmsg);


    }

    public DataTable MyRewardGetOTP(string suserID, string stoken)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {
            //SqlParameter outPutParameter = new SqlParameter();
            //outPutParameter.ParameterName = "@OutputStatus";
            //outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            //outPutParameter.Direction = System.Data.ParameterDirection.Output;
            //outPutParameter.Size = 4;

            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardGetOTP",
                  new SqlParameter("@RefDistCode", suserID),
                  new SqlParameter("@SMSOTP", stoken)
                  ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }

    /// <summary>
    /// Get My Reward 
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public bool GetOrderManegementDealerStatus(string UserTypeID, string menuid, string dealercode)
    {

        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        bool retval = false;

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOrderMangementGetConfiguration",
                                                                                                new SqlParameter("@usertype", UserTypeID),
                                                                                                new SqlParameter("@menuid", menuid),
                                                                                                 new SqlParameter("@dealercode", dealercode));

            //   pm.productid,pm.productThumImg,pm.Producttitle,od.TotalPoint,od.ModuleID,m.Module
            while (dr.Read())
            {

                if (dr["isshow"] != null)
                    retval = Convert.ToBoolean(dr["isshow"]);



            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return retval;
    }

    /// <summary>
    /// Get My Reward 
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public bool GetMyRewardCheckRedemptionWindow(string UserTypeID)
    {

        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        bool retval = false;

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMyRewardCheckRedemptionWindow",
                                                                                                new SqlParameter("@CurrentDate", DateTime.Now),
                                                                                                new SqlParameter("@UserTypeID", UserTypeID));

            //   pm.productid,pm.productThumImg,pm.Producttitle,od.TotalPoint,od.ModuleID,m.Module
            while (dr.Read())
            {

                if (dr["CheckRedemptionWindow"] != null)
                    retval = Convert.ToBoolean(dr["CheckRedemptionWindow"]);



            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return retval;
    }


    /// <summary>
    /// Get My Reward 
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public bool CashifyPartnerCode(string PartnerCode, int flag)
    {

        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        bool retval = false;

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spCashifyPartnerCode",
                                                                                                new SqlParameter("@PartnerCode", PartnerCode), new SqlParameter("@Flag", flag));

            //   pm.productid,pm.productThumImg,pm.Producttitle,od.TotalPoint,od.ModuleID,m.Module
            while (dr.Read())
            {

                if (dr["status"] != null)
                    retval = Convert.ToBoolean(dr["status"]);



            }




        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return retval;
    }
    #endregion

    #region PdfDownload
    //public void lnkpdfdownload(Object sender, EventArgs e)
    //{

    //    Thread t = new Thread(convertToPDFByHTML);
    //    t.SetApartmentState(ApartmentState.STA);
    //    t.Start();
    //    t.Join();


    //}
    public string convertToPDFByHTML(string RowHTML, string filename, string digitalsigurl)
    {
        string retfilename = string.Empty;
        try
        {
            string supload = ConfigurationManager.AppSettings["pdfurl"];
            string htmlCode = "<p>This is a p tag</p>";
            PdfDocument pdf = new PdfDocument();

            Spire.Pdf.HtmlConverter.PdfHtmlLayoutFormat htmlLayoutFormat = new Spire.Pdf.HtmlConverter.PdfHtmlLayoutFormat();

            //webBrowser load html whether Waiting

            htmlLayoutFormat.IsWaiting = true;
            htmlLayoutFormat.LoadHtmlTimeout = 30000; //Default is 30000
            //page setting

            PdfPageSettings setting = new PdfPageSettings();

            setting.Size = PdfPageSize.A4;
            string RootPath = AppDomain.CurrentDomain.BaseDirectory;
            String fileurlhtml = RootPath + @"DigitalSignature\DShtml\";// System.Configuration.ConfigurationManager.AppSettings["DSHtml"].ToString();
            string sFileName = Guid.NewGuid().ToString().Substring(1, 10) + ".html"; //"pdf" + ".html";
            string url = fileurlhtml + sFileName;
            using (StreamWriter w = new StreamWriter(url, true))
            {

                w.WriteLine(RowHTML);    // Write the text
            }

            string pureFileName = filename + ".pdf";
            //use single thread to generate the pdf from above html code
            Thread thread = new Thread(() =>
            {
                pdf.LoadFromHTML(url, false, true, true);
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
            thread.Join();


            string uploadUrl = String.Format("{0}{1}{2}", RootPath, supload, pureFileName);
            // Save the file to PDF and preview it.
            pdf.SaveToFile(uploadUrl);
            // System.Diagnostics.Process.Start("output.pdf");
            retfilename = uploadUrl;
            System.IO.File.Delete(fileurlhtml + sFileName + ".html");
            pdf.Close();


            // File.Delete(Request.PhysicalApplicationPath + "/SchemeHtml/" + sFileName + ".html");
        }
        catch (Exception ex)
        {
            //  objException.AddExceptionLog(sProjectName, sModuleName, "", sPageName, "convertToPDFByHTML", sAuthorName, sCreatedBy, ex.Message.ToString(), "");
        }
        return retfilename;
    }

    public string convertToPDF(string filename, string imagefilename, string delarname, string Mobile, string Name)
    {
        // http://www.e-iceblue.com/Tutorials/Spire.PDF/Spire.PDF-Program-Guide/How-to-Create-a-PDF-Document-and-Insert-an-Image.html
        string retfilename = string.Empty;
        SPPUtility oSPPUtility = new SPPUtility();
        string uploadUrl = string.Empty;
        try
        {
            string supload = ConfigurationManager.AppSettings["pdfurl"];
            //string htmlCode = "<p>This is a p tag</p>";
            //PdfDocument pdf = new PdfDocument();

            //Spire.Pdf.HtmlConverter.PdfHtmlLayoutFormat htmlLayoutFormat = new Spire.Pdf.HtmlConverter.PdfHtmlLayoutFormat();

            ////webBrowser load html whether Waiting

            //htmlLayoutFormat.IsWaiting = true;
            //htmlLayoutFormat.LoadHtmlTimeout = 30000; //Default is 30000
            ////page setting

            //PdfPageSettings setting = new PdfPageSettings();

            //setting.Size = PdfPageSize.A4;
            //string RootPath = AppDomain.CurrentDomain.BaseDirectory;
            //String fileurlhtml = RootPath + @"DigitalSignature\DShtml\";// System.Configuration.ConfigurationManager.AppSettings["DSHtml"].ToString();
            //string sFileName = Guid.NewGuid().ToString().Substring(1, 10) + ".html"; //"pdf" + ".html";
            //string url = fileurlhtml + sFileName;
            //using (StreamWriter w = new StreamWriter(url, true))
            //{

            //    w.WriteLine(RowHTML);    // Write the text
            //}

            //string pureFileName = filename + ".pdf";
            ////use single thread to generate the pdf from above html code
            //Thread thread = new Thread(() =>
            //{ pdf.LoadFromHTML(url, false, true, true); });
            //thread.SetApartmentState(ApartmentState.STA);
            //thread.Start();
            //thread.Join();

            //string uploadUrl = String.Format("{0}{1}{2}", RootPath, supload, pureFileName);
            //// Save the file to PDF and preview it.
            //pdf.SaveToFile(uploadUrl);
            //// System.Diagnostics.Process.Start("output.pdf");
            //retfilename = uploadUrl;
            //System.IO.File.Delete(fileurlhtml + sFileName + ".html");
            //pdf.Close();


            // File.Delete(Request.PhysicalApplicationPath + "/SchemeHtml/" + sFileName + ".html");

            string RootPath = AppDomain.CurrentDomain.BaseDirectory;
            string DSimgUrl = System.Configuration.ConfigurationManager.AppSettings["DSpdfimgUrl"].ToString();
            string imagePath = String.Format("{0}{1}{2}", RootPath, DSimgUrl, imagefilename);

            string pureFileName = filename + ".pdf";
            uploadUrl = String.Format("{0}{1}{2}", RootPath, supload, pureFileName);


            PdfDocument doc = new PdfDocument();
            PdfPageBase page = doc.Pages.Add();
            // page.Canvas.DrawString("Hello, World!",new PdfFont(PdfFontFamily.Helvetica, 30f),new PdfSolidBrush(Color.Black),10, 10);

            PdfImage image = PdfImage.FromFile(imagePath);
            page = Writepdfcontain(page, delarname, Mobile, image, Name);
            //float width = 384;
            //float height = 170;
            //float x = (page.Canvas.ClientSize.Width - width) / 2;
            //page.Canvas.DrawImage(image, x, 60, width, height);

            // height='170' width='384'
            doc.SaveToFile(uploadUrl);
            retfilename = uploadUrl;
            doc.Close();


        }
        catch (Exception ex)
        {
            oSPPUtility.InsertintoErrorLog("Function - convertToPDF", ex.Message, " ImageFileName: " + imagefilename + " pdfpath : " + uploadUrl,
                                    Convert.ToInt32(SPPUtility._Sections.DigitalSignature), 0);
            //  objException.AddExceptionLog(sProjectName, sModuleName, "", sPageName, "convertToPDFByHTML", sAuthorName, sCreatedBy, ex.Message.ToString(), "");
        }
        return retfilename;
    }
    PdfPageBase Writepdfcontain(PdfPageBase page, string dealerName, string mobile, PdfImage image, string customername)
    {


        string RootPath = AppDomain.CurrentDomain.BaseDirectory;
        string termfilepath = @"DigitalSignature\digitaltermcondition.temp";
        string filepath = String.Format("{0}{1}", RootPath, termfilepath);

        int counter = 0;
        string line;
        int y = 10;
        // Read the file and display it line by line.
        System.IO.StreamReader file =
           new System.IO.StreamReader(filepath);
        while ((line = file.ReadLine()) != null)
        {
            if (counter == 0)
            {
                page.Canvas.DrawString(line, new PdfFont(PdfFontFamily.Helvetica, 12f), new PdfSolidBrush(Color.Black), 10, y);
            }
            else
            {
                y = y + 15;
                if (line.Contains("~"))
                {
                    line = line.Replace("~", "").Replace("{name}", dealerName);
                    page.Canvas.DrawString(line, new PdfFont(PdfFontFamily.Helvetica, 10f), new PdfSolidBrush(Color.Black), 10, y);
                }
                else
                {
                    page.Canvas.DrawString(line, new PdfFont(PdfFontFamily.Helvetica, 10f), new PdfSolidBrush(Color.Black), 10, y);
                }
            }
            counter++;
        }

        file.Close();

        //y = y + 20;
        //page.Canvas.DrawString(Name, new PdfFont(PdfFontFamily.Helvetica, 10f), new PdfSolidBrush(Color.Black), 10, y);
        //y = y + 20;
        //page.Canvas.DrawString(mobile, new PdfFont(PdfFontFamily.Helvetica, 10f), new PdfSolidBrush(Color.Black), 10, y);


        float width = 100;
        float height = 50;
        float x = (page.Canvas.ClientSize.Width - width) / 2;
        y = y + 30;
        page.Canvas.DrawImage(image, 10, y, width, height);
        y = y + 50;
        page.Canvas.DrawString(customername, new PdfFont(PdfFontFamily.Helvetica, 10f), new PdfSolidBrush(Color.Black), 10, y);
        y = y + 15;
        page.Canvas.DrawString(mobile, new PdfFont(PdfFontFamily.Helvetica, 10f), new PdfSolidBrush(Color.Black), 10, y);
        return page;
    }
    #endregion

    #region "Policy and Guidlines"

    /// <summary>
    /// Get My Reward details
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<SPPPoliciesandGuidelinesResponseDTO> GetPoliciesandGuidelinesResponse()
    {
        List<SPPPoliciesandGuidelinesResponseDTO> ListSPPPoliciesandGuidelinesResponseDTO = new List<SPPPoliciesandGuidelinesResponseDTO>();


        SPPPoliciesandGuidelinesResponseDTO oSPPPoliciesandGuidelinesResponseDTO = null;
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        string vImagePath = SPPUtility.ChannelCorner.Replace("\\", "/") + "/";
        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetSPGViewableContent");

            while (dr.Read())
            {
                oSPPPoliciesandGuidelinesResponseDTO = new SPPPoliciesandGuidelinesResponseDTO();
                if (dr["filepath"] != null)
                {
                    oSPPPoliciesandGuidelinesResponseDTO.filepath = objUtility.GetFilePath(vImagePath + dr["filepath"].ToString());
                }




                ListSPPPoliciesandGuidelinesResponseDTO.Add(oSPPPoliciesandGuidelinesResponseDTO);

            }






        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return ListSPPPoliciesandGuidelinesResponseDTO;
    }

    #endregion

    #region Channel Program List
    /// <summary>
    /// To Get Channle Program List
    /// Added by Shyam Sunder Kumar as on 23-05-2017
    /// </summary>
    /// <param name="vDMSCode">DMS Code</param>
    /// <param name="vSource">Source</param>
    /// <returns>DataTable</returns>
    public DataTable GetChannelProgramList(string vDMSCode, string vSource)
    {
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        try
        {
            dtLayer = new DataLayer();
            return objUtility.GenericReplace(SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spCCPEGetProgramList",
                                                                                                new SqlParameter("@DMSCode", vDMSCode),
                                                                                                 new SqlParameter("@Source", vSource)).Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
    }

    /// <summary>
    /// Function to Add Channel Program Grouped List
    /// Added by Shyam Sunder Kumar as on 17-07-2019
    /// </summary>
    /// <param name="vDMSCode">DMS Code</param>
    /// <param name="vSource">Source</param>
    /// <returns>DataSet</returns>
    public DataSet GetChannelProgramGroupedList(string vDMSCode, string vSource)
    {
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        DataSet ds = new DataSet();
        DataSet dsFinal = new DataSet();
        try
        {
            dtLayer = new DataLayer();
            ds = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spCCPEGetProgramGroupedList",
                                                                                                new SqlParameter("@DMSCode", vDMSCode),
                                                                                             new SqlParameter("@Source", vSource));
            //DataTable tbl1 = new DataTable();
            //tbl1 = ds.Tables[0];
            //tbl1 = objUtility.GenericReplace(tbl1);
            //tbl1.TableName = "grpTable";

            //DataTable tbl2 = new DataTable();
            //tbl2 = ds.Tables[1];
            //tbl2 = objUtility.GenericReplace(tbl2);
            //tbl2.TableName = "prgmTable";

            //dsFinal.Tables.Add(tbl1);
            //dsFinal.Tables.Add(tbl2);
            return ds;

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
    }

    /// <summary>
    /// Validate Webpage Authetication token
    /// </summary>
    /// <param name="vUserID">User ID</param>
    /// <param name="vAuthenticateToken">Authenticate Token</param>
    /// <param name="vAuthorizationToken">Authorization Token</param>
    /// <returns>bool</returns>
    public bool ValidateWebPageServiceApiToken(string vUserID, string vAuthenticateToken, string vAuthorizationToken)
    {
        bool status = false;
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        try
        {

            var AuthorizationToken = SqlHelper.ExecuteScalar(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetAuthorizationToken",
                                                                                                          new SqlParameter("@UserID", vUserID));

            var AuthenticateToken = "7fqJtcYAQzw=";

            if (AuthorizationToken != null && AuthorizationToken.ToString().ToLower() == vAuthorizationToken.ToLower() && AuthenticateToken != null && AuthenticateToken.ToString().ToLower() == objUtility.Decrypt(vAuthenticateToken).ToLower())
            {
                status = true;
            }
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            objDataLayer = null;
        }

        return status;
    }

    public DataTable GetPurchaseAccessoriesDetails(string sDealerCode)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {


            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spPAGetPurchaseAccessoriesDetail",
                  new SqlParameter("@DealerCode", sDealerCode)
                  ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }

    public OrderMaster UpdatePurchaseAccessoriesOrderDetailsbyEstore(string sorderid)
    {
        SPPUtility objUtility = new SPPUtility();

        OrderMaster objOrderMaster = new OrderMaster();
        try
        {
            string URI = ConfigurationManager.AppSettings["EstoreUrl"].ToString(); //"https://stagapi.samsungshop.in/in/clientapp/api/GetOrderDetail";
            string vRequest = string.Empty;
            string appid = ConfigurationManager.AppSettings["EstoreAppID"].ToString();
            string orderid = sorderid;// "400000198";
            vRequest = "{\"AppId\":\"" + appid + "\",\"OrderId\":\"" + orderid + "\"}";
            string myParameters = vRequest;
            objUtility.InsertintoLog("step 8:preparing parmeter " + vRequest + "   getPurchaseAccessoriesHistory", "", "get PurchaseAccessories History",
      Convert.ToInt16(SPPUtility._Sections.PurchaseAccessories), 0);

            ServicePointManager.ServerCertificateValidationCallback += ValidateRemoteCertificate;
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;

            using (WebClient wc = new WebClient())
            {

                objUtility.InsertintoLog("step 9:creating object WebClient   getPurchaseAccessoriesHistory", "", "get PurchaseAccessories History",
Convert.ToInt16(SPPUtility._Sections.PurchaseAccessories), 0);

                wc.Headers[HttpRequestHeader.ContentType] = "application/json";
                string jsonResult = wc.UploadString(URI, myParameters);
                JavaScriptSerializer JavaScriptSerializer = new JavaScriptSerializer();
                objOrderMaster = JavaScriptSerializer.Deserialize<OrderMaster>(jsonResult);

                objUtility.InsertintoLog("step 10: objOrderMaster ", "", "get PurchaseAccessories History",
Convert.ToInt16(SPPUtility._Sections.PurchaseAccessories), 0);
                // Response.Write(HtmlResult);
            }
        }
        catch (Exception ex)
        {
            objUtility.InsertintoLog("step 8:error UpdatePurchaseAccessoriesOrderDetailsbyEstore " + ex.Message + ex.InnerException + "   getPurchaseAccessoriesHistory", "", "get PurchaseAccessories History",
       Convert.ToInt16(SPPUtility._Sections.PurchaseAccessories), 0);

        }
        return objOrderMaster;
    }

    /// <summary>
    /// Certificate validation callback.
    /// </summary>
    private static bool ValidateRemoteCertificate(object sender, X509Certificate cert, X509Chain chain, SslPolicyErrors error)
    {
        SPPUtility objUtility = new SPPUtility();
        // If the certificate is a valid, signed certificate, return true.
        if (error == System.Net.Security.SslPolicyErrors.None)
        {
            return true;
        }

        string strcert = "X509Certificate " + cert.Subject + " Policy Error: " + error.ToString();

        objUtility.InsertintoLog("step 8:error ValidateRemoteCertificate " + strcert + "   getPurchaseAccessoriesHistory", "", "get PurchaseAccessories History",
      Convert.ToInt16(SPPUtility._Sections.PurchaseAccessories), 0);
        return true;
    }
    public string GetPurchaseAccessoryUserTypeList()
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dtPurchaseAssoceries = null;
        string usertype = string.Empty;
        try
        {


            dtPurchaseAssoceries = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spPAGetPurchaseAccessoriesUserType").Tables[0];
            if (dtPurchaseAssoceries != null && dtPurchaseAssoceries.Rows.Count > 0)
            {
                for (int i = 0; i < dtPurchaseAssoceries.Rows.Count; i++)
                {
                    if (string.IsNullOrEmpty(usertype))
                        usertype = dtPurchaseAssoceries.Rows[i]["UserType"].ToString();
                    else
                        usertype = usertype + "," + dtPurchaseAssoceries.Rows[i]["UserType"].ToString();
                }

            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return usertype;

    }
    public string GetSambandhSchemeUserTypeList()
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSambandhScheme = null;
        string usertype = string.Empty;
        try
        {


            dtSambandhScheme = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetSambandhSchemeUserType").Tables[0];
            if (dtSambandhScheme != null && dtSambandhScheme.Rows.Count > 0)
            {
                for (int i = 0; i < dtSambandhScheme.Rows.Count; i++)
                {
                    if (string.IsNullOrEmpty(usertype))
                        usertype = dtSambandhScheme.Rows[i]["UserType"].ToString();
                    else
                        usertype = usertype + "," + dtSambandhScheme.Rows[i]["UserType"].ToString();
                }

            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return usertype;

    }
    public bool IsPurchaseAccesoriesDealer(string dealercode)
    {
        bool _Validdealer = false;
        DataTable dtDealerCategory = new DataTable();
        try
        {
            string PurchaseAccesoriesDealerCategory = GetPurchaseAccessoryUserTypeList();
            dtDealerCategory = GetCategory(dealercode);
            if (dtDealerCategory != null && dtDealerCategory.Rows.Count > 0)
            {
                for (int i = 0; i < dtDealerCategory.Rows.Count; i++)
                {
                    string _DealerCategory = dtDealerCategory.Rows[i]["VALUE"].ToString();
                    if (!string.IsNullOrEmpty(PurchaseAccesoriesDealerCategory))
                    {
                        if (("," + PurchaseAccesoriesDealerCategory + ",").Contains("," + _DealerCategory + ","))
                        {
                            _Validdealer = true;
                            return _Validdealer;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _Validdealer;
    }
    public bool IsSambandhSchemeDealer(string dealercode)
    {
        bool _Validdealer = false;
        DataTable dtDealerCategory = new DataTable();
        try
        {
            string SambandhSchemeDealerCategory = GetSambandhSchemeUserTypeList();
            dtDealerCategory = GetCategory(dealercode);
            if (dtDealerCategory != null && dtDealerCategory.Rows.Count > 0)
            {
                for (int i = 0; i < dtDealerCategory.Rows.Count; i++)
                {
                    string _DealerCategory = dtDealerCategory.Rows[i]["VALUE"].ToString();
                    if (!string.IsNullOrEmpty(SambandhSchemeDealerCategory))
                    {
                        if (("," + SambandhSchemeDealerCategory + ",").Contains("," + _DealerCategory + ","))
                        {
                            _Validdealer = true;
                            return _Validdealer;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _Validdealer;
    }
    public bool IsSCPDealer(string dealercode)
    {
        bool _Validdealer = false;
        DataTable dtDealerCategory = new DataTable();
        try
        {

            dtDealerCategory = GetCategory(dealercode);
            if (dtDealerCategory != null && dtDealerCategory.Rows.Count > 0)
            {
                _Validdealer = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _Validdealer;
    }
    public string GetPurchaseAccesoriesDealer(string dealercode)
    {

        DataTable dtDealerCategory = new DataTable();
        string UserType = string.Empty;
        try
        {

            dtDealerCategory = GetCategory(dealercode);
            string PurchaseAccesoriesDealerCategory = GetPurchaseAccessoryUserTypeList();
            if (dtDealerCategory != null && dtDealerCategory.Rows.Count > 0)
            {
                for (int i = 0; i < dtDealerCategory.Rows.Count; i++)
                {
                    string _DealerCategory = dtDealerCategory.Rows[i]["VALUE"].ToString();
                    if (!string.IsNullOrEmpty(PurchaseAccesoriesDealerCategory))
                    {
                        if (("," + PurchaseAccesoriesDealerCategory + ",").Contains("," + _DealerCategory + ","))
                        {
                            UserType = _DealerCategory;
                            return UserType;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return UserType;
    }


    /// <summary>
    /// Function Created By Shaif Rizvi on 9-2-2018 for Purchase Accessory Menu List.
    /// </summary>
    /// <returns></returns>
    public DataTable GetPurchaseAccessoryMenuList(string usertype)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {


            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spCCPAMenuDetails",
                  new SqlParameter("@search", usertype), new SqlParameter("@IsDefault", "1")
                  ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dt;

    }
    public bool IsPurchaseAccesoriesDealerbystate(string dealercode)
    {
        bool _Validdealer = false;
        DataTable dtDealerCategory = new DataTable();
        try
        {
            DataTable SPPTable = GetUserDetails(dealercode);
            string stateid = string.Empty;
            if (SPPTable.Rows[0]["RefStateID"] != null)
            {
                stateid = SPPTable.Rows[0]["RefStateID"].ToString();
            }

            if (ConfigurationManager.AppSettings["checkPurchaseAccesoriesbystate"] == "1")
            {
                if (!string.IsNullOrEmpty(stateid))
                {


                    if (ConfigurationManager.AppSettings["PurchaseAccesoriesDealerbystateid"] != null)
                    {
                        if (("," + ConfigurationManager.AppSettings["PurchaseAccesoriesDealerbystateid"] + ",").Contains("," + stateid + ","))
                        {
                            _Validdealer = true;
                            return _Validdealer;
                        }
                    }

                }
            }
            else
            {
                _Validdealer = true;
                return _Validdealer;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return _Validdealer;
    }
    /// <summary>
    /// Method Written By Amit on 12-June-2017 to get Dealer Category
    /// </summary>
    /// <param name="sDealerCode"></param>
    /// <returns></returns>
    public DataTable GetCategory(string sDealerCode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {


            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetCategory",
                  new SqlParameter("@DistCode", sDealerCode)
                  ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }

    /// <summary>
    /// Function to Get SCP Reward Coupon
    /// Added by Shyam Sunder Kumar as on 17-04-2019
    /// </summary>
    /// <param name="sDealerCode">Dealer Code</param>
    /// <returns>DataTable</returns>
    public DataTable GetSCPRewardsCoupon(string sDealerCode)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {


            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSCPGetRewardsCoupon",
                  new SqlParameter("@DealerCode", sDealerCode)
                  ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }

    public DataTable GetSCPCategory(string sDealerCode)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {


            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetSCPCategory",
                  new SqlParameter("@DistCode", sDealerCode)
                  ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }


    #endregion

    #region "Overlaying Banner"

    /// <summary>
    /// GetOverlayingBanner
    /// </summary>
    /// <param name="PartnerCode">UserTypeID</param>
    /// <returns>DataTable</returns>
    public DataTable GetOverlayingBanner(string UserTypeID)
    {


        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {

            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPGetOverlayingBanner",
                  new SqlParameter("@CurrentDate", DateTime.Now),
                  new SqlParameter("@UserTypeID", UserTypeID)
                  ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }


    #endregion

    #region SmartDost

    /// <summary>
    /// Function to SmartDost Integration Login History
    /// </summary>
    public bool SmartDostIntegrationLoginHistory(string StoreCode,
string imeinumber,
string mobilenumber,
string androidid,
string systemcode,
string rolecode,
string rolename,
string usertype)
    {
        DataLayer dtLayer = new DataLayer();

        bool retval = false;

        try
        {
            DataSet ds = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSmartDostIntegrationLoginHistory",
                                                                                                        new SqlParameter("@StoreCode", StoreCode),
                                                                                                        new SqlParameter("@imeinumber", imeinumber),
                                                                                                        new SqlParameter("@mobilenumber", mobilenumber),
                                                                                                        new SqlParameter("@androidid", androidid),
                                                                                                        new SqlParameter("@systemcode", systemcode),
                                                                                                        new SqlParameter("@rolecode", rolecode),
                                                                                                        new SqlParameter("@rolename", rolename),
                                                                                                        new SqlParameter("@usertype", usertype));

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                retval = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString()) == 1 ? true : false;
                ;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (dtLayer != null)
            {
                dtLayer = null;
            }
        }
        return retval;
    }
    #endregion

    #region"B2B"
    /// <summary>
    /// Method Name   : SPPGetIndustryByCaseStudy
    /// Createdby     : chandra prakash singh
    /// Created On    : 20 april 2018
    /// Description    :To get all Industry with respect to Case Study.
    /// </summary>
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="submenuid">submenuid</param>

    /// <returns>DataTable</returns>
    public DataTable SPPGetIndustryByCaseStudy(int usercode, int submenuid)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsIndustryList = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtIndustryList = null;
        try
        {
            dsIndustryList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetB2BCaseStudyIndustryList", new SqlParameter("@SubmenuId", submenuid));
            dtIndustryList = objUtility.GenericReplace(dsIndustryList.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtIndustryList;
    }

    /// <summary>
    /// Method Name   : SPPGetCaseStudyDetailByIndustry
    /// Createdby     : chandra prakash singh
    /// Created On    : 20 april 2018
    /// Description    :To get Case Study Detail  with respect to Industry.
    /// </summary>
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="industryid">industry id</param>

    /// <returns>DataTable</returns>  
    public DataSet SPPGetCaseStudyDetailByIndustry(int usercode, string industryid)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsCaseStudyDetails = null;
        SPPUtility objUtility = new SPPUtility();
        // DataTable dtCaseStudyDetails = null;
        try
        {
            dsCaseStudyDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SPPGetB2BCaseStudyDetailByIndustryID", new SqlParameter("@IndustryId", industryid));

            //dtCaseStudyDetails = objUtility.GenericReplace(dsCaseStudyDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsCaseStudyDetails;
    }

    /// <summary>
    /// Method Name   : SPPGetSolutionMenu
    /// Createdby     : Shaif Rizvi
    /// Created On    : 07 may 2018
    /// Description    :To get Case Solution Menu
    /// </summary>

    /// <param name="submenuid">submenuid</param>

    /// <returns>DataTable</returns>  
    public DataTable SPPGetSolutionMenu(string submenuid)
    {
        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dtCaseStudyDetails = null;
        try
        {
            dtCaseStudyDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetB2BSolution", new SqlParameter("@SubmenuId", submenuid)).Tables[0];

            dtCaseStudyDetails = objUtility.GenericReplace(dtCaseStudyDetails);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtCaseStudyDetails;
    }

    /// <summary>
    /// Method Name   : SPPGetB2BAdvanceSearchingCriteriaDetails
    /// Createdby     : CHANDRA PRAKASH SINGH
    /// Created On    : 07 may 2018
    /// Description    :To get B2B Advance Searching Criteria LIST Details
    /// </summary>

    /// <param name="submenuid">menuid</param>

    /// <returns>DataSet</returns>  
    public DataSet SPPGetB2BAdvanceSearchingCriteriaDetails(int usercode, string menuid)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsB2BAdvanceSearchingDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtB2BAdvanceSearchingDetails = null;


        try
        {
            dsB2BAdvanceSearchingDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SPPGetB2BAdvanceSearchingCriteria", new SqlParameter("@MenuId", menuid));



            dtB2BAdvanceSearchingDetails = objUtility.GenericReplace(dsB2BAdvanceSearchingDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsB2BAdvanceSearchingDetails;
    }


    /// <summary>
    /// Method Name   : SPPGetB2BAdvanceSearchingResultDetails
    /// Createdby     : CHANDRA PRAKASH SINGH
    /// Created On    : 07 may 2018
    /// Description    :To get B2B Advance Searching Result LIST Details
    /// </summary>

    /// <param name="submenuid">searchid</param>
    /// <param name="submenuid">priceRange</param>
    /// <returns>DataSet</returns>  


    public DataSet SPPGetB2BAdvanceSearchingResultDetails(int usercode, string searchbusinessid, string searchknoxid, string searchindustryid, string searchproductcatid, string minpricerange, string maxpricerange, string searchtext)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsB2BAdvanceSearchingResultDetails = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtB2BAdvanceSearchingResultDetails = null;


        try
        {
            dsB2BAdvanceSearchingResultDetails = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "SPPGetB2BAdvanceSearchingResult", new SqlParameter("@SearchBusinessId", searchbusinessid), new SqlParameter("@SearchKnoxId", searchknoxid)
                , new SqlParameter("@SearchIndustryId", searchindustryid), new SqlParameter("@SearchProductCategoryId", searchproductcatid), new SqlParameter("@MinPriceRange", minpricerange), new SqlParameter("@MaxPriceRange", maxpricerange), new SqlParameter("@SearchText", searchtext));



            dtB2BAdvanceSearchingResultDetails = objUtility.GenericReplace(dsB2BAdvanceSearchingResultDetails.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dsB2BAdvanceSearchingResultDetails;
    }


    /// <summary>
    /// Method Name   : SPPGetAdvanceSearchTextName
    /// Createdby     : chandra prakash singh
    /// Created On    : 20 april 2018
    /// Description    :To get all Search Text Name.
    /// </summary>
    /// <param name="usercode">Autogenrated User ID</param>
    /// <param name="submenuid">searchText</param>

    /// <returns>DataTable</returns>
    public DataTable SPPGetAdvanceSearchTextName(int usercode, string searchText)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsSearchTextNameList = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable dtSearchTextList = null;
        try
        {
            dsSearchTextNameList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetB2BAdvanceSearchTextNameList", new SqlParameter("@searchText", searchText));
            dtSearchTextList = objUtility.GenericReplace(dsSearchTextNameList.Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (objUtility != null)
            {
                objUtility = null;
            }
        }
        return dtSearchTextList;
    }

    public List<SPPProductDetailResponseSDDTO> ProductDetails(string productcode, string userid)
    {
        List<SPPProductResponseSDDTO> lstProduct = new List<SPPProductResponseSDDTO>();
        SPPBusinessLayer sppobjBal = new SPPBusinessLayer();
        DataTable dtProduct = new DataTable();
        SPPUtility objUtility = new SPPUtility();
        SPPProductDetailResponseSDDTO _objDetails = null;
        List<SPPProductDetailResponseSDDTO> _lstDetails = null;

        productimagesSD _objimage = null;
        List<productimagesSD> _lstimage = null;
        productspecificationSD _objspec = null;
        List<productspecificationSD> _lstspec = null;

        productspecvaluesSD _objvalues = null;
        List<productspecvaluesSD> __lstvalues = null;

        DataSet ds = null;
        DataTable dtDetails = null;
        DataTable dtimages = null;
        DataTable dtTitle = null;
        DataTable dtSpec = null;

        string strPath = SPPUtility.ProductCenter;
        string sPath = SPPUtility.ProductCenter.Replace("\\", "/");
        try
        {

            dtProduct = sppobjBal.SPPSDGetProductByProductCode(productcode, userid);

            if (dtProduct != null && dtProduct.Rows.Count > 0)
            {

                for (int i = 0; i < dtProduct.Rows.Count; i++)
                {
                    SPPProductResponseSDDTO objProduct = new SPPProductResponseSDDTO();

                    if (dtProduct.Rows[i]["ProductNo"] != null)
                        objProduct.productcode = dtProduct.Rows[i]["ProductNo"].ToString();

                    if (dtProduct.Rows[i]["ProductName"] != null)
                        objProduct.productname = dtProduct.Rows[i]["ProductName"].ToString();


                    if (dtProduct.Rows[i]["ProductID"] != null)
                        objProduct.productid = dtProduct.Rows[i]["ProductID"].ToString();

                    if (dtProduct.Rows[i]["DealerPrice"] != null)
                        objProduct.dealerprice = dtProduct.Rows[i]["DealerPrice"].ToString();

                    if (dtProduct.Rows[i]["MRP"] != null)
                        objProduct.maxretailprice = dtProduct.Rows[i]["MRP"].ToString();

                    ds = sppobjBal.SPPSDGetProductDetails(objProduct.productcode, string.Empty);

                    if (ds != null && ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        {
                            _lstDetails = new List<SPPProductDetailResponseSDDTO>();

                            dtDetails = ds.Tables[0];
                            //  dtDetails = objUtility.GenericReplace(dtDetails);

                            foreach (DataRow dr in dtDetails.Rows)
                            {
                                _objDetails = new SPPProductDetailResponseSDDTO();
                                _objDetails.colorcode = dr["ColorCode"].ToString();
                                _objDetails.colorname = dr["ColorName"].ToString();
                                _objDetails.skucode = dr["SkuCode"].ToString();

                                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                                {
                                    DataView dvimages = new DataView(ds.Tables[1]);
                                    //dvimages.RowFilter = "ProductsID = " + dr["ProductsID"].ToString();
                                    //Change By Amit Singh on 10-Oct-2019 for colour Code Issue
                                    dvimages.RowFilter = "ProductsID = " + dr["ProductsID"].ToString() + " and ColorCode = '" + dr["ColorCode"].ToString() + "'";

                                    dtimages = dvimages.ToTable();

                                    _lstimage = new List<productimagesSD>();
                                    foreach (DataRow drimg in dtimages.Rows)
                                    {
                                        _objimage = new productimagesSD();
                                        _objimage.largeimageurl = drimg["largeimageurl"].ToString();
                                        _objimage.thumbimageurl = drimg["thumbimageurl"].ToString();

                                        _lstimage.Add(_objimage);
                                    }

                                    _objDetails.productimages = _lstimage;
                                }

                                if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                                {
                                    _lstspec = new List<productspecificationSD>();
                                    DataView dvTitle = new DataView(ds.Tables[2]);
                                    dvTitle.RowFilter = "ProductsID = " + dr["ProductsID"].ToString();
                                    dtTitle = dvTitle.ToTable();

                                    foreach (DataRow drTitle in dtTitle.Rows)
                                    {
                                        _objspec = new productspecificationSD();
                                        _objspec.title = drTitle["Title"].ToString();

                                        DataView dvspec = new DataView(ds.Tables[3]);
                                        dvspec.RowFilter = "ProductsID = " + dr["ProductsID"].ToString() + " and Title = '" + drTitle["Title"].ToString() + "'";
                                        dtSpec = dvspec.ToTable();

                                        __lstvalues = new List<productspecvaluesSD>();

                                        foreach (DataRow drSpec in dtSpec.Rows)
                                        {
                                            _objvalues = new productspecvaluesSD();
                                            _objvalues.key = drSpec["speckey"].ToString();
                                            _objvalues.value = drSpec["specValue"].ToString();
                                            __lstvalues.Add(_objvalues);
                                        }
                                        _objspec.values = __lstvalues;
                                        _lstspec.Add(_objspec);
                                    }

                                    _objDetails.specification = _lstspec;
                                }

                                _lstDetails.Add(_objDetails);
                            }

                            objProduct.details = _lstDetails;
                        }
                    }

                    lstProduct.Add(objProduct);
                }


            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return _lstDetails;
    }
    #endregion

    #region DashBord Analytics
    /// <summary>
    /// To Get Channle Program Menu
    /// Added by Shaif Rizvi as on 27-07-2017
    /// </summary>
    /// <param name="vDMSCode">DMS Code</param>
    /// <returns>DataTable</returns>
    //public SPPMenuDashbordResponseDTO GetDAGetMenu(string vProgramID)
    //{
    //    DataLayer dtLayer = null;
    //    SPPUtility objUtility = new SPPUtility();

    //    SPPMenuDashbordResponseDTO oMenuDashbord = new SPPMenuDashbordResponseDTO();
    //    oMenuDashbord.data = new List<Data>();

    //    Data oListData = new Data();
    //    oListData.parameter = new List<Parameter>();

    //    Parameter oListParameter = new Parameter();
    //    oListParameter.measurment = new List<Measurment>();




    //    Data oData = null;
    //    Parameter oParameter = null;
    //    Measurment oMeasurment = null;

    //    try
    //    {
    //        dtLayer = new DataLayer();
    //        DataTable dtMenu = objUtility.GenericReplace(SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_GetMenu",
    //                                                                                          new SqlParameter("@ProgramID", vProgramID)).Tables[0]);

    //        int param = -1;
    //        int catid = -1;
    //        int mesu = 0;
    //        List<int> keydup = new List<int>();
    //        for (int i = 0; i < dtMenu.Rows.Count; i++)
    //        {
    //            if (!keydup.Contains(Convert.ToInt32(dtMenu.Rows[i]["CategoryID"])))
    //            {

    //                if (catid != Convert.ToInt32(dtMenu.Rows[i]["CategoryID"]))
    //                {
    //                    oData = new Data();
    //                    oData.categoryid = dtMenu.Rows[i]["CategoryID"].ToString();
    //                    oData.categoryname = dtMenu.Rows[i]["CategoryName"].ToString();
    //                    oData.isapplicable = Convert.ToBoolean(dtMenu.Rows[i]["isapplicable"]);
    //                    catid = Convert.ToInt32(dtMenu.Rows[i]["CategoryID"]);
    //                    oData.parameter = new List<Parameter>();
    //                    keydup.Add(catid);
    //                }

    //                for (int j = 0; j < dtMenu.Rows.Count; j++)
    //                {
    //                    if (catid == Convert.ToInt32(dtMenu.Rows[j]["CategoryID"]))
    //                    {
    //                        // -----------------------------Parameter------------------------------------

    //                        if (param != Convert.ToInt32(dtMenu.Rows[j]["parameterid"]))
    //                        {
    //                            oParameter = new Parameter();
    //                            oParameter.parameterid = dtMenu.Rows[j]["parameterid"].ToString();
    //                            oParameter.parametername = dtMenu.Rows[j]["parametername"].ToString();
    //                            oParameter.isapplicable = Convert.ToBoolean(dtMenu.Rows[j]["isapplicable"]);
    //                            param = Convert.ToInt32(dtMenu.Rows[j]["parameterid"]);
    //                            oParameter.measurment = new List<Measurment>();
    //                            //-------------------------measurment--------------------------
    //                            for (int x = 0; x < dtMenu.Rows.Count; x++)
    //                            {
    //                                if (param == Convert.ToInt32(dtMenu.Rows[x]["parameterid"]))
    //                                {
    //                                    oMeasurment = new Measurment();
    //                                    oMeasurment.measurmentid = dtMenu.Rows[x]["measurmentid"].ToString();
    //                                    oMeasurment.measurmentname = dtMenu.Rows[x]["measurmentname"].ToString();
    //                                    oParameter.measurment.Add(oMeasurment);
    //                                }

    //                                //  oParameter.measurment.Add(oMeasurment);
    //                            }
    //                            //-------------------------------measurment End--------------------------------



    //                            oData.parameter.Add(oParameter);
    //                        }

    //                        // oListData.parameter.Add(oParameter);
    //                        //  -------------------------------------Parameter end-------------------------------------------
    //                    }
    //                }
    //                oMenuDashbord.data.Add(oData);

    //            }
    //        }

    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;

    //    }
    //    finally
    //    {
    //        if (dtLayer != null)
    //            dtLayer = null;

    //    }
    //    return oMenuDashbord;
    //}
    public SPPMenuDashbordResponseDTO GetDAGetMenu(string vProgramID, string UserCode)
    {
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();

        SPPMenuDashbordResponseDTO oMenuDashbord = new SPPMenuDashbordResponseDTO();
        oMenuDashbord.data = new List<Data>();

        Data oListData = new Data();
        oListData.parameter = new List<Parameter>();

        Parameter oListParameter = new Parameter();
        oListParameter.measurment = new List<Measurment>();

        Usertype oUsertype = new Usertype();
        oMenuDashbord.usertype = new List<Usertype>();

        TierReport otierreport = new TierReport();
        oMenuDashbord.tierreport = new List<TierReport>();


        Data oData = null;
        Parameter oParameter = null;
        Measurment oMeasurment = null;

        try
        {
            dtLayer = new DataLayer();
            DataSet dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_GetMenu",
                                                                                              new SqlParameter("@ProgramID", vProgramID)
                                                                                              , new SqlParameter("@UserCode", UserCode));

            int param = -1;
            int catid = -1;
            int mesu = 0;
            List<int> keydup = new List<int>();
            DataTable dtMenu = objUtility.GenericReplace(dsMenu.Tables[0]);
            for (int i = 0; i < dtMenu.Rows.Count; i++)
            {
                if (!keydup.Contains(Convert.ToInt32(dtMenu.Rows[i]["CategoryID"])))
                {

                    if (catid != Convert.ToInt32(dtMenu.Rows[i]["CategoryID"]))
                    {
                        oData = new Data();
                        oData.categoryid = dtMenu.Rows[i]["CategoryID"].ToString();
                        oData.categoryname = dtMenu.Rows[i]["CategoryName"].ToString();
                        oData.iscategoryapplicable = Convert.ToBoolean(dtMenu.Rows[i]["isapplicable"]);
                        catid = Convert.ToInt32(dtMenu.Rows[i]["CategoryID"]);
                        oData.parameter = new List<Parameter>();
                        keydup.Add(catid);
                    }

                    for (int j = 0; j < dtMenu.Rows.Count; j++)
                    {
                        if (catid == Convert.ToInt32(dtMenu.Rows[j]["CategoryID"]))
                        {
                            // -----------------------------Parameter------------------------------------

                            if (param != Convert.ToInt32(dtMenu.Rows[j]["parameterid"]))
                            {
                                oParameter = new Parameter();
                                oParameter.parameterid = dtMenu.Rows[j]["parameterid"].ToString();
                                oParameter.parametername = dtMenu.Rows[j]["parametername"].ToString();
                                oParameter.isparameterapplicable = Convert.ToBoolean(dtMenu.Rows[j]["isapplicable1"]);
                                param = Convert.ToInt32(dtMenu.Rows[j]["parameterid"]);
                                oParameter.measurment = new List<Measurment>();
                                //-------------------------measurment--------------------------
                                for (int x = 0; x < dtMenu.Rows.Count; x++)
                                {
                                    if (param == Convert.ToInt32(dtMenu.Rows[x]["parameterid"]))
                                    {
                                        oMeasurment = new Measurment();
                                        oMeasurment.measurmentid = dtMenu.Rows[x]["measurmentid"].ToString();
                                        oMeasurment.measurmentname = dtMenu.Rows[x]["measurmentname"].ToString();
                                        oParameter.measurment.Add(oMeasurment);
                                    }

                                    //  oParameter.measurment.Add(oMeasurment);
                                }
                                //-------------------------------measurment End--------------------------------



                                oData.parameter.Add(oParameter);
                            }

                            // oListData.parameter.Add(oParameter);
                            //  -------------------------------------Parameter end-------------------------------------------
                        }
                    }
                    oMenuDashbord.data.Add(oData);

                }
            }
            DataTable dtuser = objUtility.GenericReplace(dsMenu.Tables[1]);
            if (dtuser != null && dtuser.Rows.Count > 0)
            {

                for (int i = 0; i < dtuser.Rows.Count; i++)
                {
                    oUsertype = new Usertype();
                    oUsertype.usertypeid = dtuser.Rows[i]["usertypeid"].ToString();
                    oUsertype.usertypename = dtuser.Rows[i]["usertypename"].ToString();
                    oUsertype.username = dtuser.Rows[i]["username"].ToString();
                    oUsertype.filterapplicable = dtuser.Rows[i]["filterapplicable"].ToString();
                    oMenuDashbord.usertype.Add(oUsertype);

                }


            }
            DataTable dttier = objUtility.GenericReplace(dsMenu.Tables[2]);
            if (dttier != null && dttier.Rows.Count > 0)
            {

                for (int i = 0; i < dttier.Rows.Count; i++)
                {
                    otierreport = new TierReport();
                    otierreport.tierid = dttier.Rows[i]["tierid"].ToString();
                    otierreport.tiertext = dttier.Rows[i]["tiertext"].ToString();
                    otierreport.isvisible = dttier.Rows[i]["isVisible"].ToString();
                    oMenuDashbord.tierreport.Add(otierreport);

                }


            }
            //oMenuDashbord.istierapplicable = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spCCPEGetTierApplicable",
            //                                                                                  new SqlParameter("@DistCode", UserCode)).Tables[0].Rows[0]["IsApplicable"].ToString();

            /*For Tier Applicable*/
            if (dsMenu.Tables[3] != null && dsMenu.Tables[3].Rows.Count > 0)
            {
                oMenuDashbord.istierapplicable = dsMenu.Tables[3].Rows[0]["IsApplicable"].ToString();
            }
            /*End Tier Applicable*/

            /*For Graph Color*/
            if (dsMenu.Tables[4] != null && dsMenu.Tables[4].Rows.Count > 0)
            {
                DataTable dtColor = new DataTable();
                List<GraphColor> _lstGraph = new List<GraphColor>();
                GraphColor _color = new GraphColor();
                /*for Pie*/
                dtColor = objUtility.GenericReplace(dsMenu.Tables[4]);
                DataView dvColor = new DataView();
                dvColor = new DataView(dtColor);
                dvColor.RowFilter = "GraphID = 11";
                dtColor = dvColor.ToTable();

                foreach (DataRow dr in dtColor.Rows)
                {
                    _color = new GraphColor();
                    _color.color = dr["color"].ToString();
                    _lstGraph.Add(_color);
                }
                oMenuDashbord.piecolor = _lstGraph;
                /*for Bar*/
                dtColor = objUtility.GenericReplace(dsMenu.Tables[4]);
                _lstGraph = new List<GraphColor>();
                dvColor = new DataView();
                dvColor = new DataView(dtColor);
                dvColor.RowFilter = "GraphID = 12";
                dtColor = dvColor.ToTable();

                foreach (DataRow dr in dtColor.Rows)
                {
                    _color = new GraphColor();
                    _color.color = dr["color"].ToString();
                    _lstGraph.Add(_color);
                }
                oMenuDashbord.barcolor = _lstGraph;

                /*for Line*/
                dtColor = objUtility.GenericReplace(dsMenu.Tables[4]);
                _lstGraph = new List<GraphColor>();
                dvColor = new DataView();
                dvColor = new DataView(dtColor);
                dvColor.RowFilter = "GraphID = 13";
                dtColor = dvColor.ToTable();

                foreach (DataRow dr in dtColor.Rows)
                {
                    _color = new GraphColor();
                    _color.color = dr["color"].ToString();
                    _lstGraph.Add(_color);
                }
                oMenuDashbord.linecolor = _lstGraph;
            }
            /*End Graph Color*/

            /*For Graph Horizontal Line Color*/
            if (dsMenu.Tables[5] != null && dsMenu.Tables[5].Rows.Count > 0)
            {
                DataTable dtHColor = new DataTable();
                dtHColor = objUtility.GenericReplace(dsMenu.Tables[5]);
                List<GraphColor> _lstGraph = new List<GraphColor>();
                GraphColor _color = new GraphColor();
                foreach (DataRow dr in dtHColor.Rows)
                {
                    _color = new GraphColor();
                    _color.color = dr["color"].ToString();
                    _lstGraph.Add(_color);
                }
                oMenuDashbord.horizoncolor = _lstGraph;
            }
            /*End For Graph Horizontal Line Color*/
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return oMenuDashbord;
    }

    //public SPPSearchDashbordResponseDTO GetSearchDashbord(string vProgramID, string vMonth, string vYear, string vPartnerCode)
    //{
    //    DataLayer dtLayer = null;
    //    SPPUtility objUtility = new SPPUtility();

    //    SPPSearchDashbordResponseDTO oSPPSearchDashbordResponseDTO = new SPPSearchDashbordResponseDTO();

    //    oSPPSearchDashbordResponseDTO.Chart = new List<chartdata>();

    //    chartdata ochartdata = new chartdata();
    //    ochartdata.charttitle = "Winner %";
    //    ochartdata.isapplicable = true;

    //    chartvalue ochartvalue = null;
    //    ochartdata.ChartDetails = new List<chartvalue>();

    //    try
    //    {
    //        dtLayer = new DataLayer();
    //        DataTable dtMenu = objUtility.GenericReplace(SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchChart",
    //                                                                                          new SqlParameter("@ProgramID", string.Empty),
    //                                                                                          new SqlParameter("@Month", "7"),
    //                                                                                          new SqlParameter("@Year", "2017"),
    //                                                                                          new SqlParameter("@PartnerCode", string.Empty)).Tables[0]);


    //        for (int i = 0; i < dtMenu.Rows.Count; i++)
    //        {
    //            ochartvalue = new chartvalue();
    //            ochartvalue.id = dtMenu.Rows[i]["id"].ToString();
    //            ochartvalue.columnheader = dtMenu.Rows[i]["columnheader"].ToString();
    //            ochartvalue.columnvalue = dtMenu.Rows[i]["columnvalue"].ToString();
    //            ochartdata.ChartDetails.Add(ochartvalue);
    //        }

    //        oSPPSearchDashbordResponseDTO.Chart.Add(ochartdata);

    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;

    //    }
    //    finally
    //    {
    //        if (dtLayer != null)
    //            dtLayer = null;

    //    }
    //    return oSPPSearchDashbordResponseDTO;
    //}

    public bool ValidateDashboardSearch(string vProgramID, string vMonth, string quarter, string vYear, string cluster, string region, string state)
    {
        DataLayer dtLayer = new DataLayer();
        int ValidationCount = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_ValidateDashboardSearch",
                                                                                              new SqlParameter("@ProgramID", vProgramID),
                                                                                              new SqlParameter("@Month", vMonth == "0" ? quarter : vMonth),
                                                                                         new SqlParameter("@Year", vYear),
                                                                                          new SqlParameter("@cluster", cluster),
                                                                                           new SqlParameter("@Subregion", region),
                                                                                            new SqlParameter("@state", state)
                                                                                           ).Tables[0].Rows.Count;
        if (ValidationCount > 0)
            return true;
        else
            return false;
    }

    /// <summary>
    /// Added by Shyam Sunder Kumar as on 13-Oct-2019 to Dashbaord Enhancement
    /// </summary>
    /// <param name="vProgramID"></param>
    /// <param name="vMonth"></param>
    /// <param name="vYear"></param>
    /// <param name="vPartnerCode"></param>
    /// <param name="ParameterID"></param>
    /// <param name="vReportID">Report ID  0 : Landing Report - Geo,1 : City Tier Snapshot, 2 : Regional Snapshot, 3 : SPD Wise Snapshot, 4 : Revenue Tier Snapshot</param>
    /// <param name="Quarter"></param>
    /// <param name="LoginUser"></param>
    /// <param name="cluster"></param>
    /// <param name="region"></param>
    /// <param name="state"></param>
    /// <param name="partnertypeid"></param>
    /// <returns></returns>
    public List<SPPSearchDashbordResponseDTO> GetSearchDashbord(string vProgramID
        , string vMonth
        , string vYear
        , string vPartnerCode
        , string vMeasurementID
        , string vReportID
        , string vQuarter
        , string vLoginUser
        , string vcluster
        , string vregion
        , string vstate
        , string vpartnertypeid
        )
    {
        DataLayer dtLayer = null;
        DataSet dsMenu = null;
        SPPUtility objUtility = new SPPUtility();
        List<SPPSearchDashbordResponseDTO> objSPPSearchDashbord = new List<SPPSearchDashbordResponseDTO>();
        SPPSearchDashbordResponseDTO objSPPSearchDashbordResponseDTO = new SPPSearchDashbordResponseDTO();

        DataTable dt = new DataTable();
        DataTable dtconfigure = new DataTable();

        DataTable dtMeasurement = new DataTable();
        DataTable dtRange = new DataTable();
        Chartdetail BachP = new Chartdetail();
        Chartdetail2 LachP = new Chartdetail2();
        Chartdetail3 TachP = new Chartdetail3();
        Chartdetailpie PachP = new Chartdetailpie();
        rangebar _rangebar = new rangebar();
        rangevalue _rangevalue = new rangevalue();

        Chart c = new Chart();
        Chart c1 = new Chart();
        Line L = new Line();
        Line L1 = new Line();
        Bar B = new Bar();
        Bar B1 = new Bar();
        Pie P = new Pie();
        Table T = new Table();
        Table T1 = new Table();
        Table T2 = new Table();
        Table T3 = new Table();
        string vBreadCrumb = string.Empty;
        try
        {
            dtLayer = new DataLayer();

            /*Report ID 
             0 : Landing Report - Geo
             1 : City Tier Snapshot
             2 : Regional Snapshot
             3 : SPD Wise Snapshot
             4 : Revenue Tier Snapshot
           */

            dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordReports",
                                                                                               new SqlParameter("@ProgramID", vProgramID),
                                                                                               new SqlParameter("@Month", (vMonth == "0" ? vQuarter : vMonth)),
                                                                                               new SqlParameter("@Year", vYear),
                                                                                               new SqlParameter("@PartnerCode", vPartnerCode),
                                                                                               new SqlParameter("@cluster", vcluster),
                                                                                               new SqlParameter("@region", vregion),
                                                                                               new SqlParameter("@state", vstate),
                                                                                               new SqlParameter("@LoginUser", vLoginUser),
                                                                                               new SqlParameter("@Level3ID", vMeasurementID),
                                                                                               new SqlParameter("@ReportID", vReportID)
                                                                                               );
            if (dsMenu.Tables[4] != null && dsMenu.Tables[4].Rows.Count > 0)
            {
                vBreadCrumb = dsMenu.Tables[4].Rows[0]["BreadCrumb"].ToString();
            }
            if (dsMenu.Tables[7] != null && dsMenu.Tables[7].Rows.Count > 0)
            {
                dtconfigure = objUtility.GenericReplace(dsMenu.Tables[7]);
            }
            /*Pie Chart*/
            objSPPSearchDashbordResponseDTO = new SPPSearchDashbordResponseDTO();
            objSPPSearchDashbordResponseDTO.chart = new List<Chart>();

            if (vMeasurementID == "0")
            {

                if (dsMenu.Tables[6] != null && dsMenu.Tables[6].Rows.Count > 0)
                {
                    c = new Chart();
                    _rangebar = new rangebar();
                    _rangevalue = new rangevalue();
                    _rangebar.rangevaluelist = new List<rangevalue>();
                    dt = new DataTable();
                    dt = objUtility.GenericReplace(dsMenu.Tables[6]);
                    _rangebar.barname = dt.Rows[0]["RewardText"].ToString();
                    _rangebar.barvalue = dt.Rows[0]["RewardValue"].ToString();


                    if (dsMenu.Tables[5] != null && dsMenu.Tables[5].Rows.Count > 0)
                    {
                        dtRange = new DataTable();
                        dtRange = objUtility.GenericReplace(dsMenu.Tables[5]);
                        foreach (DataRow _dr in dtRange.Rows)
                        {
                            _rangevalue = new rangevalue();
                            _rangevalue.rangename = _dr["RangeText"].ToString();
                            _rangevalue.range = _dr["RangeValue"].ToString();
                            _rangebar.rangevaluelist.Add(_rangevalue);
                        }
                    }

                    c.foottext = string.Empty;
                    c.disclaimer = string.Empty;
                    c.breadcrumb = vBreadCrumb;

                    BachP = new Chartdetail();
                    BachP.columnheader = _rangebar.barname;
                    BachP.columnvalue = _rangebar.barvalue;


                    B = new Bar();
                    B.chartdetails = new List<Chartdetail>();
                    B.chartdetails.Add(BachP);
                    B.rangevaluelist = _rangebar.rangevaluelist;
                    B.color = string.Empty;

                    c.bar.Add(B);

                    T = new Table();
                    T.chartdetails = new List<Chartdetail3>();

                    TachP = new Chartdetail3();
                    TachP.columnheader = string.Empty;
                    TachP.columnvalue = "Value";
                    T.chartdetails.Add(TachP);

                    TachP = new Chartdetail3();
                    TachP.columnheader = dt.Rows[0]["RewardText"].ToString();
                    TachP.columnvalue = dt.Rows[0]["RewardValue"].ToString();
                    T.chartdetails.Add(TachP);

                    //foreach (DataRow _dr in dtRange.Rows)
                    //{
                    //    TachP = new Chartdetail3();
                    //    TachP.columnheader = _dr["RangeText"].ToString();
                    //    TachP.columnvalue = _dr["RangeValue"].ToString();
                    //    T.chartdetails.Add(TachP);
                    //}
                    c.title = (new SPPBusinessLayer()).GetDashbordConfiguration().Where(x => x.id == 3).ToList()[0].value;
                    c.table.Add(T);
                    if (dsMenu.Tables[2] != null && dsMenu.Tables[2].Rows.Count > 0)
                    {
                        c.title = dsMenu.Tables[2].Rows[0]["Title"].ToString();
                        c.foottext = dsMenu.Tables[2].Rows[0]["FootText"].ToString();
                        c.disclaimer = dsMenu.Tables[2].Rows[0]["Disclaimer"].ToString();
                        c.breadcrumb = vBreadCrumb;
                        c.titlefootnote = string.Empty;
                    }
                    objSPPSearchDashbordResponseDTO.chart.Add(c);

                }
                else
                {
                    dt = new DataTable();
                    dt = objUtility.GenericReplace(dsMenu.Tables[1]);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        c = new Chart();
                        c.pie = new List<Pie>();
                        c.table = new List<Table>();
                        P.chartdetails = new List<Chartdetailpie>();
                        T = new Table();
                        T.chartdetails = new List<Chartdetail3>();

                        TachP = new Chartdetail3();
                        TachP.columnheader = string.Empty;

                        TachP.columnvalue = dtconfigure.Rows[0]["winnertext1"].ToString(); //configure winner text
                        T.chartdetails.Add(TachP);

                        foreach (DataRow _dr in dt.Rows)
                        {
                            PachP = new Chartdetailpie();
                            PachP.columnheader = _dr["Reward"].ToString();
                            PachP.columnvalue = _dr["Value"].ToString();
                            P.chartdetails.Add(PachP);

                            TachP = new Chartdetail3();
                            TachP.columnheader = _dr["Reward"].ToString();
                            TachP.columnvalue = _dr["Value"].ToString();
                            T.chartdetails.Add(TachP);
                        }
                        c.table.Add(T);

                        T = new Table();
                        T.chartdetails = new List<Chartdetail3>();
                        TachP = new Chartdetail3();
                        TachP.columnheader = string.Empty;
                        TachP.columnvalue = dtconfigure.Rows[0]["winnertext2"].ToString(); //configure winner text %
                        T.chartdetails.Add(TachP);
                        foreach (DataRow _dr in dt.Rows)
                        {
                            TachP = new Chartdetail3();
                            TachP.columnheader = _dr["Reward"].ToString();
                            TachP.columnvalue = _dr["Percentage"].ToString() + "%";
                            T.chartdetails.Add(TachP);
                        }
                        c.table.Add(T);

                        if (dsMenu.Tables[2] != null && dsMenu.Tables[2].Rows.Count > 0)
                        {
                            P.totalvalue = dsMenu.Tables[2].Rows[0]["TotalPoint"].ToString();
                            c.title = dsMenu.Tables[2].Rows[0]["Title"].ToString();
                            c.foottext = dsMenu.Tables[2].Rows[0]["FootText"].ToString();
                            c.disclaimer = dsMenu.Tables[2].Rows[0]["Disclaimer"].ToString();
                            c.breadcrumb = vBreadCrumb;
                            c.titlefootnote = string.Empty;
                        }

                        c.pie.Add(P);


                        objSPPSearchDashbordResponseDTO.chart.Add(c);

                    }
                }
            }
            /*End Pie Chart*/

            dtMeasurement = new DataTable();
            dtMeasurement = objUtility.GenericReplace(dsMenu.Tables[3]);

            foreach (DataRow _drMeasurement in dtMeasurement.Rows)
            {
                c = new Chart();
                c.line = new List<Line>();
                c.bar = new List<Bar>();

                c.title = _drMeasurement["Title"].ToString();
                c.foottext = _drMeasurement["FootText"].ToString();
                c.disclaimer = _drMeasurement["Disclaimer"].ToString();
                c.breadcrumb = vBreadCrumb;
                c.titlefootnote = _drMeasurement["MeasurementName"].ToString();

                dt = new DataTable();
                dt = objUtility.GenericReplace(dsMenu.Tables[0]);
                DataView dv = new DataView(dt);
                dv.RowFilter = "MeasurementID=" + _drMeasurement["MeasurementID"].ToString();
                dv.Sort = "RowID ASC";
                dt = dv.ToTable();

                B = new Bar();
                B.chartdetails = new List<Chartdetail>();

                B1 = new Bar();
                B1.chartdetails = new List<Chartdetail>();

                L = new Line();
                L.chartdetails = new List<Chartdetail2>();

                L1 = new Line();
                L1.chartdetails = new List<Chartdetail2>();

                T = new Table();
                T.chartdetails = new List<Chartdetail3>();


                T1 = new Table();
                T1.chartdetails = new List<Chartdetail3>();



                T2 = new Table();
                T2.chartdetails = new List<Chartdetail3>();



                T3 = new Table();
                T3.chartdetails = new List<Chartdetail3>();

                if (Convert.ToBoolean(_drMeasurement["IsBonusPoint"].ToString()) == false)
                {
                    if (_drMeasurement["MeasurementTypeID"].ToString() == "5" || _drMeasurement["MeasurementTypeID"].ToString() == "19")
                    {
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            B.title = _drMeasurement["TgtText"].ToString();
                            B1.title = _drMeasurement["AchText"].ToString();
                            L.title = _drMeasurement["AchPText"].ToString();
                            L1.title = _drMeasurement["NationalText"].ToString();

                            TachP = new Chartdetail3();
                            TachP.columnheader = string.Empty;
                            TachP.columnvalue = _drMeasurement["AchText"].ToString();
                            T1.chartdetails.Add(TachP);

                            TachP = new Chartdetail3();
                            TachP.columnheader = string.Empty;
                            TachP.columnvalue = _drMeasurement["TgtText"].ToString();
                            T.chartdetails.Add(TachP);

                            TachP = new Chartdetail3();
                            TachP.columnheader = string.Empty;
                            TachP.columnvalue = _drMeasurement["AchPText"].ToString();
                            T2.chartdetails.Add(TachP);

                            TachP = new Chartdetail3();
                            TachP.columnheader = string.Empty;
                            TachP.columnvalue = _drMeasurement["NationalText"].ToString();
                            T3.chartdetails.Add(TachP);

                            foreach (DataRow _dr in dt.Rows)
                            {
                                BachP = new Chartdetail();
                                BachP.columnvalue = string.IsNullOrEmpty(_dr["Tgt"].ToString()) ? "0" : _dr["Tgt"].ToString();
                                BachP.columnheader = _dr["displayMonth"].ToString();
                                B.chartdetails.Add(BachP);


                                BachP = new Chartdetail();
                                BachP.columnvalue = string.IsNullOrEmpty(_dr["Ach"].ToString()) ? "0" : _dr["Ach"].ToString();
                                BachP.columnheader = _dr["displayMonth"].ToString();
                                B1.chartdetails.Add(BachP);



                                LachP = new Chartdetail2();
                                LachP.columnvalue = string.IsNullOrEmpty(_dr["Achp"].ToString()) ? "0" : _dr["Achp"].ToString();
                                LachP.columnheader = _dr["displayMonth"].ToString();
                                L.chartdetails.Add(LachP);
                                L.islinegraph = "1";


                                LachP = new Chartdetail2();
                                LachP.columnvalue = string.IsNullOrEmpty(_dr["NAchp"].ToString()) ? "0" : _dr["NAchp"].ToString();
                                LachP.columnheader = _dr["displayMonth"].ToString();
                                L1.chartdetails.Add(LachP);
                                L1.islinegraph = "1";

                                TachP = new Chartdetail3();
                                TachP.columnheader = _dr["displayMonth"].ToString();
                                TachP.columnvalue = (string.IsNullOrEmpty(_dr["Tgt"].ToString()) ? "0" : String.Format("{0:n}", Convert.ToDouble(_dr["Tgt"].ToString()))) + _drMeasurement["TgtSuffix"].ToString();
                                T.chartdetails.Add(TachP);


                                TachP = new Chartdetail3();
                                TachP.columnheader = _dr["displayMonth"].ToString();
                                TachP.columnvalue = (string.IsNullOrEmpty(_dr["Ach"].ToString()) ? "0" : String.Format("{0:n}", Convert.ToDouble(_dr["Ach"].ToString()))) + _drMeasurement["AchSuffix"].ToString();
                                T1.chartdetails.Add(TachP);


                                TachP = new Chartdetail3();
                                TachP.columnheader = _dr["displayMonth"].ToString();
                                TachP.columnvalue = (string.IsNullOrEmpty(_dr["Achp"].ToString()) ? "0" : _dr["Achp"].ToString()) + _drMeasurement["AchpSuffix"].ToString();
                                T2.chartdetails.Add(TachP);

                                TachP = new Chartdetail3();
                                TachP.columnheader = _dr["displayMonth"].ToString();
                                TachP.columnvalue = (string.IsNullOrEmpty(_dr["NAchp"].ToString()) ? "0" : _dr["NAchp"].ToString()) + _drMeasurement["AchpSuffix"].ToString();
                                T3.chartdetails.Add(TachP);

                            }
                            if (Convert.ToBoolean(dsMenu.Tables[7].Rows[0]["IsTgtVsAchClubbed"].ToString()) == true)
                            {
                                c.bar.Add(B);
                                c.bar.Add(B1);
                                c.line.Add(L);
                                c.line.Add(L1);

                                c.table.Add(T);
                                c.table.Add(T1);
                                c.table.Add(T2);
                                c.table.Add(T3);
                            }
                            else
                            {
                                c.bar.Add(B);
                                c.bar.Add(B1);

                                c.line.Add(L1);

                                c.table.Add(T);
                                c.table.Add(T1);
                                c.table.Add(T2);

                                c1 = new Chart();
                                //c1 = c;
                                c1.bar = new List<Bar>();
                                c1.line = new List<Line>();
                                c1.table = new List<Table>();
                                Bar BAch = new Bar();
                                BAch.chartdetails = new List<Chartdetail>();
                                BAch.title = L.title;
                                foreach (Chartdetail2 _cd in L.chartdetails)
                                {
                                    Chartdetail _c1 = new Chartdetail();
                                    _c1.columnheader = _cd.columnheader;
                                    _c1.columnvalue = _cd.columnvalue;
                                    BAch.chartdetails.Add(_c1);
                                }

                                c1.bar.Add(BAch);
                                c1.line.Add(L1);

                                c1.table.Add(T2);
                                c1.table.Add(T3);
                                c1.title = c.title;
                                c1.breadcrumb = c.breadcrumb;
                                c1.disclaimer = c.disclaimer;
                                c1.foottext = c.foottext;
                                c1.title = c.title;
                                c1.titlefootnote = c.titlefootnote;

                            }
                        }

                    }
                    else if (_drMeasurement["MeasurementTypeID"].ToString() == "6")
                    {
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            B.title = _drMeasurement["AchPText"].ToString();
                            L.title = _drMeasurement["NationalText"].ToString();

                            TachP = new Chartdetail3();
                            TachP.columnheader = string.Empty;
                            TachP.columnvalue = _drMeasurement["AchPText"].ToString();
                            T.chartdetails.Add(TachP);

                            TachP = new Chartdetail3();
                            TachP.columnheader = string.Empty;
                            TachP.columnvalue = _drMeasurement["NationalText"].ToString();
                            T1.chartdetails.Add(TachP);

                            foreach (DataRow _dr in dt.Rows)
                            {
                                BachP = new Chartdetail();
                                BachP.columnvalue = string.IsNullOrEmpty(_dr["Achp"].ToString()) ? "0" : _dr["Achp"].ToString();
                                BachP.columnheader = _dr["displayMonth"].ToString();
                                B.chartdetails.Add(BachP);



                                LachP = new Chartdetail2();
                                LachP.columnvalue = string.IsNullOrEmpty(_dr["NAchp"].ToString()) ? "0" : _dr["NAchp"].ToString();
                                LachP.columnheader = _dr["displayMonth"].ToString();
                                L.chartdetails.Add(LachP);
                                L.islinegraph = "1";


                                TachP = new Chartdetail3();
                                TachP.columnheader = _dr["displayMonth"].ToString();
                                TachP.columnvalue = (string.IsNullOrEmpty(_dr["Achp"].ToString()) ? "0" : _dr["Achp"].ToString()) + _drMeasurement["AchpSuffix"].ToString();
                                T.chartdetails.Add(TachP);


                                TachP = new Chartdetail3();
                                TachP.columnheader = _dr["displayMonth"].ToString();
                                TachP.columnvalue = (string.IsNullOrEmpty(_dr["NAchp"].ToString()) ? "0" : _dr["NAchp"].ToString()) + _drMeasurement["AchpSuffix"].ToString();
                                T1.chartdetails.Add(TachP);
                            }

                            c.bar.Add(B);
                            c.line.Add(L);
                            c.table.Add(T);
                            c.table.Add(T1);

                        }


                    }

                    c.valuetype = ((_drMeasurement["AchpSuffix"].ToString() == "%") ? "P" : string.Empty);
                    objSPPSearchDashbordResponseDTO.chart.Add(c);

                    if ((_drMeasurement["MeasurementTypeID"].ToString() == "5" || _drMeasurement["MeasurementTypeID"].ToString() == "19")
                        && Convert.ToBoolean(dsMenu.Tables[7].Rows[0]["IsTgtVsAchClubbed"].ToString()) == false)
                    {
                        objSPPSearchDashbordResponseDTO.chart.Add(c1);
                    }


                }
                /*For Points*/
                if (vMeasurementID != "0")
                {
                    c = new Chart();
                    c.line = new List<Line>();
                    c.bar = new List<Bar>();

                    c.title = _drMeasurement["PointText"].ToString();
                    c.foottext = string.Empty;
                    c.disclaimer = _drMeasurement["Disclaimer"].ToString();
                    c.breadcrumb = vBreadCrumb;
                    c.titlefootnote = _drMeasurement["MeasurementName"].ToString();

                    dt = new DataTable();
                    dt = objUtility.GenericReplace(dsMenu.Tables[0]);
                    dv = new DataView(dt);
                    dv.RowFilter = "MeasurementID=" + _drMeasurement["MeasurementID"].ToString();
                    dv.Sort = "RowID ASC";
                    dt = dv.ToTable();

                    B = new Bar();
                    B.chartdetails = new List<Chartdetail>();

                    L = new Line();
                    L.chartdetails = new List<Chartdetail2>();

                    T = new Table();
                    T.chartdetails = new List<Chartdetail3>();

                    T1 = new Table();
                    T1.chartdetails = new List<Chartdetail3>();

                    B.title = _drMeasurement["PointText"].ToString();
                    L.title = _drMeasurement["PointNationalText"].ToString();

                    TachP = new Chartdetail3();
                    TachP.columnheader = string.Empty;
                    TachP.columnvalue = _drMeasurement["PointText"].ToString();
                    T.chartdetails.Add(TachP);

                    TachP = new Chartdetail3();
                    TachP.columnheader = string.Empty;
                    TachP.columnvalue = _drMeasurement["PointNationalText"].ToString();
                    T1.chartdetails.Add(TachP);

                    if (dt != null && dt.Rows.Count > 0)
                    {
                        foreach (DataRow _dr in dt.Rows)
                        {
                            BachP = new Chartdetail();
                            BachP.columnvalue = (string.IsNullOrEmpty(_dr["Point"].ToString()) ? "0" : _dr["Point"].ToString()) + _drMeasurement["PointSuffix"].ToString();
                            BachP.columnheader = _dr["displayMonth"].ToString();
                            B.chartdetails.Add(BachP);



                            LachP = new Chartdetail2();
                            LachP.columnvalue = (string.IsNullOrEmpty(_dr["NPoint"].ToString()) ? "0" : _dr["NPoint"].ToString()) + _drMeasurement["PointSuffix"].ToString();
                            LachP.columnheader = _dr["displayMonth"].ToString();
                            L.chartdetails.Add(LachP);
                            L.islinegraph = "1";


                            TachP = new Chartdetail3();
                            TachP.columnheader = _dr["displayMonth"].ToString();
                            TachP.columnvalue = (string.IsNullOrEmpty(_dr["Point"].ToString()) ? "0" : _dr["Point"].ToString()) + _drMeasurement["PointSuffix"].ToString();
                            T.chartdetails.Add(TachP);


                            TachP = new Chartdetail3();
                            TachP.columnheader = _dr["displayMonth"].ToString();
                            TachP.columnvalue = (string.IsNullOrEmpty(_dr["NPoint"].ToString()) ? "0" : _dr["NPoint"].ToString()) + _drMeasurement["PointSuffix"].ToString();
                            T1.chartdetails.Add(TachP);
                        }

                        c.bar.Add(B);
                        c.line.Add(L);
                        c.table.Add(T);
                        c.table.Add(T1);

                        c.title = _drMeasurement["Title"].ToString();
                        c.foottext = _drMeasurement["FootText"].ToString();
                        c.disclaimer = _drMeasurement["Disclaimer"].ToString();
                        c.breadcrumb = vBreadCrumb;
                        c.titlefootnote = _drMeasurement["MeasurementName"].ToString();

                        c.valuetype = ((_drMeasurement["PointSuffix"].ToString() == "%") ? "P" : string.Empty);
                        objSPPSearchDashbordResponseDTO.chart.Add(c);
                    }

                }
                /*End For Points*/

            }
            objSPPSearchDashbord.Add(objSPPSearchDashbordResponseDTO);


        }
        catch (Exception ex)
        {
            dsMenu = null;
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

        return objSPPSearchDashbord;
    }
    public List<SPPSearchDashbordResponseDTO> GetSearchDashbord1(string vProgramID, string vMonth, string vYear, string vPartnerCode, string ParameterID, string ReportID, string Quarter, string LoginUser, string cluster, string region, string state, string partnertypeid)
    {
        DataLayer dtLayer = null;
        DataSet dsMenu = null;
        SPPUtility objUtility = new SPPUtility();
        List<SPPSearchDashbordResponseDTO> objPPSearchDashbord = new List<SPPSearchDashbordResponseDTO>();
        SPPSearchDashbordResponseDTO sPPSearchDashbordResponseDTO = new SPPSearchDashbordResponseDTO();
        sPPSearchDashbordResponseDTO.chart = new List<Chart>();
        Chart c = new Chart();
        try
        {
            dtLayer = new DataLayer();

            /*Report ID 
             0 : Landing Report - Geo
             1 : City Tier Snapshot
             2 : Regional Snapshot
             3 : SPD Wise Snapshot
             4 : Revenue Tier Snapshot
           */
            if (Quarter == "0")
            {
                if (ParameterID == "0" && ReportID == "0")
                {
                    //monthly report
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartnew",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", vPartnerCode),
                                                                                                      new SqlParameter("@cluster", cluster),
                                                                                                       new SqlParameter("@region", region),
                                                                                                        new SqlParameter("@state", state),
                                                                                                       new SqlParameter("@LoginUser", LoginUser));

                    SPPMenuDashbordResponseDTO objSPPMenuDashbordResponseDTO = GetDAGetMenu(vProgramID, LoginUser);
                    //if (objSPPMenuDashbordResponseDTO.usertype[objSPPMenuDashbordResponseDTO.usertype.Count - 1].filterapplicable == "0")
                    //{
                    if (objSPPMenuDashbordResponseDTO.usertype.Count.ToString() == partnertypeid)
                    {
                        // get winner Achivement value basis of range
                        rangebar objrangebar = GetWinnerAchivementbyuser(vProgramID, vMonth, vYear, vPartnerCode, Quarter, cluster, region, state);
                        // objPPSearchDashbord.Add(GenerateGraphrange(dsMenu, objrangebar));
                        objPPSearchDashbord.Add(GenerateGraphrange(dsMenu, objrangebar, vMonth, int.Parse(vYear)));
                    }
                    else
                    {
                        //  objPPSearchDashbord.Add(GenerateGraph(dsMenu));
                        objPPSearchDashbord.Add(GenerateGraph(dsMenu, vMonth, int.Parse(vYear)));
                    }




                }
                else if (ParameterID != "0" && ReportID == "0")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", vPartnerCode),
                                                                                                      new SqlParameter("@cluster", cluster),
                                                                                                       new SqlParameter("@region", region),
                                                                                                        new SqlParameter("@state", state),
                                                                                                         new SqlParameter("@ParameterID", ParameterID),
                                                                                                         new SqlParameter("@LoginUser", LoginUser));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));

                }


                if (ParameterID == "0" && ReportID == "1")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartCityTier",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty));

                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));
                }
                else if (ParameterID != "0" && ReportID == "1")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartCityTierWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                         new SqlParameter("@ParameterID", ParameterID));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));

                }
                else if (ParameterID == "0" && ReportID == "2")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartRegionTier",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty));

                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));
                }
                else if (ParameterID != "0" && ReportID == "2")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartRegionTierWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                         new SqlParameter("@ParameterID", ParameterID));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));

                }
                else if (ParameterID == "0" && ReportID == "4")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartRevenueTier",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty));

                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));
                }
                else if (ParameterID != "0" && ReportID == "4")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartRevenueTierWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                         new SqlParameter("@ParameterID", ParameterID));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));

                }
                else if (ParameterID == "0" && ReportID == "3")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartSPDTier",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty));

                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));
                }
                else if (ParameterID != "0" && ReportID == "3")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartSPDTierWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                         new SqlParameter("@ParameterID", ParameterID));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));

                }
                //objPPSearchDashbord.Add(GenerateGraph1(dsMenu, 1));
                //objPPSearchDashbord.Add(GenerateGraph1(dsMenu, 2));
            }
            else
            {

                if (ParameterID == "0" && ReportID == "0")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarter",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", vPartnerCode),
                                                                                                      new SqlParameter("@cluster", cluster),
                                                                                                       new SqlParameter("@region", region),
                                                                                                        new SqlParameter("@state", state),
                                                                                                         new SqlParameter("@Quarter", @Quarter),
                                                                                                          new SqlParameter("@LoginUser", LoginUser));



                    SPPMenuDashbordResponseDTO objSPPMenuDashbordResponseDTO = GetDAGetMenu(vProgramID, LoginUser);
                    //if (objSPPMenuDashbordResponseDTO.usertype[1].filterapplicable == "0")
                    //{
                    if (objSPPMenuDashbordResponseDTO.usertype.Count.ToString() == partnertypeid)
                    {
                        // get winner Achivement value basis of range
                        rangebar objrangebar = GetWinnerAchivementbyuser(vProgramID, vMonth, vYear, vPartnerCode, Quarter, cluster, region, state);
                        // objPPSearchDashbord.Add(GenerateGraphrange(dsMenu, objrangebar));
                        objPPSearchDashbord.Add(GenerateGraphrange(dsMenu, objrangebar, Quarter, int.Parse(vYear)));
                    }
                    else
                    {
                        //objPPSearchDashbord.Add(GenerateGraph(dsMenu));
                        objPPSearchDashbord.Add(GenerateGraph(dsMenu, Quarter, int.Parse(vYear)));
                    }


                }
                else if (ParameterID != "0" && ReportID == "0")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarterWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", vPartnerCode),
                                                                                                      new SqlParameter("@cluster", cluster),
                                                                                                       new SqlParameter("@region", region),
                                                                                                        new SqlParameter("@state", state),
                                                                                                         new SqlParameter("@ParameterID", ParameterID),
                                                                                                          new SqlParameter("@Quarter", @Quarter),
                                                                                                          new SqlParameter("@LoginUser", LoginUser));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));

                }


                if (ParameterID == "0" && ReportID == "1")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarterCityTier",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                         new SqlParameter("@Quarter", Quarter));

                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));
                }
                else if (ParameterID != "0" && ReportID == "1")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarterCityTierWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                         new SqlParameter("@ParameterID", ParameterID),
                                                                                                         new SqlParameter("@Quarter", Quarter));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));

                }
                else if (ParameterID == "0" && ReportID == "2")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarterRegionTier",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                        new SqlParameter("@Quarter", Quarter));

                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));
                }
                else if (ParameterID != "0" && ReportID == "2")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarterRegionTierWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                         new SqlParameter("@ParameterID", ParameterID),
                                                                                                         new SqlParameter("@Quarter", Quarter));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));

                }
                else if (ParameterID == "0" && ReportID == "4")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarterRevenueTier",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                        new SqlParameter("@Quarter", Quarter));

                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));
                }
                else if (ParameterID != "0" && ReportID == "4")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarterRevenueTierWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                         new SqlParameter("@ParameterID", ParameterID),
                                                                                                         new SqlParameter("@Quarter", Quarter));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));

                }
                else if (ParameterID == "0" && ReportID == "3")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarterSPDTier",
                                                                                                          new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                        new SqlParameter("@Quarter", Quarter));

                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));
                }
                else if (ParameterID != "0" && ReportID == "3")
                {
                    dsMenu = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_SearchDashbordChartQuarterSPDTierWithParameter",
                                                                                                      new SqlParameter("@ProgramID", vProgramID),
                                                                                                      new SqlParameter("@Month", vMonth),
                                                                                                     new SqlParameter("@Year", vYear),
                                                                                                      new SqlParameter("@PartnerCode", string.Empty),
                                                                                                      new SqlParameter("@cluster", string.Empty),
                                                                                                       new SqlParameter("@region", string.Empty),
                                                                                                        new SqlParameter("@state", string.Empty),
                                                                                                         new SqlParameter("@ParameterID", ParameterID),
                                                                                                         new SqlParameter("@Quarter", Quarter));


                    objPPSearchDashbord.Add(GenerateGraphWithParameter(dsMenu));


                }

            }
        }
        catch (Exception ex)
        {
            dsMenu = null;
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        //Blank line chart for all dashbord report
        if (vPartnerCode == "0" && cluster == "0" && region == "0" && state == "0")
        {
            Line line = new Line();
            for (int i = 0; i < objPPSearchDashbord[0].chart.Count; i++)
            {
                if (objPPSearchDashbord[0].chart[i].line.Count > 0)
                {
                    if (objPPSearchDashbord[0].chart[i].line[0].islinegraph != "1")
                        objPPSearchDashbord[0].chart[i].line = new List<Line>();
                }

            }

        }
        return objPPSearchDashbord;
    }

    //private static SPPSearchDashbordResponseDTO GenerateGraph(DataSet dsMenu)
    private static SPPSearchDashbordResponseDTO GenerateGraph(DataSet dsMenu, string MonthQtr = "", int Year = 0)
    {
        SPPBusinessLayer sppobj = new SPPBusinessLayer();
        SPPUtility objUtility = new SPPUtility();


        bool chartbar = false;
        bool chartline = false;
        bool charttable = false;
        bool charttable1 = false;
        bool chartpie = false;
        Chartdetail chartdetail = null;
        Chartdetail2 chartdetail2 = null;
        Chartdetail3 chartdetail3 = null;
        Chartdetailpie chartdetailpie = null;

        Pie pie = new Pie();
        pie.chartdetails = new List<Chartdetailpie>();


        Bar bar = new Bar();
        bar.chartdetails = new List<Chartdetail>();

        Line line = new Line();
        line.chartdetails = new List<Chartdetail2>();

        Table table = new Table();
        table.chartdetails = new List<Chartdetail3>();

        Table table1 = new Table();
        table1.chartdetails = new List<Chartdetail3>();

        Chart chart = new Chart();

        chart.pie = new List<Pie>();

        chart.bar = new List<Bar>();
        chart.line = new List<Line>();
        chart.table = new List<Table>();

        SPPSearchDashbordResponseDTO sPPSearchDashbordResponseDTO = new SPPSearchDashbordResponseDTO();
        sPPSearchDashbordResponseDTO.chart = new List<Chart>();
        DataTable dtWinner = objUtility.GenericReplace(dsMenu.Tables[0]);
        int winnertotalval = 0;
        string vTitleText = string.Empty;
        try
        {
            /*Modified by Shyam Sunder Kumar as on 08-Jun-2019 to add Prevalidation text*/
            if (Year != 0)
            {
                string vMonth = string.Empty;
                if (!(MonthQtr.ToUpper() == "Q1" || MonthQtr.ToUpper() == "Q2" || MonthQtr.ToUpper() == "Q3" || MonthQtr.ToUpper() == "Q4"))
                {
                    vMonth = System.Globalization.CultureInfo.CurrentUICulture.DateTimeFormat.GetAbbreviatedMonthName(int.Parse(MonthQtr));

                }
                else
                {

                    if (MonthQtr.ToUpper() == "Q1")
                    {
                        vMonth = "Jan - Mar";
                    }
                    else if (MonthQtr.ToUpper() == "Q2")
                    {
                        vMonth = "Apr - Jun";
                    }
                    else if (MonthQtr.ToUpper() == "Q3")
                    {
                        vMonth = "Jul - Sep";
                    }
                    else
                    {
                        vMonth = "Oct - Dec";
                    }


                }

                vTitleText = " [ " + vMonth + " " + Year.ToString() + " " + sppobj.GetDashbordConfiguration().Where(x => x.id == 7).ToList()[0].value + " ]";
            }
            /*End Changes*/
            if (dsMenu.Tables[0].Rows.Count > 0)
            {
                for (int i = 1; i <= dtWinner.Rows.Count; i++)
                {
                    bool one = true;
                    bool two = true;
                    for (int j = 0; j < dtWinner.Rows.Count; j++)
                    {
                        //----------------------------------------Bar chart--------------------------------------------------
                        if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && dtWinner.Rows[j]["type"].ToString() == "P")
                        {
                            if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && one)
                            {
                                pie.color = SPPUtility.HexConverterColor();

                                one = false;
                                chart.title = sppobj.GetDashbordConfiguration().Where(x => x.id == 4).ToList()[0].value;// "Winner %";
                                chart.title = chart.title + vTitleText + " | " + chart.title + vTitleText; //To Add Prevalidation text
                                chart.disclaimer = "On the Insert tab, the galleries include items that are designed to coordinate with the overall look of your document. You can use these galleries to insert tables, headers, footers, lists, cover pages, and other document building blocks. When you create pictures, charts, or diagrams, they also coordinate with your current document look.";
                            }
                            if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && dtWinner.Rows[j]["columnheader"].ToString() == "SRD")
                            {
                                chart.title = dtWinner.Rows[j]["columnvalue"].ToString() + " | " + dtWinner.Rows[j]["columnvalue"].ToString();
                            }
                            chartdetailpie = new Chartdetailpie();
                            chartdetailpie.columnheader = dtWinner.Rows[j]["columnheader"].ToString();
                            chartdetailpie.columnvalue = dtWinner.Rows[j]["columnvalue"].ToString();

                            pie.chartdetails.Add(chartdetailpie);
                            chartpie = true;
                        }
                        //------------------------------------------Bar chart end-----------------------------------------------------------
                        //-----------------------------------------Line chart------------------------------------------------------------------------
                        //if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && dtWinner.Rows[j]["type"].ToString() == "L")
                        //{
                        //    if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && one)
                        //    {
                        //        line.color = SPPUtility.HexConverterColor();
                        //        one = false;
                        //    }
                        //    if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && dtWinner.Rows[j]["columnheader"].ToString() == "SRD")
                        //    {
                        //        chart.title = dtWinner.Rows[j]["columnvalue"].ToString();
                        //    }
                        //    chartdetail2 = new Chartdetail2();
                        //    chartdetail2.columnheader = dtWinner.Rows[j]["columnheader"].ToString();
                        //    chartdetail2.columnvalue = dtWinner.Rows[j]["columnvalue"].ToString();
                        //    line.chartdetails.Add(chartdetail2);
                        //    chartline = true;
                        //}
                        //------------------------------------------Line Chart end-----------------------------------------------------------------------

                        //-----------------------------------------Table chart------------------------------------------------------------------------
                        if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && dtWinner.Rows[j]["type"].ToString() == "N")
                        {
                            if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && one)
                            {
                                table.color = SPPUtility.HexConverterColor();
                                one = false;
                                chartdetail3 = new Chartdetail3();
                                chartdetail3.columnheader = "";
                                chartdetail3.columnvalue = sppobj.GetDashbordConfiguration().Where(x => x.id == 5).ToList()[0].value;// "Winners";
                                table.chartdetails.Add(chartdetail3);

                            }
                            if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && dtWinner.Rows[j]["columnheader"].ToString() == "SRD")
                            {
                                chart.title = dtWinner.Rows[j]["columnvalue"].ToString() + " | " + dtWinner.Rows[j]["columnvalue"].ToString();

                            }
                            chartdetail3 = new Chartdetail3();
                            chartdetail3.columnheader = dtWinner.Rows[j]["columnheader"].ToString();
                            chartdetail3.columnvalue = dtWinner.Rows[j]["columnvalue"].ToString();
                            winnertotalval = winnertotalval + Convert.ToInt32(Convert.ToDecimal(dtWinner.Rows[j]["columnvalue"].ToString()));
                            pie.totalvalue = winnertotalval.ToString();
                            table.chartdetails.Add(chartdetail3);

                            charttable = true;
                        }
                        if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && dtWinner.Rows[j]["type"].ToString() == "P")
                        {
                            if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && two)
                            {
                                table.color = SPPUtility.HexConverterColor();
                                two = false;
                                chartdetail3 = new Chartdetail3();
                                chartdetail3.columnheader = "";
                                //chartdetail3.columnvalue = sppobj.GetDashbordConfiguration().Where(x => x.id == 4).ToList()[0].value;// "Winners%";
                                /*changes made by shyam sunder kumar as on 17-05-2019 to change winner % to %*/
                                chartdetail3.columnvalue = sppobj.GetDashbordConfiguration().Where(x => x.id == 6).ToList()[0].value;// "Winners%";
                                                                                                                                     /*End changes*/
                                table1.chartdetails.Add(chartdetail3);

                            }
                            if (Convert.ToInt32(dtWinner.Rows[j]["id"]) == i && dtWinner.Rows[j]["columnheader"].ToString() == "SRD")
                            {
                                chart.title = dtWinner.Rows[j]["columnvalue"].ToString();
                            }
                            chartdetail3 = new Chartdetail3();
                            chartdetail3.columnheader = dtWinner.Rows[j]["columnheader"].ToString();
                            chartdetail3.columnvalue = dtWinner.Rows[j]["columnvalue"].ToString() + "%";
                            table1.chartdetails.Add(chartdetail3);

                            charttable1 = true;
                        }

                        //------------------------------------------Line Chart end-----------------------------------------------------------------------


                    }
                    if (chartbar)
                    {
                        chart.bar.Add(bar);
                        chartbar = false;
                    }
                    if (chartline)
                    {
                        chart.line.Add(line);
                        chartline = false;
                    }
                    if (charttable)
                    {
                        chart.table.Add(table);
                        charttable = false;
                    }
                    if (charttable1)
                    {
                        chart.table.Add(table1);
                        charttable1 = false;
                    }
                    if (chartpie)
                    {
                        chart.pie.Add(pie);
                        chartpie = false;
                    }
                }

                sPPSearchDashbordResponseDTO.chart.Add(chart);
            }

            if (dsMenu.Tables[1].Rows.Count > 0)
            {
                DataTable dttarget = dsMenu.Tables[1];
                var targetRows = (from DataRow dRow in dttarget.Rows
                                  select dRow["RefLevel3ID"]).Distinct();
                foreach (var col in targetRows)
                {
                    int levelid = Convert.ToInt32(col);

                    sPPSearchDashbordResponseDTO.chart.Add(GenerateGraph1(dsMenu, 1, false, levelid));
                }


            }
            // sPPSearchDashbordResponseDTO.chart.Add(GenerateGraph1(dsMenu, 2));
            if (dsMenu.Tables[2].Rows.Count > 0)
            {
                DataTable dtNormal = dsMenu.Tables[2];
                var distinctRows = (from DataRow dRow in dtNormal.Rows
                                    select dRow["RefLevel3ID"]).Distinct();
                foreach (var col in distinctRows)
                {
                    int levelid = Convert.ToInt32(col);
                    sPPSearchDashbordResponseDTO.chart.Add(GenerateNormalGraph(dsMenu, levelid, false, false));
                }
            }

            // }



            //---------------------------------------------------End Target vs Achivement------------------------------------------------------------------------
        }
        catch (Exception ex)
        {
            throw ex;
        }



        return sPPSearchDashbordResponseDTO;
    }

    public rangebar GetWinnerAchivementbyuser(string vProgramID, string vMonth, string vYear, string vPartnerCode, string Quarter, string cluster, string region, string state)
    {
        DataLayer dtLayer = null;
        dtLayer = new DataLayer();

        DataSet dswin = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_WinnerAchivementbyuser",
                                                                                                             new SqlParameter("@ProgramID", vProgramID),
                                                                                                         new SqlParameter("@Cluster", cluster),
                                                                                                        new SqlParameter("@SubRegion", region),
                                                                                                         new SqlParameter("@State", state),
                                                                                                         new SqlParameter("@month", vMonth),
                                                                                                          new SqlParameter("@year", vYear),
                                                                                                    new SqlParameter("@PartnerCode", vPartnerCode),

                                                                                                    new SqlParameter("@Quarter", Quarter));

        rangebar orangebar = new rangebar();
        if (dswin != null && dswin.Tables[0].Rows.Count > 0)
        {

            orangebar.barname = dswin.Tables[0].Rows[0]["Rewards"].ToString();
            orangebar.barvalue = dswin.Tables[0].Rows[0]["TotalPoint"].ToString();
            rangevalue orangevalue = null;
            orangebar.rangevaluelist = new List<rangevalue>();
            for (int i = 0; i < dswin.Tables[1].Rows.Count; i++)
            {
                orangevalue = new rangevalue();
                orangevalue.rangename = dswin.Tables[1].Rows[i]["RangeName"].ToString();
                orangevalue.range = dswin.Tables[1].Rows[i]["RangeValue"].ToString();
                orangevalue.color = dswin.Tables[1].Rows[i]["color"].ToString();
                orangebar.rangevaluelist.Add(orangevalue);

            }
        }
        return orangebar;


        //orangebar.rangevaluelist = new List<rangevalue>();
        //rangevalue orangevalue = null;
        //orangevalue = new rangevalue();
        //orangevalue.rangename = "Gold";
        //orangevalue.range = 1000;
        //orangevalue.color = SPPUtility.HexConverterColor();
        //orangebar.rangevaluelist.Add(orangevalue);
        //orangevalue = new rangevalue();
        //orangevalue.rangename = "Silver";
        //orangevalue.range = 600;
        //orangevalue.color = SPPUtility.HexConverterColor();
        //orangebar.rangevaluelist.Add(orangevalue);
        //orangevalue = new rangevalue();
        //orangevalue.rangename = "platinum";
        //orangevalue.range = 400;
        //orangevalue.color = SPPUtility.HexConverterColor();
        //orangebar.rangevaluelist.Add(orangevalue);

    }


    // private static SPPSearchDashbordResponseDTO GenerateGraphrange(DataSet dsMenu, rangebar orangebar)
    private static SPPSearchDashbordResponseDTO GenerateGraphrange(DataSet dsMenu, rangebar orangebar, string MonthQtr = "", int Year = 0)
    {
        SPPBusinessLayer sppobj = new SPPBusinessLayer();
        SPPUtility objUtility = new SPPUtility();


        bool chartbar = false;
        bool chartline = false;
        bool charttable = false;
        bool charttable1 = false;
        bool chartpie = false;
        Chartdetail chartdetail = null;
        Chartdetail2 chartdetail2 = null;
        Chartdetail3 chartdetail3 = null;
        Chartdetailpie chartdetailpie = null;

        Pie pie = new Pie();
        pie.chartdetails = new List<Chartdetailpie>();


        Bar bar = new Bar();
        bar.chartdetails = new List<Chartdetail>();

        Line line = new Line();
        line.chartdetails = new List<Chartdetail2>();

        Table table = new Table();
        table.chartdetails = new List<Chartdetail3>();

        Table table1 = new Table();
        table1.chartdetails = new List<Chartdetail3>();

        Chart chart = new Chart();

        chart.pie = new List<Pie>();

        chart.bar = new List<Bar>();
        chart.line = new List<Line>();
        chart.table = new List<Table>();

        SPPSearchDashbordResponseDTO sPPSearchDashbordResponseDTO = new SPPSearchDashbordResponseDTO();
        sPPSearchDashbordResponseDTO.chart = new List<Chart>();
        DataTable dtWinner = objUtility.GenericReplace(dsMenu.Tables[0]);
        int winnertotalval = 0;

        string vTitleText = string.Empty;

        try
        {
            /*Modified by Shyam Sunder Kumar as on 08-Jun-2019 to add Prevalidation text*/
            if (Year != 0)
            {
                string vMonth = string.Empty;
                if (!(MonthQtr.ToUpper() == "Q1" || MonthQtr.ToUpper() == "Q2" || MonthQtr.ToUpper() == "Q3" || MonthQtr.ToUpper() == "Q4"))
                {
                    vMonth = System.Globalization.CultureInfo.CurrentUICulture.DateTimeFormat.GetAbbreviatedMonthName(int.Parse(MonthQtr));

                }
                else
                {

                    if (MonthQtr.ToUpper() == "Q1")
                    {
                        vMonth = "Jan - Mar";
                    }
                    else if (MonthQtr.ToUpper() == "Q2")
                    {
                        vMonth = "Apr - Jun";
                    }
                    else if (MonthQtr.ToUpper() == "Q3")
                    {
                        vMonth = "Jul - Sep";
                    }
                    else
                    {
                        vMonth = "Oct - Dec";
                    }


                }

                vTitleText = " [ " + vMonth + " " + Year.ToString() + " " + sppobj.GetDashbordConfiguration().Where(x => x.id == 7).ToList()[0].value + " ]";
            }
            if (dsMenu.Tables[0].Rows.Count > 0)
            {




                chart.title = sppobj.GetDashbordConfiguration().Where(x => x.id == 3).ToList()[0].value;// "Winner Gate";

                chart.title = chart.title + vTitleText + " | " + chart.title + vTitleText + " | " + chart.title + vTitleText + " | " + chart.title + vTitleText;

                chartdetail = new Chartdetail();
                chartdetail.columnheader = orangebar.barname;
                chartdetail.columnvalue = orangebar.barvalue.ToString();
                bar.rangevaluelist = new List<rangevalue>();
                bar.rangevaluelist = orangebar.rangevaluelist;
                bar.chartdetails.Add(chartdetail);
                chartbar = true;



                //-----------------------------------------Table chart------------------------------------------------------------------------
                chartdetail3 = new Chartdetail3();
                chartdetail3.columnheader = "";
                chartdetail3.columnvalue = "Value";
                table.chartdetails.Add(chartdetail3);

                chartdetail3 = new Chartdetail3();
                chartdetail3.columnheader = orangebar.barname;
                chartdetail3.columnvalue = orangebar.barvalue;
                table.chartdetails.Add(chartdetail3);

                for (int i = 0; i < orangebar.rangevaluelist.Count; i++)
                {
                    chartdetail3 = new Chartdetail3();
                    chartdetail3.columnheader = orangebar.rangevaluelist[i].rangename;
                    chartdetail3.columnvalue = orangebar.rangevaluelist[i].range;
                    table.chartdetails.Add(chartdetail3);


                    charttable = true;
                }


                //------------------------------------------Line Chart end-----------------------------------------------------------------------


            }
            if (chartbar)
            {
                chart.bar.Add(bar);
                chartbar = false;
            }
            if (chartline)
            {
                chart.line.Add(line);
                chartline = false;
            }
            if (charttable)
            {
                chart.table.Add(table);
                charttable = false;
            }
            if (charttable1)
            {
                chart.table.Add(table1);
                charttable1 = false;
            }
            if (chartpie)
            {
                chart.pie.Add(pie);
                chartpie = false;
            }


            sPPSearchDashbordResponseDTO.chart.Add(chart);


            if (dsMenu.Tables[1].Rows.Count > 0)
            {
                DataTable dttarget = dsMenu.Tables[1];
                var targetRows = (from DataRow dRow in dttarget.Rows
                                  select dRow["RefLevel3ID"]).Distinct();
                foreach (var col in targetRows)
                {
                    int levelid = Convert.ToInt32(col);

                    sPPSearchDashbordResponseDTO.chart.Add(GenerateGraph1(dsMenu, 1, false, levelid));
                }


            }
            // sPPSearchDashbordResponseDTO.chart.Add(GenerateGraph1(dsMenu, 2));
            if (dsMenu.Tables[2].Rows.Count > 0)
            {
                DataTable dtNormal = dsMenu.Tables[2];
                var distinctRows = (from DataRow dRow in dtNormal.Rows
                                    select dRow["RefLevel3ID"]).Distinct();
                foreach (var col in distinctRows)
                {
                    int levelid = Convert.ToInt32(col);
                    sPPSearchDashbordResponseDTO.chart.Add(GenerateNormalGraph(dsMenu, levelid, false, false));
                }
            }

            // }



            //---------------------------------------------------End Target vs Achivement------------------------------------------------------------------------
        }
        catch (Exception ex)
        {
            throw ex;
        }



        return sPPSearchDashbordResponseDTO;
    }


    private static Chart GenerateGraph1(DataSet dsMenu, int vTargetorAccivement, bool isParam, int LavelID)
    {
        SPPBusinessLayer sppobj = new SPPBusinessLayer();
        SPPUtility objUtility = new SPPUtility();
        bool chartbar = false;
        bool chartbar1 = false;
        bool chartline = false;
        bool charttable = false;
        bool charttable1 = false;
        Chartdetail chartdetail = null;
        Chartdetail2 chartdetail2 = null;
        Chartdetail3 chartdetail3 = null;
        Bar bar = new Bar();
        bar.chartdetails = new List<Chartdetail>();

        Bar bar1 = new Bar();
        bar1.chartdetails = new List<Chartdetail>();

        Line line = new Line();
        line.chartdetails = new List<Chartdetail2>();

        Table table = new Table();
        table.chartdetails = new List<Chartdetail3>();

        Table table1 = new Table();
        table1.chartdetails = new List<Chartdetail3>();

        Table table2 = new Table();
        table2.chartdetails = new List<Chartdetail3>();

        Chart chart = new Chart();
        chart.bar = new List<Bar>();
        chart.line = new List<Line>();
        chart.table = new List<Table>();

        SPPSearchDashbordResponseDTO sPPSearchDashbordResponseDTO = new SPPSearchDashbordResponseDTO();
        sPPSearchDashbordResponseDTO.chart = new List<Chart>();
        DataTable dtWinner = objUtility.GenericReplace(dsMenu.Tables[0]);

        try
        {



            //----------------------------------------------------Target vs Achivement-----------------------------------------------------------
            DataTable dtTarget = isParam == true ? objUtility.GenericReplace(dsMenu.Tables[0]) : objUtility.GenericReplace(dsMenu.Tables[1]);



            sPPSearchDashbordResponseDTO.chart = new List<Chart>();
            //chart = new Chart();
            //chart.bar = new List<Bar>();
            List<Bar> listbar = null;
            System.Collections.Hashtable objcheckbar = new System.Collections.Hashtable();
            System.Collections.Hashtable objcheckbar1 = new System.Collections.Hashtable();
            System.Collections.Hashtable objchecktable = new System.Collections.Hashtable();
            System.Collections.Hashtable objchecktable1 = new System.Collections.Hashtable();
            //for (int i = 1; i <= dtTarget.Rows.Count; i++)
            //{

            // int DataTypeID = Convert.ToInt32(dtTarget.Rows[i]["DataTypeID"]);


            for (int j = 0; j < dtTarget.Rows.Count; j++)
            {

                //if (i == 1)
                //{
                if (LavelID == Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) && vTargetorAccivement == Convert.ToInt32(dtTarget.Rows[j]["DataTypeID"]))
                {
                    int key = Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) + Convert.ToInt32(dtTarget.Rows[j]["DataTypeID"]);
                    if (!objcheckbar.Contains(key))
                    {
                        objcheckbar.Add(key, key);

                        bar = new Bar();
                        bar.color = SPPUtility.HexConverterColor();
                        bar.chartdetails = new List<Chartdetail>();
                        bar.title = dtTarget.Rows[j]["RelevantData"].ToString();

                    }


                    chartdetail = new Chartdetail();
                    chartdetail.columnheader = dtTarget.Rows[j]["monthname"].ToString();

                    chartdetail.columnvalue = dtTarget.Rows[j]["value"].ToString();
                    bar.chartdetails.Add(chartdetail);
                    chartbar = true;

                }

                if (LavelID == Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) && 2 == Convert.ToInt32(dtTarget.Rows[j]["DataTypeID"]))
                {
                    int key = Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) + Convert.ToInt32(dtTarget.Rows[j]["DataTypeID"]);
                    if (!objcheckbar1.Contains(key))
                    {
                        objcheckbar1.Add(key, key);

                        bar1 = new Bar();
                        bar1.color = SPPUtility.HexConverterColor();
                        bar1.chartdetails = new List<Chartdetail>();
                        bar1.title = dtTarget.Rows[j]["RelevantData"].ToString();

                    }


                    chartdetail = new Chartdetail();
                    chartdetail.columnheader = dtTarget.Rows[j]["monthname"].ToString();

                    chartdetail.columnvalue = dtTarget.Rows[j]["value"].ToString();
                    bar1.chartdetails.Add(chartdetail);
                    chartbar1 = true;

                }

                //----------------------------------------------Table---------------------------------------------------

                if (LavelID == Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) && vTargetorAccivement == Convert.ToInt32(dtTarget.Rows[j]["DataTypeID"]))
                {
                    int key = Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) + Convert.ToInt32(dtTarget.Rows[j]["DataTypeID"]);
                    if (!objchecktable.Contains(key))
                    {
                        objchecktable.Add(key, key);

                        table = new Table();
                        table.color = SPPUtility.HexConverterColor();
                        table.chartdetails = new List<Chartdetail3>();
                        //commented by anish
                        //chart.title = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(),0) + " " + dtTarget.Rows[j]["Year"].ToString();
                        chart.title = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 0)[1].Replace("–", " ");
                        chart.titlefootnote = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 0)[0];
                        chart.valuetype = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 3)[0];
                        chart.foottext = sppobj.GetDashbordConfiguration().Where(x => x.id == 1).ToList()[0].value;
                        chartdetail3 = new Chartdetail3();
                        chartdetail3.columnheader = "";
                        chartdetail3.columnvalue = dtTarget.Rows[j]["RelevantData"].ToString();
                        table.chartdetails.Add(chartdetail3);

                    }


                    chartdetail3 = new Chartdetail3();
                    chartdetail3.columnheader = dtTarget.Rows[j]["monthname"].ToString();

                    // chartdetail3.columnvalue = String.Format(new System.Globalization.CultureInfo("en-IN", false), "{0:n}", Convert.ToDouble(dtTarget.Rows[j]["value"].ToString()));
                    chartdetail3.columnvalue = String.Format("{0:n}", Convert.ToDouble(dtTarget.Rows[j]["value"].ToString()));
                    table.chartdetails.Add(chartdetail3);

                    charttable = true;

                }

                if (LavelID == Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) && 2 == Convert.ToInt32(dtTarget.Rows[j]["DataTypeID"]))
                {
                    int key = Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) + Convert.ToInt32(dtTarget.Rows[j]["DataTypeID"]);
                    if (!objchecktable1.Contains(key))
                    {
                        objchecktable1.Add(key, key);

                        table1 = new Table();
                        table1.color = SPPUtility.HexConverterColor();
                        table1.chartdetails = new List<Chartdetail3>();
                        //commented by anish
                        //chart.title = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(),0) + " " + dtTarget.Rows[j]["Year"].ToString();
                        chart.title = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 0)[1].Replace("–", " ");
                        chart.titlefootnote = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 0)[0];
                        chart.valuetype = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 3)[0];
                        chart.foottext = sppobj.GetDashbordConfiguration().Where(x => x.id == 1).ToList()[0].value;
                        chartdetail3 = new Chartdetail3();
                        chartdetail3.columnheader = "";

                        chartdetail3.columnvalue = dtTarget.Rows[j]["RelevantData"].ToString();
                        table1.chartdetails.Add(chartdetail3);

                    }


                    chartdetail3 = new Chartdetail3();
                    chartdetail3.columnheader = dtTarget.Rows[j]["monthname"].ToString();

                    //chartdetail3.columnvalue = String.Format(new System.Globalization.CultureInfo("en-IN", false), "{0:n}", Convert.ToDouble(dtTarget.Rows[j]["value"].ToString())) + sppobj.returnChartValueType(sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 3)[0]);
                    chartdetail3.columnvalue = String.Format("{0:n}", Convert.ToDouble(dtTarget.Rows[j]["value"].ToString())) + sppobj.returnChartValueType(sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 3)[0]);
                    table1.chartdetails.Add(chartdetail3);
                    charttable1 = true;

                }


            }



            chart.bar.Add(bar);
            chart.bar.Add(bar1);

            line = new Line();
            line.color = SPPUtility.HexConverterColor();
            line.chartdetails = new List<Chartdetail2>();
            line.title = sppobj.GetDashbordConfiguration().Where(x => x.id == 2).ToList()[0].value;
            line.islinegraph = "1";

            //-----------------------Table---------------------------------

            table2 = new Table();
            table2.chartdetails = new List<Chartdetail3>();
            chartdetail3 = new Chartdetail3();
            chartdetail3.columnheader = "";
            chartdetail3.columnvalue = sppobj.GetDashbordConfiguration().Where(x => x.id == 2).ToList()[0].value;
            table2.chartdetails.Add(chartdetail3);


            //------------------------End-----------------------------------
            for (int i = 0; i < bar.chartdetails.Count; i++)
            {

                chartdetail2 = new Chartdetail2();
                chartdetail2.columnheader = string.Empty;
                double avg = (Convert.ToDouble(bar1.chartdetails[i].columnvalue) / Convert.ToDouble(bar.chartdetails[i].columnvalue)) * 100;
                if (Double.IsNaN(avg) || Double.IsInfinity(avg))
                    avg = 0;
                chartdetail2.columnvalue = System.Math.Round(avg, 2).ToString();
                line.chartdetails.Add(chartdetail2);

                chartdetail3 = new Chartdetail3();
                chartdetail3.columnheader = bar1.chartdetails[i].columnheader;
                if (Double.IsNaN(avg) || Double.IsInfinity(avg))
                    avg = 0;
                chartdetail3.columnvalue = System.Math.Round(avg, 2).ToString() + "%";
                table2.chartdetails.Add(chartdetail3);

            }
            chart.line.Add(line);

            //Add duplicate Line

            if (line.chartdetails.Count > 0)
            {
                Line L1 = new Line();
                L1.color = line.color;
                L1.islinegraph = line.islinegraph;

                L1.title = "Temprory";

                List<Chartdetail2> c = new List<Chartdetail2>();
                Chartdetail2 c1 = new Chartdetail2();
                c1.columnvalue = (Convert.ToDouble(line.chartdetails[0].columnvalue) / 2).ToString();
                c1.columnheader = line.chartdetails[0].columnheader;

                c.Add(c1);
                L1.chartdetails = c;
                chart.line.Add(L1);
            }
            //End

            chart.table.Add(table);
            chart.table.Add(table1);
            chart.table.Add(table2);
            chart.table.Add(table2);

            // }
            //  sPPSearchDashbordResponseDTO.Chart.Add(chart);


            //---------------------------------------------------End Target vs Achivement------------------------------------------------------------------------
        }
        catch (Exception ex)
        {
            throw ex;
        }



        return chart;
    }
    string returnChartValueType(string val)
    {
        return val.ToLower() == "p" ? "%" : "";

    }
    private static Chart GenerateNormalGraph(DataSet dsMenu, int LavelID, bool isParam, bool ispointchart)
    {
        SPPBusinessLayer sppobj = new SPPBusinessLayer();
        SPPUtility objUtility = new SPPUtility();
        bool chartbar = false;
        bool chartline = false;
        bool charttable = false;
        bool charttable1 = false;
        Chartdetail chartdetail = null;
        Chartdetail2 chartdetail2 = null;
        Chartdetail3 chartdetail3 = null;
        Bar bar = new Bar();
        bar.chartdetails = new List<Chartdetail>();

        Line line = new Line();
        line.chartdetails = new List<Chartdetail2>();

        Table table = new Table();
        table.chartdetails = new List<Chartdetail3>();

        Table table1 = new Table();
        table1.chartdetails = new List<Chartdetail3>();

        Chart chart = new Chart();
        chart.bar = new List<Bar>();
        chart.line = new List<Line>();
        chart.table = new List<Table>();

        SPPSearchDashbordResponseDTO sPPSearchDashbordResponseDTO = new SPPSearchDashbordResponseDTO();
        sPPSearchDashbordResponseDTO.chart = new List<Chart>();
        DataTable dtWinner = objUtility.GenericReplace(dsMenu.Tables[0]);
        ;
        try
        {


            DataTable dtTarget = null;
            //----------------------------------------------------Target vs Achivement-----------------------------------------------------------
            //if (ispointchart)
            //{
            //    dtTarget = dsMenu.Tables[3];
            //}
            //else
            //{

            //     dtTarget = isParam == true ? dsMenu.Tables[1] : dsMenu.Tables[2];
            //}

            if (ispointchart)
            {
                dtTarget = objUtility.GenericReplace(dsMenu.Tables[2]);
            }
            else
            {

                dtTarget = isParam == true ? objUtility.GenericReplace(dsMenu.Tables[1]) : objUtility.GenericReplace(dsMenu.Tables[2]);
            }



            sPPSearchDashbordResponseDTO.chart = new List<Chart>();
            //chart = new Chart();
            //chart.bar = new List<Bar>();
            //chart.line = new List<Line>();
            List<Bar> listbar = null;
            System.Collections.Hashtable objcheckbar = new System.Collections.Hashtable();
            System.Collections.Hashtable objcheckline = new System.Collections.Hashtable();
            System.Collections.Hashtable objchecktable = new System.Collections.Hashtable();
            //for (int i = 1; i <= dtTarget.Rows.Count; i++)
            //{

            // int DataTypeID = Convert.ToInt32(dtTarget.Rows[i]["DataTypeID"]);


            for (int j = 0; j < dtTarget.Rows.Count; j++)
            {
                if (!string.IsNullOrEmpty(dtTarget.Rows[j]["value"].ToString()))
                {
                    //if (i == 1)
                    //{
                    if (LavelID == Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) && dtTarget.Rows[j]["type"].ToString() == "B")
                    {
                        string key = dtTarget.Rows[j]["RefLevel3ID"].ToString() + dtTarget.Rows[j]["type"].ToString();
                        if (!objcheckbar.Contains(key))
                        {
                            objcheckbar.Add(key, key);

                            bar = new Bar();
                            bar.color = SPPUtility.HexConverterColor();
                            bar.chartdetails = new List<Chartdetail>();
                            bar.title = ispointchart == true ? "Points Earned" : dtTarget.Rows[j]["RelevantData"].ToString();
                            chart.title = ispointchart == true ? "Points Earned" : sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 0)[1].Replace("–", " "); //+ " " + dtTarget.Rows[j]["Year"].ToString();

                            chart.valuetype = ispointchart == true ? sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 2)[0] : sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 1)[0];
                            chart.foottext = sppobj.GetDashbordConfiguration().Where(x => x.id == 1).ToList()[0].value;
                        }


                        chartdetail = new Chartdetail();
                        chartdetail.columnheader = dtTarget.Rows[j]["monthname"].ToString();

                        chartdetail.columnvalue = dtTarget.Rows[j]["value"].ToString();
                        bar.chartdetails.Add(chartdetail);
                        chartbar = true;


                    }
                    else if (LavelID == Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) && dtTarget.Rows[j]["type"].ToString() == "L")
                    {
                        string key = dtTarget.Rows[j]["RefLevel3ID"].ToString() + dtTarget.Rows[j]["type"].ToString();
                        if (!objcheckline.Contains(key))
                        {
                            objcheckline.Add(key, key);

                            line = new Line();
                            line.color = SPPUtility.HexConverterColor();
                            line.chartdetails = new List<Chartdetail2>();
                            line.title = "National";
                        }


                        chartdetail2 = new Chartdetail2();
                        chartdetail2.columnheader = dtTarget.Rows[j]["monthname"].ToString();

                        chartdetail2.columnvalue = dtTarget.Rows[j]["value"].ToString();
                        line.chartdetails.Add(chartdetail2);

                        chartbar = true;


                    }
                    //----------------------------------------Table----------------------------------------


                    if (LavelID == Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) && dtTarget.Rows[j]["type"].ToString() == "B")
                    {
                        string key = dtTarget.Rows[j]["RefLevel3ID"].ToString() + dtTarget.Rows[j]["type"].ToString();
                        if (!objchecktable.Contains(key))
                        {
                            objchecktable.Add(key, key);

                            table = new Table();
                            table.color = SPPUtility.HexConverterColor();
                            table.chartdetails = new List<Chartdetail3>();
                            chart.title = ispointchart == true ? "Points Earned" : sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 0)[1].Replace("–", " ");//+ " " + dtTarget.Rows[j]["Year"].ToString();// sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString());
                            chart.titlefootnote = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 0)[0];
                            chart.valuetype = ispointchart == true ? sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 2)[0] : sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 1)[0];
                            chart.foottext = sppobj.GetDashbordConfiguration().Where(x => x.id == 1).ToList()[0].value;
                            chartdetail3 = new Chartdetail3();
                            chartdetail3.columnheader = "";
                            chartdetail3.columnvalue = dtTarget.Rows[j]["RelevantData"].ToString();
                            table.chartdetails.Add(chartdetail3);

                        }


                        chartdetail3 = new Chartdetail3();
                        chartdetail3.columnheader = dtTarget.Rows[j]["monthname"].ToString();
                        string perc = ispointchart == true ? sppobj.returnChartValueType(sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 2)[0]) : sppobj.returnChartValueType(sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 1)[0]);
                        chartdetail3.columnvalue = dtTarget.Rows[j]["value"].ToString() + perc;
                        table.chartdetails.Add(chartdetail3);

                        charttable = true;


                    }
                    else if (LavelID == Convert.ToInt32(dtTarget.Rows[j]["RefLevel3ID"]) && dtTarget.Rows[j]["type"].ToString() == "L")
                    {
                        string key = dtTarget.Rows[j]["RefLevel3ID"].ToString() + dtTarget.Rows[j]["type"].ToString();
                        if (!objchecktable.Contains(key))
                        {
                            objchecktable.Add(key, key);

                            table1 = new Table();
                            table1.color = SPPUtility.HexConverterColor();
                            table1.chartdetails = new List<Chartdetail3>();
                            chart.title = ispointchart == true ? "Points Earned" : sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 0)[1].Replace("–", " ");// +" " + dtTarget.Rows[j]["Year"].ToString();
                            chart.titlefootnote = sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 0)[0];
                            chart.valuetype = ispointchart == true ? sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 2)[0] : sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 1)[0];
                            string perchk = ispointchart == true ? sppobj.returnChartValueType(sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 2)[0]) : sppobj.returnChartValueType(sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 1)[0]);
                            chart.foottext = perchk == "P" ? sppobj.GetDashbordConfiguration().Where(x => x.id == 1).ToList()[0].value : "";
                            chartdetail3 = new Chartdetail3();
                            chartdetail3.columnheader = "";
                            chartdetail3.columnvalue = "National";// dtTarget.Rows[j]["RelevantData"].ToString();
                            table1.chartdetails.Add(chartdetail3);

                        }


                        chartdetail3 = new Chartdetail3();
                        chartdetail3.columnheader = dtTarget.Rows[j]["monthname"].ToString();
                        string perc = ispointchart == true ? sppobj.returnChartValueType(sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 2)[0]) : sppobj.returnChartValueType(sppobj.GetGraphTitle(dtTarget.Rows[j]["RefLevel3ID"].ToString(), 1)[0]);
                        chartdetail3.columnvalue = dtTarget.Rows[j]["value"].ToString() + perc;
                        table1.chartdetails.Add(chartdetail3);

                        charttable1 = true;


                    }

                    //--------------------------------------------------------------------------------------

                }
            }

            chart.bar.Add(bar);
            chart.line.Add(line);

            chart.table.Add(table);
            chart.table.Add(table1);
            // }
            //  sPPSearchDashbordResponseDTO.Chart.Add(chart);


            //---------------------------------------------------End Target vs Achivement------------------------------------------------------------------------
        }
        catch (Exception ex)
        {
            throw ex;
        }



        return chart;
    }


    private static SPPSearchDashbordResponseDTO GenerateGraphWithParameter(DataSet dsMenu)
    {


        SPPSearchDashbordResponseDTO sPPSearchDashbordResponseDTO = new SPPSearchDashbordResponseDTO();
        sPPSearchDashbordResponseDTO.chart = new List<Chart>();
        SPPUtility objUtility = new SPPUtility();
        try
        {
            DataTable dttarget = objUtility.GenericReplace(dsMenu.Tables[0]);
            var targetRows = (from DataRow dRow in dttarget.Rows
                              select dRow["RefLevel3ID"]).Distinct();
            foreach (var col in targetRows)
            {
                int levelid = Convert.ToInt32(col);

                sPPSearchDashbordResponseDTO.chart.Add(GenerateGraph1(dsMenu, 1, true, levelid));
            }

            // sPPSearchDashbordResponseDTO.chart.Add(GenerateGraph1(dsMenu, 1,true));
            // sPPSearchDashbordResponseDTO.chart.Add(GenerateGraph1(dsMenu, 2));
            DataTable dtNormal = objUtility.GenericReplace(dsMenu.Tables[1]);
            var distinctRows = (from DataRow dRow in dtNormal.Rows
                                select dRow["RefLevel3ID"]).Distinct();
            foreach (var col in distinctRows)
            {
                int levelid = Convert.ToInt32(col);
                sPPSearchDashbordResponseDTO.chart.Add(GenerateNormalGraph(dsMenu, levelid, true, false));
            }

            if (dsMenu.Tables.Count == 3)
            {
                DataTable dtNormalchart = objUtility.GenericReplace(dsMenu.Tables[2]);
                var distinctRows1 = (from DataRow dRow in dtNormal.Rows
                                     select dRow["RefLevel3ID"]).Distinct();
                foreach (var col in distinctRows1)
                {
                    int levelid = Convert.ToInt32(col);
                    sPPSearchDashbordResponseDTO.chart.Add(GenerateNormalGraph(dsMenu, levelid, false, true));
                }
            }

            // }



            //---------------------------------------------------End Target vs Achivement------------------------------------------------------------------------
        }
        catch (Exception ex)
        {
            throw ex;
        }



        return sPPSearchDashbordResponseDTO;
    }
    /// <summary>
    /// Function to Get Channel Program Month
    /// Added by Shyam Sunder Kumar as on 21-Aug-2017
    /// </summary>
    /// <param name="vProgramID">Program ID</param>
    /// <returns>DataTable</returns>
    public DataTable GetChannelProgramMonth(string vProgramID)
    {
        DataLayer dtLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        try
        {
            return objUtility.GenericReplace(SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_GetMonth",
                                                                                                new SqlParameter("@ProgramID", vProgramID)).Tables[0]);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
            if (objUtility != null)
                objUtility = null;

        }

    }

    /// <summary>
    /// Function to Get Report Type and Month
    /// Added by Shyam Sunder Kumar as on 15-Sep-2017
    /// </summary>
    /// <param name="vProgramID">Program ID</param>
    /// <param name="vMode">M-Month, Q-Quarter</param>
    /// <returns>SPPChannelProgramReportResponseDTO</returns>
    public SPPChannelProgramReportResponseDTO GetChannelProgramReportType(string vProgramID)
    {
        DataLayer dtLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        SPPChannelProgramReportResponseDTO obj = new SPPChannelProgramReportResponseDTO();

        Month objMonth = null;
        Quarter objQuarter = null;
        DataSet dtMonth = new DataSet();
        obj.month = new List<Month>();
        obj.quarter = new List<Quarter>();
        try
        {

            dtMonth = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_GetMonth",
                                                                                                new SqlParameter("@ProgramID", vProgramID));
            if (dtMonth.Tables[0] != null & dtMonth.Tables[0].Rows.Count > 0)
            {
                //if (vMode.ToUpper() == "M")
                //{
                //    obj.value = "M";
                //    obj.text = "Month";
                //}
                //else
                //{
                //    obj.value = "Q";
                //    obj.text = "Quarter";
                //}
                for (int i = 0; i < dtMonth.Tables[0].Rows.Count; i++)
                {

                    objMonth = new Month();

                    objMonth.month = dtMonth.Tables[0].Rows[i]["Month"].ToString();
                    objMonth.year = dtMonth.Tables[0].Rows[i]["Year"].ToString();
                    objMonth.display = dtMonth.Tables[0].Rows[i]["MonthName"].ToString();

                    obj.month.Add(objMonth);


                }
            }

            if (dtMonth.Tables[1] != null & dtMonth.Tables[1].Rows.Count > 0)
            {
                //if (vMode.ToUpper() == "M")
                //{
                //    obj.value = "M";
                //    obj.text = "Month";
                //}
                //else
                //{
                //    obj.value = "Q";
                //    obj.text = "Quarter";
                //}
                for (int i = 0; i < dtMonth.Tables[1].Rows.Count; i++)
                {



                    objQuarter = new Quarter();

                    objQuarter.quarter = dtMonth.Tables[1].Rows[i]["Month"].ToString();
                    objQuarter.year = dtMonth.Tables[1].Rows[i]["Year"].ToString();
                    objQuarter.display = dtMonth.Tables[1].Rows[i]["MonthName"].ToString();

                    obj.quarter.Add(objQuarter);

                }
            }
            return obj;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
            if (objMonth != null)
                objMonth = null;
            if (dtMonth != null)
                dtMonth = null;
            if (obj != null)
                obj = null;
            if (objUtility != null)
                objUtility = null;
        }

    }

    /// <summary>
    /// Function to Get Report Type and Month
    /// Added by Shyam Sunder Kumar as on 15-Sep-2017
    /// </summary>
    /// <param name="vProgramID">Program ID</param>
    /// <param name="vMode">M-Month, Q-Quarter</param>
    /// <returns>SPPChannelProgramReportResponseDTO</returns>
    public SPPChannelProgramGeoResponseDTO GetChannelProgramGeoFilter(string vProgramID, string LoginUser)
    {
        DataLayer dtLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        SPPChannelProgramGeoResponseDTO obj = new SPPChannelProgramGeoResponseDTO();

        Cluster objCluster = null;
        Regiongeo objRegion = null;
        State objState = null;

        DataSet dtGeo = new DataSet();
        obj.cluster = new List<Cluster>();
        obj.region = new List<Regiongeo>();
        obj.state = new List<State>();
        try
        {

            dtGeo = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_GetGeoFilter",
                                                                                                new SqlParameter("@ProgramID", vProgramID),
                                                                                                new SqlParameter("@LoginUser", LoginUser));
            if (dtGeo.Tables[0] != null & dtGeo.Tables[0].Rows.Count > 0)
            {
                //if (vMode.ToUpper() == "M")

                for (int i = 0; i < dtGeo.Tables[0].Rows.Count; i++)
                {

                    objCluster = new Cluster();

                    objCluster.clusterkey = dtGeo.Tables[0].Rows[i]["clusterkey"].ToString();
                    objCluster.clustervalue = dtGeo.Tables[0].Rows[i]["clustervalue"].ToString();

                    obj.cluster.Add(objCluster);


                }
            }

            if (dtGeo.Tables[1] != null & dtGeo.Tables[1].Rows.Count > 0)
            {

                for (int i = 0; i < dtGeo.Tables[1].Rows.Count; i++)
                {

                    objRegion = new Regiongeo();

                    objRegion.clusterkey = dtGeo.Tables[1].Rows[i]["clusterkey"].ToString();
                    objRegion.regionkey = dtGeo.Tables[1].Rows[i]["subregionkey"].ToString();
                    objRegion.regionvalue = dtGeo.Tables[1].Rows[i]["subregionvalue"].ToString();

                    obj.region.Add(objRegion);

                }
            }

            if (dtGeo.Tables[2] != null & dtGeo.Tables[2].Rows.Count > 0)
            {

                for (int i = 0; i < dtGeo.Tables[2].Rows.Count; i++)
                {


                    objState = new State();
                    objState.clusterkey = dtGeo.Tables[2].Rows[i]["clusterkey"].ToString();
                    objState.regionkey = dtGeo.Tables[2].Rows[i]["subregionkey"].ToString();
                    objState.statekey = dtGeo.Tables[2].Rows[i]["statekey"].ToString();
                    objState.statevalue = dtGeo.Tables[2].Rows[i]["statevalue"].ToString();

                    obj.state.Add(objState);

                }
            }
            return obj;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
            if (obj != null)
                obj = null;
            if (objUtility != null)
                objUtility = null;
        }

    }

    /// <summary>
    /// Function to Get Report Type and Month
    /// Added by Shyam Sunder Kumar as on 15-Sep-2017
    /// </summary>
    /// <param name="vProgramID">Program ID</param>
    /// <param name="vMode">M-Month, Q-Quarter</param>
    /// <returns>SPPChannelProgramReportResponseDTO</returns>
    public List<SPPChannelProgramUserFilterResponseDTO> GetChannelProgramUserFilter(string vProgramID, string cluster, string region, string state
        , string parenttype, string PartnerCode, string LoginUser, string Month, string Year, string vTargetType)
    {
        DataLayer dtLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();

        SPPChannelProgramUserFilterResponseDTO obj = null;
        List<SPPChannelProgramUserFilterResponseDTO> list = new List<SPPChannelProgramUserFilterResponseDTO>();
        //SRDUser objSRDUser = null;
        //MDDUser objMDDUser = null;
        //TSEUser objTSEUser = null;

        DataSet dtGeo = new DataSet();
        //obj.srduser = new List<SRDUser>();
        //obj.mdduser = new List<MDDUser>();
        //obj.tseuser = new List<TSEUser>();
        //obj.smduser = new List<SMDUser>();
        try
        {

            //dtGeo = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_GetDashbordUserFilter",
            //                                                                                    new SqlParameter("@ProgramID", vProgramID));
            //         @ProgramID INT = 13
            //,@Cluster VARCHAR(50) = '0'
            //,@SubRegion VARCHAR(50) = '0'
            //,@State VARCHAR(50) = '0'
            //,@parenttype VARCHAR(50) = '0'
            //,@PartnerCode VARCHAR(50) = '0'
            //,@LoginUser Varchar(50)='aditya.b2'
            dtGeo = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_GetDashbordUserFilterOrg",
                                                                                                new SqlParameter("@ProgramID", vProgramID),
                                                                                                new SqlParameter("@Cluster", cluster),
                                                                                                new SqlParameter("@SubRegion", region),
                                                                                                new SqlParameter("@State", state),
                                                                                                new SqlParameter("@parenttype", parenttype),
                                                                                                new SqlParameter("@PartnerCode", PartnerCode),
                                                                                                new SqlParameter("@LoginUser", LoginUser),
                                                                                                new SqlParameter("@Month", Month),
                                                                                                new SqlParameter("@Year", Year),
                                                                                                new SqlParameter("@targettype", vTargetType)
                                                                                               );

            if (dtGeo.Tables.Count > 0)
            {
                if (dtGeo.Tables[0] != null & dtGeo.Tables[0].Rows.Count > 0)
                {
                    //if (vMode.ToUpper() == "M")

                    for (int i = 0; i < dtGeo.Tables[0].Rows.Count; i++)
                    {

                        obj = new SPPChannelProgramUserFilterResponseDTO();

                        obj.partnercode = dtGeo.Tables[0].Rows[i]["partnercode"].ToString();
                        obj.partnername = dtGeo.Tables[0].Rows[i]["partnername"].ToString();

                        list.Add(obj);


                    }
                }
            }

            //if (dtGeo.Tables[1] != null & dtGeo.Tables[1].Rows.Count > 0)
            //{

            //    for (int i = 0; i < dtGeo.Tables[1].Rows.Count; i++)
            //    {



            //        objMDDUser = new MDDUser();

            //       // objMDDUser.srdusercode = dtGeo.Tables[1].Rows[i]["partnercode"].ToString();
            //        objMDDUser.partnercode = dtGeo.Tables[1].Rows[i]["partnercode"].ToString();
            //        objMDDUser.partnername = dtGeo.Tables[1].Rows[i]["partnername"].ToString();

            //        obj.mdduser.Add(objMDDUser);

            //    }
            //}
            //if (dtGeo.Tables.Count > 2)
            //{
            //    if (dtGeo.Tables[2] != null & dtGeo.Tables[2].Rows.Count > 0)
            //    {

            //        for (int i = 0; i < dtGeo.Tables[2].Rows.Count; i++)
            //        {



            //            objTSEUser = new TSEUser();

            //           // objTSEUser.mddusercode = dtGeo.Tables[2].Rows[i]["mddusername"].ToString();
            //            objTSEUser.partnercode = dtGeo.Tables[2].Rows[i]["tseusercode"].ToString();
            //            objTSEUser.partnername = dtGeo.Tables[2].Rows[i]["tseusername"].ToString();

            //            obj.tseuser.Add(objTSEUser);

            //        }
            //    }
            //}
            return list;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
            if (obj != null)
                obj = null;
            if (objUtility != null)
                objUtility = null;
        }

    }

    public string[] GetGraphTitle(string Level3ID, int Flag)
    {


        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        string[] ret = { };
        try
        {


            dt = objUtility.GenericReplace(SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_GetGraphTitle",
                  new SqlParameter("@Level3ID", Level3ID), new SqlParameter("@Flag", Flag.ToString())
                  ).Tables[0]);
            if (Flag == 1)
                ret = new string[] { dt.Rows[0]["Level3Text"].ToString(), string.Empty };
            else
                ret = new string[] { dt.Rows[0]["Level3Text"].ToString(), dt.Rows[0]["param"].ToString() };

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return ret;
    }
    #endregion

    #region "Auth2 Implementation"
    public void AddAuthorizationcodeAuth2(AuthModel authmodel)
    {
        DataLayer objDataLayer = new DataLayer();
        //      @ClientID varchar(100),
        //@ClientSecret varchar(100),
        //@AuthorizationCode  varchar(100),
        //@DealerCode varchar(50),
        //@urlcode varchar(50),
        //@skucode varchar(50)
        try
        {
            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spInsertAuth2AuthorizationCode",
                                                                                                            new SqlParameter("@ClientID", authmodel.ClientID),
                                                                                                            new SqlParameter("@ClientSecret", authmodel.ClientSecret),
                                                                                                            new SqlParameter("@AuthorizationCode", authmodel.AuthorizationCode),
                                                                                                            new SqlParameter("@DealerCode", authmodel.DealerCode),
                                                                                                            new SqlParameter("@urlcode", authmodel.UrlCode),
                                                                                                            new SqlParameter("@skucode", authmodel.SkuCode),



                                                                                                            new SqlParameter("@accesstoken", authmodel.AccessToken),
                                                                                                            new SqlParameter("@refreshtoken", authmodel.RefreshToken),
                                                                                                            new SqlParameter("@AccessTokenExpireTimeInSecond", authmodel.AccessTokenExpireTimeInSecond),
                                                                                                            new SqlParameter("@accesstokenexpiredate", authmodel.accesstokenexpiredate),
                                                                                                            new SqlParameter("@IsRefreshTokenExpire", authmodel.IsRefreshTokenExpire),
                                                                                                            new SqlParameter("@RefreshTokenExpireDate", authmodel.RefreshTokenExpireDate),
                                                                                                            new SqlParameter("@devicetype", authmodel.devicetype),
                                                                                                            new SqlParameter("@Flag", authmodel.Flag),
                                                                                                            new SqlParameter("@AuthorizationCodeExpireDate", authmodel.AuthorizationCodeExpireDate),

                                                                                                           new SqlParameter("@scope", authmodel.scope));







        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }

    }

    public DataTable GetDealerCodeByAuthToken(AuthModel authmodel)
    {
        DataLayer objDataLayer = new DataLayer();
        try
        {
            DataSet ds = new DataSet();
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetDealerCodeByAuthToken",
                                                                                                             new SqlParameter("@Token", authmodel.Token));
            return ds.Tables[0];
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }

    }

    public bool ValidateAddTokenParam(AuthTokenParamRequestDTO input)
    {
        bool status = false;
        DataLayer objDataLayer = new DataLayer();
        try
        {

            var authorizationcode = SqlHelper.ExecuteScalar(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spAuthTokenParamCheckSecurity",
                                                                                                          new SqlParameter("@authorizationcode", input.authorizationcode),
                                                                                                          new SqlParameter("@clientid", input.clientid),
                                                                                                          new SqlParameter("@clientsecret", input.clientsecret),
                                                                                                          new SqlParameter("@refreshtoken", input.refreshtoken),
                                                                                                          new SqlParameter("@token", input.token));



            if (!string.IsNullOrEmpty(input.token))
            {
                if (authorizationcode != null && authorizationcode.ToString().ToLower() == input.token.ToLower())
                {
                    status = true;
                }
            }
            else if (!string.IsNullOrEmpty(input.refreshtoken))
            {
                if (authorizationcode != null && authorizationcode.ToString().ToLower() == input.refreshtoken.ToLower())
                {
                    status = true;
                }
            }
            else
            {
                if (authorizationcode != null && authorizationcode.ToString().ToLower() == input.authorizationcode.ToLower())
                {
                    status = true;
                }
            }
        }
        catch (Exception exc)
        {
            throw exc;
        }
        finally
        {
            objDataLayer = null;
        }

        return status;
    }

    //piyus get details API TODO
    #endregion


    /// <summary>
    /// Upgrade program popup
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public DataTable GetUpgradeProgramConfiguration()
    {

        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        DataTable Datatable = null;
        try
        {
            dtLayer = new DataLayer();
            Datatable = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "SpDealerOnBoardDetailConfiguration",
                                                                                                new SqlParameter("@CurrentDate", DateTime.Now)).Tables[0];






        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return Datatable;
    }

    /// <summary>
    /// Upgrade program popup
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<Dialog> GetUpgradeProgramConfigurationv2(string DealerCode)
    {

        List<Dialog> dialog = new List<Dialog>();
        Dialog odialog = null;

        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        DataSet dstable = null;
        string agreebuttontext = string.Empty;
        string agreebuttonvisible = string.Empty;
        string disagreebuttontext = string.Empty;
        string disagreebuttonvisible = string.Empty;

        string vUpgradeImagePath = string.Empty;
        String vFileType = System.Configuration.ConfigurationManager.AppSettings["UpgradeFileType"].ToString();


        vUpgradeImagePath = SPPUtility.UpgradePopup.Replace("\\", "/") + "/";
        string path = System.Configuration.ConfigurationManager.AppSettings["upgradepopupimg"].ToString();

        //  string vUpgradeImagePath = System.Configuration.ConfigurationManager.AppSettings["upgradepopupimg"].ToString() + SPPUtility.UpgradePopup.Replace("\\", "/") + "/";
        try
        {
            dtLayer = new DataLayer();
            dstable = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "SpDealerOnBoardDetailConfigurationv2",
                new SqlParameter("@DealerCode", DealerCode),
                new SqlParameter("@CurrentDate", DateTime.Now));

            for (int i = 0; i < dstable.Tables[0].Rows.Count; i++)
            { //AgreeButtonText,	AgreeButtonEnable,	DisagreeButtonText,	DisagreeButtonEnable
                agreebuttontext = dstable.Tables[0].Rows[i]["AgreeButtonText"].ToString();
                agreebuttonvisible = dstable.Tables[0].Rows[i]["AgreeButtonEnable"].ToString();

                disagreebuttontext = dstable.Tables[0].Rows[i]["DisagreeButtonText"].ToString();
                disagreebuttonvisible = dstable.Tables[0].Rows[i]["DisagreeButtonEnable"].ToString();
            }

            for (int i = 0; i < dstable.Tables[1].Rows.Count; i++)
            { //ConfigurationID	ConfigurationImage	Termandcondition	isshowterm	IsupgradeMenu	isshowagree
                odialog = new Dialog();
                odialog.configurationid = dstable.Tables[1].Rows[i]["ConfigurationID"].ToString();
                //   objUtility.GetNASFilePath(SPPUtility.ChannelProgramEngine + "\\Logo\\" + dt.Rows[i]["LogoPath"].ToString())
                odialog.configurationimage = vFileType == "F" ? path + objUtility.GetFilePath(vUpgradeImagePath + dstable.Tables[1].Rows[i]["ConfigurationImage"].ToString()) : path + vUpgradeImagePath + dstable.Tables[1].Rows[i]["ConfigurationImage"].ToString();

                odialog.termandcondition = "Term and Condition";// dstable.Tables[1].Rows[i]["Termandcondition"].ToString();
                odialog.termconditiondetails = dstable.Tables[1].Rows[i]["Termandcondition"].ToString();
                odialog.isshowterm = dstable.Tables[1].Rows[i]["isshowterm"].ToString();
                odialog.isupgrademenu = dstable.Tables[1].Rows[i]["IsupgradeMenu"].ToString();
                odialog.isshowagree = dstable.Tables[1].Rows[i]["isshowagree"].ToString();
                odialog.agreebuttontext = agreebuttontext;
                odialog.agreebuttonvisible = agreebuttonvisible;

                odialog.disagreebuttontext = disagreebuttontext;
                odialog.disagreebuttonvisible = disagreebuttonvisible;
                dialog.Add(odialog);
            }

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return dialog;
    }

    /// <summary>
    /// Upgrade program popup
    /// </summary>
    /// <param name="PartnerCode">sPartnerCode</param>
    /// <returns></returns>
    public List<Dialog> DealerOnBoardUpgradeSaveAction(string DealerCode, string ConfigurationID, string sAction)
    {

        List<Dialog> dialog = new List<Dialog>();
        Dialog odialog = null;

        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        DataSet dstable = null;
        string agreebuttontext = string.Empty;
        string agreebuttonvisible = string.Empty;
        string disagreebuttontext = string.Empty;
        string disagreebuttonvisible = string.Empty;

        //string vUpgradeImagePath = SPPUtility.OverlayPopup.Replace("\\", "/") + "/";
        string vUpgradeImagePath = string.Empty;
        String vFileType = System.Configuration.ConfigurationManager.AppSettings["UpgradeFileType"].ToString();

        vUpgradeImagePath = SPPUtility.UpgradePopup.Replace("\\", "/") + "/";
        string path = System.Configuration.ConfigurationManager.AppSettings["upgradepopupimg"].ToString();
        try
        {


            dtLayer = new DataLayer();
            dstable = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "SpDealerOnBoardUpgradeSaveAction",
                new SqlParameter("@DealerCode", DealerCode),
                 new SqlParameter("@ConfigurationID", ConfigurationID),
                  new SqlParameter("@Action", sAction),
                new SqlParameter("@CurrentDate", DateTime.Now));

            for (int i = 0; i < dstable.Tables[0].Rows.Count; i++)
            { //AgreeButtonText,	AgreeButtonEnable,	DisagreeButtonText,	DisagreeButtonEnable
                agreebuttontext = dstable.Tables[0].Rows[i]["AgreeButtonText"].ToString();
                agreebuttonvisible = dstable.Tables[0].Rows[i]["AgreeButtonEnable"].ToString();

                disagreebuttontext = dstable.Tables[0].Rows[i]["DisagreeButtonText"].ToString();
                disagreebuttonvisible = dstable.Tables[0].Rows[i]["DisagreeButtonEnable"].ToString();
            }

            for (int i = 0; i < dstable.Tables[1].Rows.Count; i++)
            { //ConfigurationID	ConfigurationImage	Termandcondition	isshowterm	IsupgradeMenu	isshowagree
                odialog = new Dialog();
                odialog.configurationid = dstable.Tables[1].Rows[i]["ConfigurationID"].ToString();
                odialog.configurationimage = vFileType == "F" ? path + objUtility.GetFilePath(vUpgradeImagePath + dstable.Tables[1].Rows[i]["ConfigurationImage"].ToString()) : path + vUpgradeImagePath + dstable.Tables[1].Rows[i]["ConfigurationImage"].ToString();// objUtility.GetFilePath(vUpgradeImagePath + dstable.Tables[1].Rows[i]["ConfigurationImage"].ToString()); 
                odialog.termandcondition = "Term and Condition";// dstable.Tables[1].Rows[i]["Termandcondition"].ToString();
                odialog.termconditiondetails = dstable.Tables[1].Rows[i]["Termandcondition"].ToString();
                odialog.isshowterm = dstable.Tables[1].Rows[i]["isshowterm"].ToString();
                odialog.isupgrademenu = dstable.Tables[1].Rows[i]["IsupgradeMenu"].ToString();
                odialog.isshowagree = dstable.Tables[1].Rows[i]["isshowagree"].ToString();
                odialog.agreebuttontext = agreebuttontext;
                odialog.agreebuttonvisible = agreebuttonvisible;

                odialog.disagreebuttontext = disagreebuttontext;
                odialog.disagreebuttonvisible = disagreebuttonvisible;
                dialog.Add(odialog);
            }

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return dialog;
    }

    public List<DashbordConfiguration> GetDashbordConfiguration()
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        List<DashbordConfiguration> olist = new List<DashbordConfiguration>();
        DashbordConfiguration oDashbordConfiguration = null;
        try
        {


            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spDA_GetDashbordConfiguration").Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                oDashbordConfiguration = new DashbordConfiguration();
                oDashbordConfiguration.id = Convert.ToInt32(dt.Rows[i]["id"].ToString());
                oDashbordConfiguration.value = dt.Rows[i]["Configuration"].ToString();
                olist.Add(oDashbordConfiguration);

            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return olist;
    }
    public bool SPPSelfOrderAccessCheck(int configID)
    {
        string ires = "";
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@ConfigurationValue";
            outPutParameter.SqlDbType = System.Data.SqlDbType.VarChar;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 200;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSPPGetConfigurationValueByConfigurationID",
                new SqlParameter("@ConfigurationID", configID),
                outPutParameter
                );
            ires = outPutParameter.Value.ToString();


            if (ires == "1")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }


    }

    public bool CheckOrderSubmitToday(int storeid, string applicationSource)
    {
        DataSet ds = new DataSet();
        DataLayer objDataLayer = new DataLayer();
        try
        {

            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSmartDostConnection(), CommandType.StoredProcedure, "spGetOrderBookingDealerDetailForSPP",
                new SqlParameter("@storeID", storeid),
                new SqlParameter("@ApplicationSource", applicationSource)
                );



            if (ds.Tables[0].Rows.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }

    public int GetStoreIDByDealerCode(string dealercode)
    {
        DataSet ds = new DataSet();
        DataLayer objDataLayer = new DataLayer();
        try
        {

            int storeid = (int)SqlHelper.ExecuteScalar(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOrderBookComGetStoreID",
                new SqlParameter("@DealerCode", dealercode)
                );

            return storeid;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }
    #region "Product Corner Smart Dost"

    /// <summary>
    /// Function to Get Product Details
    /// </summary>
    /// <param name="vProductcode">Product code</param>
    /// <param name="vSKUCode">SKU Code</param>
    /// <returns>DataSet</returns>
    public DataSet SPPSDGetProductDetails(string vProductcode, string vSKUCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProductList = new DataSet();
        try
        {
            dsProductList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSDGetProductDetails"
                , new SqlParameter("@Productcode", vProductcode), new SqlParameter("@SkuCode", vSKUCode));
            return dsProductList;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (dsProductList != null)
            {
                dsProductList = null;
            }
        }

    }


    /// <summary>
    /// Function to Get Product Details By SKU Code
    /// </summary>
    /// <param name="vSKUCode">SKU Code</param>
    /// <param name="vDMSCode">DMS Code</param>
    /// <returns>DataTable</returns>
    public DataTable SPPSDGetProductBySKUCode(string vSKUCode, string vDMSCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProductList = new DataSet();
        try
        {
            dsProductList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetProductBySKUCode"
                , new SqlParameter("@SKUCode", vSKUCode), new SqlParameter("@DMSCode", vDMSCode));
            return dsProductList.Tables[0];
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (dsProductList != null)
            {
                dsProductList = null;
            }
        }

    }

    public DataTable SPPSDGetProductByProductCode(string vProductCode, string vDMSCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProductList = new DataSet();
        try
        {
            dsProductList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetProductByProductCode"
                , new SqlParameter("@ProductCode", vProductCode), new SqlParameter("@DMSCode", vDMSCode));
            return dsProductList.Tables[0];
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (dsProductList != null)
            {
                dsProductList = null;
            }
        }

    }
    #endregion "Product Corner Smart Dost"

    #region Order Management SPP
    /// <summary>
    /// Function to List Product by Dealer Code and Category ID
    /// Modified by Shyam Sunder Kumar as on 28-May-2020 to Change Proc name which have additional Parameter @CatID
    /// </summary>
    /// <param name="DealerCode">DealerCode</param>
    /// <param name="CategoryID">CategoryID</param>
    /// <returns>DataTable</returns>
    public DataTable GetNomralOrderBookingList(string DealerCode, string CategoryID)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {

            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetOrderBookingNormalProductList",
                new SqlParameter("@DealerCode", DealerCode)
                , new SqlParameter("@CatID", CategoryID)
                ).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }
    public DataTable GetSuggestedOrderBookingList(string DealerCode, string CategoryID)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;


        try
        {

            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetOrderBookingSuggestedProductList", new SqlParameter("@DealerCode", DealerCode), new SqlParameter("@CatID", CategoryID)).Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }
    public DataTable GetSuggestedOrderDealerDetailsSPP(int storeID, string ApplicationSource)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable suggSKUlist = null;


        try
        {


            suggSKUlist = SqlHelper.ExecuteDataset(objDataLayer.GetSmartDostConnection(), CommandType.StoredProcedure, "spGetOrderBookingDealerDetailForSPP",
                new SqlParameter("@storeID", storeID),
                new SqlParameter("@ApplicationSource", ApplicationSource)).Tables[0];



        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return suggSKUlist;
    }
    public bool OrderBookingSuggestedEnableDisable(string StoreCode, int storeID, string ApplicationSource)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable suggSKUlist = null;
        bool IsSuggestedOrderEnabled = false;

        try
        {
            DataTable dtSDSuggestedRecord = GetSuggestedOrderDealerDetailsSPP(storeID, ApplicationSource);

            suggSKUlist = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetOrderBookingSuggestedEnableDisable",
                new SqlParameter("@storeCode", StoreCode),
                new SqlParameter("@tblSuggestedEnableDisable", dtSDSuggestedRecord)).Tables[0];

            if (suggSKUlist.Rows.Count > 0 && suggSKUlist != null)
                IsSuggestedOrderEnabled = Convert.ToBoolean(suggSKUlist.Rows[0]["IsSuggestedOrderEnabled"]) == true ? true : false;


        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return IsSuggestedOrderEnabled;
    }

    public GetSuggestedOrderDetailsDTO GetSuggestedOrderDealerDetails(int userID, int storeID, string ApplicationSource)
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable suggSKUlist = null;
        GetSuggestedOrderDetailsDTO sku = null;

        try
        {


            suggSKUlist = SqlHelper.ExecuteDataset(objDataLayer.GetSmartDostConnection(), CommandType.StoredProcedure, "spGetOrderBookingDealerDetail",
                new SqlParameter("@userID", userID),
                new SqlParameter("@storeID", storeID),
                new SqlParameter("@ApplicationSource", ApplicationSource)).Tables[0];
            //  OutstandingValue OutstandingDate CurrentStock SellThrough SellOut IsSuggestedOrderEnabled SAMSDataDate



            for (int i = 0; i < suggSKUlist.Rows.Count; i++)
            {
                sku = new GetSuggestedOrderDetailsDTO();
                if (suggSKUlist.Rows[i]["OutstandingValue"] != null && !string.IsNullOrEmpty(suggSKUlist.Rows[i]["OutstandingValue"].ToString()))
                    sku.OutstandingValue = decimal.Parse(suggSKUlist.Rows[i]["OutstandingValue"].ToString());

                if (suggSKUlist.Rows[i]["OutstandingDate"] != null && !string.IsNullOrEmpty(suggSKUlist.Rows[i]["OutstandingDate"].ToString()))
                    sku.OutstandingDate = suggSKUlist.Rows[i]["OutstandingDate"].ToString();

                if (suggSKUlist.Rows[i]["CurrentStock"] != null && !string.IsNullOrEmpty(suggSKUlist.Rows[i]["CurrentStock"].ToString()))
                    sku.CurrentStock = Double.Parse(suggSKUlist.Rows[i]["CurrentStock"].ToString());
                if (suggSKUlist.Rows[i]["SellThrough"] != null && !string.IsNullOrEmpty(suggSKUlist.Rows[i]["SellThrough"].ToString()))
                    sku.SellThrough = decimal.Parse(suggSKUlist.Rows[i]["SellThrough"].ToString());
                if (suggSKUlist.Rows[i]["SellOut"] != null && !string.IsNullOrEmpty(suggSKUlist.Rows[i]["SellOut"].ToString()))
                    sku.Sellout = decimal.Parse(suggSKUlist.Rows[i]["SellOut"].ToString());
                if (suggSKUlist.Rows[i]["IsSuggestedOrderEnabled"] != null && !string.IsNullOrEmpty(suggSKUlist.Rows[i]["IsSuggestedOrderEnabled"].ToString()))
                    sku.IsSuggestedOrderEnabled = Convert.ToBoolean(suggSKUlist.Rows[i]["IsSuggestedOrderEnabled"]);
                if (suggSKUlist.Rows[i]["SAMSDataDate"] != null && !string.IsNullOrEmpty(suggSKUlist.Rows[i]["SAMSDataDate"].ToString()))
                    sku.SAMSDataDate = suggSKUlist.Rows[i]["SAMSDataDate"].ToString();

            }



        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return sku;
    }


    public GetSuggestedOrderDetailsDTO GetSuggestedOrderDetail(int userID, int storeID, string dealercode, string ApplicationSource)
    {
        GetSuggestedOrderDetailsDTO orderDetail = new GetSuggestedOrderDetailsDTO();

        OrderCategoriesDTO _obj = new OrderCategoriesDTO();
        List<SuggestedOrderProductDetailDTO> sKUlist = new List<SuggestedOrderProductDetailDTO>();
        List<NormalOrderProductDetailDTO> NormalSKUlist = new List<NormalOrderProductDetailDTO>();
        NormalOrderProductDetailDTO normalSKU = new NormalOrderProductDetailDTO();
        SuggestedOrderProductDetailDTO sku = new SuggestedOrderProductDetailDTO();
        DataTable prodList = new DataTable();
        DataTable _dtCategory = new DataTable();

        // var storeCode = StoreRepository.GetStoreCode(storeID);
        orderDetail.StoreCode = dealercode;
        // [dbo].[spGetOrderBookingDealerDetail]

        var result = GetSuggestedOrderDealerDetails(userID, storeID, ApplicationSource);

        if (result != null)
        {
            orderDetail.OutstandingDate = string.IsNullOrEmpty(result.OutstandingDate) == true ? string.Empty : result.OutstandingDate.ToString();
            orderDetail.OutstandingValue = result.OutstandingValue;
            orderDetail.CurrentStock = result.CurrentStock;
            orderDetail.Sellout = result.Sellout;
            orderDetail.SellThrough = result.SellThrough;
            //calling from spp
            orderDetail.IsSuggestedOrderEnabled = OrderBookingSuggestedEnableDisable(dealercode, storeID, ApplicationSource);// Convert.ToBoolean(result.IsSuggestedOrderEnabled);
            result.IsSuggestedOrderEnabled = orderDetail.IsSuggestedOrderEnabled;
            // result.IsSuggestedOrderEnabled = true;
            orderDetail.SAMSDataDate = result.SAMSDataDate;
            // result.IsSuggestedOrderEnabled = true;
        }

        orderDetail.categories = new List<OrderCategoriesDTO>();


        _dtCategory = GetOrderCategory();
        foreach (DataRow _drCategory in _dtCategory.Rows)
        {
            _obj = new OrderCategoriesDTO();
            _obj.title = _drCategory["CategoryName"].ToString();
            _obj.id = _drCategory["CategoryID"].ToString();
            _obj.IsExpandable = Convert.ToBoolean(_drCategory["IsExpanded"]);

            if (_drCategory["CategoryType"].ToString().ToUpper() == "B" || _drCategory["CategoryType"].ToString().ToUpper() == "N")
            {
                NormalSKUlist = new List<NormalOrderProductDetailDTO>();
                prodList = new DataTable();
                prodList = GetNomralOrderBookingList(dealercode, _drCategory["CategoryID"].ToString());
                if (prodList != null && prodList.Rows.Count > 0)
                {
                    foreach (DataRow _drProd in prodList.Rows)
                    {
                        normalSKU = new NormalOrderProductDetailDTO();
                        normalSKU.ProductCode = _drProd["ProductCode"].ToString();
                        normalSKU.Sellout = Double.Parse(_drProd["Sellout"].ToString());
                        normalSKU.SellThrough = Double.Parse(_drProd["SellThrough"].ToString());
                        normalSKU.CurrentStock = Double.Parse(_drProd["CurrentStock"].ToString());
                        normalSKU.DistryStock = Convert.ToInt32(_drProd["DistryStock"].ToString());

                        normalSKU.IsOutOfStock = bool.Parse(_drProd["IsOutOfStock"].ToString());
                        normalSKU.DealerPrice = Convert.ToInt64(_drProd["DealerPrice"]);
                        normalSKU.ProductColor = _drProd["ProductColor"].ToString();
                        normalSKU.MarketName = _drProd["MarketName"].ToString();
                        normalSKU.productID = Convert.ToInt32(_drProd["ProductID"]);
                        if (_drProd["IsExclusive"] != null && !string.IsNullOrEmpty(_drProd["IsExclusive"].ToString()))
                            normalSKU.IsExclusive = Convert.ToBoolean(_drProd["IsExclusive"]);
                        normalSKU.ishero = bool.Parse(_drProd["HeroModel"].ToString());
                        normalSKU.ProductGroup = _drCategory["SubmitValue"].ToString();
                        normalSKU.thumburl = ConfigurationManager.AppSettings["SPP_HtmlContentBaseURL"].ToString() + (new SPPUtility()).GetFilePath(SPPUtility.ProductCenter.Replace("\\", "/") + _drCategory["ImagePath"].ToString());

                        NormalSKUlist.Add(normalSKU);
                    }
                    _obj.NormalOrderProductDetails = NormalSKUlist;
                }
            }
            if (result.IsSuggestedOrderEnabled == true)
            {
                if (_drCategory["CategoryType"].ToString().ToUpper() == "B" || _drCategory["CategoryType"].ToString().ToUpper() == "S")
                {
                    sKUlist = new List<SuggestedOrderProductDetailDTO>();

                    DataTable suggSKUlist = GetSuggestedOrderBookingList(dealercode, _drCategory["CategoryID"].ToString());
                    if (suggSKUlist != null && suggSKUlist.Rows.Count > 0)
                    {
                        foreach (DataRow _drsuggSKUlist in suggSKUlist.Rows)
                        {
                            sku = new SuggestedOrderProductDetailDTO();
                            sku.SuggestedOrderQty = Convert.ToInt32(_drsuggSKUlist["SuggestedOrderQty"]);
                            sku.ProductCode = _drsuggSKUlist["ProductCode"].ToString();
                            sku.Sellout = Double.Parse(_drsuggSKUlist["Sellout"].ToString());
                            sku.SellThrough = Double.Parse(_drsuggSKUlist["SellThrough"].ToString());
                            sku.CurrentStock = Double.Parse(_drsuggSKUlist["CurrentStock"].ToString());
                            sku.DistryStock = Double.Parse(_drsuggSKUlist["DistryStock"].ToString());
                            sku.IsFocusModel = bool.Parse(_drsuggSKUlist["IsFocusModel"].ToString());
                            sku.IsNPPI = bool.Parse(_drsuggSKUlist["IsNPPI"].ToString());
                            sku.ISZeroStock = bool.Parse(_drsuggSKUlist["IsZeroStock"].ToString());
                            sku.IsOutOfStock = bool.Parse(_drsuggSKUlist["IsOutOfStock"].ToString());
                            sku.DealerPrice = Convert.ToInt64(_drsuggSKUlist["DealerPrice"]);
                            sku.ProductColor = _drsuggSKUlist["ProductColor"].ToString();
                            sku.MarketName = _drsuggSKUlist["MarketName"].ToString();
                            sku.productID = Convert.ToInt32(_drsuggSKUlist["ProductID"]);
                            if (_drsuggSKUlist["IsExclusive"] != null && !string.IsNullOrEmpty(_drsuggSKUlist["IsExclusive"].ToString()))
                                sku.IsExclusive = Convert.ToBoolean(_drsuggSKUlist["IsExclusive"]);
                            sku.ishero = bool.Parse(_drsuggSKUlist["HeroModel"].ToString());
                            sku.ProductGroup = _drCategory["SubmitValue"].ToString();
                            sku.thumburl = ConfigurationManager.AppSettings["SPP_HtmlContentBaseURL"].ToString() + (new SPPUtility()).GetFilePath(SPPUtility.ProductCenter.Replace("\\", "/") + _drCategory["ImagePath"].ToString());
                            sKUlist.Add(sku);
                        }
                        _obj.ProductDetails = sKUlist;
                    }
                }
            }
            orderDetail.categories.Add(_obj);
        }


        return orderDetail;
    }

    /// <summary>
    /// Function to Get Category List
    /// Added by Shyam Sunder Kumar as on 27-May-2020
    /// </summary>
    /// <returns></returns>
    public DataTable GetOrderCategory()
    {

        DataLayer objDataLayer = new DataLayer();
        SPPUtility objUtility = new SPPUtility();
        DataTable dt = null;
        try
        {
            dt = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetOrderBookingProductCategory").Tables[0];

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
            if (objUtility != null)
            {
                objUtility = null;
            }
        }

        return dt;
    }

    //---------------------------My Order---------------------------
    public DataTable GetMyOrder(string vStoreCode, string vStartDate, string vEndDate, string vOrderType, string CountryCode, string DivisionCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataTable orderSummary = new DataTable();
        try
        {
            return SqlHelper.ExecuteDataset(objDataLayer.GetSmartDostConnection(), CommandType.StoredProcedure, "SPGetReportOrderBooking",
                new SqlParameter("@StoreCode", vStoreCode),
                new SqlParameter("@UserCode", null),
                new SqlParameter("@StartDate", vStartDate),
                  new SqlParameter("@EndDate", vEndDate),
                  new SqlParameter("@OrderType", vOrderType),
                  new SqlParameter("@OrderStatus", null),
                  new SqlParameter("@CountryCode", CountryCode),
                  new SqlParameter("@DivisionCode", DivisionCode)

                ).Tables[0];
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }


    }

    public DataTable SearchOrderNo(string vStoreCode, string vStartDate, string vEndDate, string vSearchText)
    {
        DataLayer objDataLayer = new DataLayer();
        DataTable orderSummary = new DataTable();
        try
        {
            return SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOrderBookComSearchOrder",
                new SqlParameter("@DistCode", vStoreCode),
                new SqlParameter("@FromDate", vStartDate),
                  new SqlParameter("@ToDate", vEndDate),
                  new SqlParameter("@SearchText", vSearchText)
                ).Tables[0];
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }


    }

    public DataTable GetProductDetails(string vOrderNumber)
    {
        DataLayer objDataLayer = new DataLayer();
        DataTable orderSummary = new DataTable();
        try
        {
            return SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOrderBookComGetOrderDetails",
                new SqlParameter("@OrderNo", vOrderNumber)
                ).Tables[1];
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }


    }

    /// <summary>
    /// Method Created By Amit Singh on 3 June 2021 for Order Cancelled
    /// </summary>
    /// <param name="vOrderNumber"></param>
    /// <returns></returns>
    public DataTable GetCanceledProductDetails(string vOrderNumber)
    {
        DataLayer objDataLayer = new DataLayer();
        DataTable orderSummary = new DataTable();
        try
        {
            return SqlHelper.ExecuteDataset(objDataLayer.GetSmartDostConnection(), CommandType.StoredProcedure, "SPGetReportOrderBookingOrderCancel",
                new SqlParameter("@OrderNo", vOrderNumber)
                ).Tables[0];
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }


    }

    public DataTable GetDealerMinMax(string vDistCode, string vImei, string vLatitide, string vLongitude)
    {
        DataLayer objDataLayer = new DataLayer();
        DataTable orderSummary = new DataTable();
        try
        {
            return SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOrderBookPGGetMinMax",
                new SqlParameter("@DistCode", vDistCode),
                new SqlParameter("@Imei", vImei),
                new SqlParameter("@Latitide", vLatitide),
                new SqlParameter("@Longitude", vLongitude)
                ).Tables[0];
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }


    }
    //--------------------------

    /// <summary>
    /// Function to Generate and Get OTP Message
    /// Added by Shyam Sunder Kumar as on 19-Dec-2020
    /// </summary>
    /// <param name="vOTP">OTP</param>
    /// <param name="vDistCode">Dist Code</param> 
    /// <returns>DataTable</returns>
    public DataTable GenerateOTPMessage(string vOTP, string vDistCode)
    {
        DataLayer dtLayer = new DataLayer();

        try
        {

            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spLAGetOrderbookOTPMessage",
                                                                                                new SqlParameter("@DistCode", vDistCode)
                                                                                                , new SqlParameter("@Otp", vOTP)).Tables[0];


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
        }


    }

    /// <summary>
    /// Function to validate Orderbook OTP
    /// Added by Shyam Sunder Kumar as on 19-Dec-2020
    /// </summary>
    /// <param name="vOTP">OTP</param>
    /// <param name="vDistCode">Dist Code</param> 
    /// <returns>DataTable</returns>
    public DataTable ValidateOrderbookOTP(string vOTP, string vDistCode)
    {
        DataLayer dtLayer = new DataLayer();

        try
        {

            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spLAValidateOrderbookOTP",
                                                                                                new SqlParameter("@DistCode", vDistCode)
                                                                                                , new SqlParameter("@Otp", vOTP)).Tables[0];


        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;
        }


    }
    #endregion


    #region "Order Prebooking"


    public DataSet GetPrebookGetProductList(string vDealerCode)
    {
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        try
        {
            dtLayer = new DataLayer();
            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spPrebookGetProductList",
                                                                                                new SqlParameter("@DealerCode", vDealerCode));

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
    }

    public DataSet GetPrebookGetHistory(string vDealerCode)
    {
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        try
        {
            dtLayer = new DataLayer();
            return SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spPrebookGetHistory",
                                                                                                new SqlParameter("@DealerCode", vDealerCode));

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
    }

    public DataTable SavePrebookData(string vDealerCode, string vCustomerName, string vMobileNo, string vModelCode
        , string vMarketName, string vProductCode, string vQty, string vPrice, string vCreatedBy)
    {
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        try
        {
            dtLayer = new DataLayer();
            return objUtility.GenericReplace(SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spPrebookSaveOrder",
                                                                                                new SqlParameter("@DealerCode", vDealerCode),
                                                                                                new SqlParameter("@CustomerName", vCustomerName),
                                                                                                new SqlParameter("@MobileNo", vMobileNo),
                                                                                                new SqlParameter("@ModelCode", vModelCode),
                                                                                                new SqlParameter("@MarketName", vMarketName),
                                                                                                new SqlParameter("@ProductCode", vProductCode),
                                                                                                new SqlParameter("@Qty", vQty),
                                                                                                new SqlParameter("@Price", vPrice),
                                                                                                new SqlParameter("@CreatedBy", vCreatedBy)).Tables[0]);

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
    }
    #endregion "Order Prebooking"

    #region "Reset Password"
    /// <summary>
    /// Method is used to send new password to be saved(changed) in MCS
    /// Amit Kumar Singh
    /// Date: 27-Apr-2020
    /// </summary>
    /// <param name="UserID"></param>
    /// <param name="EncryNewPassword"></param>
    /// <returns></returns>
    public DataSet ChangePassword(string UserID, string EncryNewPassword, string OldPassword, int IsOldPwdVerify)
    {
        DataSet dsResultDetails = null;
        DataLayer dtLayer = new DataLayer();

        try
        {
            dsResultDetails = SqlHelper.ExecuteDataset(dtLayer.GetMCSConnection(), CommandType.StoredProcedure, "spChangeUserPassword",
                                                                                                        new SqlParameter("@UserId", UserID),
                                                                                                        new SqlParameter("@OldPassword", OldPassword),
                                                                                                        new SqlParameter("@NewPassword", EncryNewPassword),
                                                                                                        new SqlParameter("@IsOldPwdVerify", IsOldPwdVerify));

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
        return dsResultDetails;
    }

    #endregion "Reset Password"

    #region SMAPP Customer Service Retrun REquest
    /// <summary>
    /// SMAPP Customer Service Retrun REquest
    /// </summary>
    /// <returns></returns>
    public List<ReturnProductResponseDTO> SaveSMAPPReturnRequest(ReturnProductRequestDTO objRequest)
    {
        ReturnProductResponseDTO ReturnProd = null;
        List<ReturnProductResponseDTO> ReturnProductResponseList = new List<ReturnProductResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();
        DataSet dsRequest = new DataSet();

        try
        {
            dtLayer = new DataLayer();
            dsRequest = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(),
                CommandType.StoredProcedure,
                "dbo.spSMAPPSaveReturnRequest",
                new SqlParameter("@ProductCode", objRequest.ProductCode),
                new SqlParameter("@SerialNumber", objRequest.SerialNumber),
                new SqlParameter("@DealerName", objRequest.DealerName),
                new SqlParameter("@DealerCode", objRequest.DealerCode),
                new SqlParameter("@PurchaseDate", objRequest.PurchaseDate),
                new SqlParameter("@IssueReportedDate", objRequest.IssueReportedDate),
                new SqlParameter("@CustomerName", objRequest.CustomerName),
                new SqlParameter("@MoblieNumber", objRequest.MoblieNumber),
                new SqlParameter("@IssueID", objRequest.IssueID),
                new SqlParameter("@IssueRemarks", objRequest.IssueRemarks),
                new SqlParameter("@Remarks", objRequest.Remarks),
                new SqlParameter("@IsWithInWarranty", objRequest.IsWithInWarranty),
                new SqlParameter("@IsPhysicalCheck", objRequest.IsPhysicalCheck),
                new SqlParameter("@IsElectricalCheck", objRequest.IsElectricalCheck),
                new SqlParameter("@IsWebRequest", objRequest.IsWebRequest),
                new SqlParameter("@StatusID", objRequest.StatusID),
                new SqlParameter("@InvoiceFilePath", objRequest.InvoiceFilePath),
                new SqlParameter("@CreatedBy", objRequest.userId),
                new SqlParameter("@ReturnRequestType", objRequest.ReturnRequestType));

            ReturnProd = new ReturnProductResponseDTO();


            if (dsRequest != null && dsRequest.Tables.Count > 0 && dsRequest.Tables[0].Rows.Count > 0)
            {
                if (dsRequest.Tables[0].Rows[0]["ResultType"] != null && dsRequest.Tables[0].Rows[0]["ResultType"].ToString() != "")
                    ReturnProd.ResultType = dsRequest.Tables[0].Rows[0]["ResultType"].ToString();

                if (dsRequest.Tables[0].Rows[0]["ResultMessage"] != null && dsRequest.Tables[0].Rows[0]["ResultMessage"].ToString() != "")
                    ReturnProd.ResultMessage = dsRequest.Tables[0].Rows[0]["ResultMessage"].ToString();

                if (dsRequest.Tables[0].Rows[0]["RequestId"] != null && dsRequest.Tables[0].Rows[0]["RequestId"].ToString() != "")
                    ReturnProd.RequestId = dsRequest.Tables[0].Rows[0]["RequestId"].ToString();

                ReturnProductResponseList.Add(ReturnProd);
            }
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return ReturnProductResponseList;
    }

    /// <summary>
    /// Get Issue types master
    /// </summary>
    /// <param name="PartnerCode"></param>
    /// <returns>List<GetIssueTypesResponseDTO></returns>
    public List<GetIssueTypesResponseDTO> GetIssueTypesMaster()
    {
        GetIssueTypesResponseDTO objIssueType = null;
        List<GetIssueTypesResponseDTO> lstIssueType = new List<GetIssueTypesResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetSMAPPIssueMaster");

            while (dr.Read())
            {
                objIssueType = new GetIssueTypesResponseDTO();
                if (dr["IssueID"] != null && dr["IssueID"].ToString() != "")
                    objIssueType.IssueID = dr["IssueID"].ToString();

                if (dr["IssueType"] != null && dr["IssueType"].ToString() != "")
                    objIssueType.IssueType = dr["IssueType"].ToString();

                lstIssueType.Add(objIssueType);
            }
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return lstIssueType;
    }

    /// <summary>
    /// Check SMAPP User Access
    /// </summary>
    /// <param name="PartnerCode"></param>
    /// <returns>List<GetIssueTypesResponseDTO></returns>
    public List<SMAPPAccessResponseDTO> CheckSMAPPUserAccessRights(string strDealerCode, bool boolIsWebRequest)
    {
        SMAPPAccessResponseDTO objResponse = null;
        List<SMAPPAccessResponseDTO> lstResponse = new List<SMAPPAccessResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();

        try
        {
            dtLayer = new DataLayer();
            //var IsEligible = SqlHelper.ExecuteScalar(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetRequestReturnAccessRights",
            //                                                                                              new SqlParameter("@DealerCode", strUserId),
            //                                                                                              new SqlParameter("@IsWebRequest", boolIsWebRequest),

            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@IsEligible";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Bit;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;


            SqlHelper.ExecuteNonQuery(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetRequestReturnAccessRights",
                new SqlParameter("@DealerCode", strDealerCode),
                new SqlParameter("@IsWebRequest", boolIsWebRequest),
                outPutParameter
                );

            bool boolIsEligible = false;

            try
            {
                boolIsEligible = Convert.ToBoolean(outPutParameter.Value);
            }
            catch { }

            objResponse = new SMAPPAccessResponseDTO();

            if (boolIsEligible)
            {
                objResponse.ResultType = "success";
                objResponse.IsEligible = "true";
            }
            else
            {
                objResponse.ResultType = "failure";
                objResponse.IsEligible = "false";
            }

            lstResponse.Add(objResponse);
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return lstResponse;
    }

    /// <summary>
    /// Get product details
    /// </summary>
    /// <param name="PartnerCode"></param>
    /// <returns>List<GetIssueTypesResponseDTO></returns>
    public List<GetProductDetailResponseDTO> GetSMAPPProductsDetails()
    {
        GetProductDetailResponseDTO obj = null;
        List<GetProductDetailResponseDTO> lst = new List<GetProductDetailResponseDTO>();
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetSMAPPProductCode");

            while (dr.Read())
            {
                obj = new GetProductDetailResponseDTO();
                if (dr["ProductCode"] != null && dr["ProductCode"].ToString() != "")
                    obj.ProductCode = dr["ProductCode"].ToString();

                if (dr["MarketName"] != null && dr["MarketName"].ToString() != "")
                    obj.MarketName = dr["MarketName"].ToString();

                lst.Add(obj);
            }
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return lst;
    }

    // Added on 09-Sep-20
    public static byte[] Convertbytefromstream(Stream Input)
    {
        using (MemoryStream ms = new MemoryStream())
        {
            Input.Seek(0, SeekOrigin.Begin);

            Input.CopyTo(ms);
            return ms.ToArray();
        }
    }


    public string SMAPPSaveInvoice(Stream FileStream, string strFileName)
    {
        string imageExtension = string.Empty;
        byte[] imageByteArray = new byte[0];
        string result = string.Empty;
        string strFinalResult = string.Empty;

        string actualFileName = strFileName;
        string uploadDirectoryPath = ConfigurationManager.AppSettings["SMAPPInvoiceUrl"];
        SPPUtility objUtility = new SPPUtility();
        decimal filesize = 0;
        char[] strBlackListChars = { ':', ';', '<', '>', '%', '\'', '$' };
        bool hasInvalidChar = false;
        DataSet dsDBResultSession = new DataSet();
        string strAppPath = System.Web.Hosting.HostingEnvironment.ApplicationPhysicalPath;

        if (actualFileName.IndexOfAny(strBlackListChars) >= 0)
            hasInvalidChar = true;
        try
        {
            imageByteArray = Convertbytefromstream(FileStream);

            filesize = decimal.Round(Convert.ToDecimal(FileStream.Position) / (1024 * 1024), 2, MidpointRounding.AwayFromZero);

            // if dir path not exists, then create it
            string strDir = strAppPath + uploadDirectoryPath;
            if (!Directory.Exists(strDir))
                Directory.CreateDirectory(strDir);

            //if (imageExtension.Equals("jpg", StringComparison.OrdinalIgnoreCase) && filesize <= 5 && (hasInvalidChar == false))
            result = objUtility.UploadSMAPPFileOnServer(actualFileName, imageByteArray, uploadDirectoryPath);
        }
        catch (Exception ex)
        {
            objUtility.InsertintoErrorLog("Function - SMAPPSaveInvoice", ex.ToString(), "SMAPPModule SMAPPSaveInvoice",
                    Convert.ToInt16(SPPUtility._Sections.SMAPPModule), 1);
        }
        if (result.Contains("File uploaded"))
        {
            strFinalResult = "success";
        }
        else//WRITTING DOWN THE ELSE CONDITION TO AVOID UNECESSARY ISSUES.
        {
            dsDBResultSession = null;
        }
        return strFinalResult;
    }

    #endregion

    #region Order Booking With Payment Gateway Integration and Credit Management
    /// <summary>
    /// Get MDD list on the basis of dealer
    /// </summary>
    /// <param name="UserName"></param>
    /// <returns>List<GetSPPOrderBookAdvancePaymentMDDMappingResponseDTO></returns>
    public GetSPPOrderBookAdvancePaymentMDDMappingResponseDTO GetOrderBookingMDDMapping(string UserName)
    {
        GetSPPOrderBookAdvancePaymentMDDMappingResponseDTO objMDD = new GetSPPOrderBookAdvancePaymentMDDMappingResponseDTO();
        objMDD.mddlist = new List<MDDList>();
        MDDList objMDDlst = null;
        DataLayer dtLayer = null;
        SPPUtility objUtility = new SPPUtility();

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBPGGetMDDMapping", new SqlParameter("@UserName", UserName));

            while (dr.Read())
            {
                objMDDlst = new MDDList();
                if (dr["distcode"] != null && dr["distcode"].ToString() != "")
                    objMDDlst.distcode = dr["distcode"].ToString();

                if (dr["distname"] != null && dr["distname"].ToString() != "")
                    objMDDlst.distname = dr["distname"].ToString();

                objMDD.mddlist.Add(objMDDlst);
            }
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return objMDD;
    }

    /// <summary>
    /// Get Payment Mode List
    /// </summary>
    /// <param name="vMDDCode">MDDCode [In case of Type = 'PM'] </param> 
    /// <returns>GetSPPOrderBookPaymentModeListResponseDTO</returns>
    public GetSPPOrderBookPaymentModeListResponseDTO GetOrderBookingModeList(string vMDDCode)
    {
        GetSPPOrderBookPaymentModeListResponseDTO objML = new GetSPPOrderBookPaymentModeListResponseDTO();
        objML.paymentmode = new List<ModeList>();
        objML.paymentinstruction = new List<ModeInstruction>();
        ModeList objMode = null;
        ModeInstruction objInstruction = null;

        DataLayer dtLayer = null;

        SPPUtility objUtility = new SPPUtility();

        try
        {
            dtLayer = new DataLayer();
            SqlDataReader dr = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBPGGetPaymentMode"
                , new SqlParameter("@Type", "PM")
                , new SqlParameter("@MDDCode", vMDDCode));

            while (dr.Read())
            {
                objMode = new ModeList();
                if (dr["modeid"] != null && dr["modeid"].ToString() != "")
                    objMode.modeid = dr["modeid"].ToString();

                if (dr["modetext"] != null && dr["modetext"].ToString() != "")
                    objMode.modetext = dr["modetext"].ToString();

                objML.paymentmode.Add(objMode);
            }


            SqlDataReader dr1 = SqlHelper.ExecuteReader(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBPGGetPaymentMode"
                , new SqlParameter("@Type", "PMI")
                , new SqlParameter("@MDDCode", vMDDCode));
            int i = 1;
            while (dr1.Read())
            {
                objInstruction = new ModeInstruction();

                if (dr1["modetext"] != null && dr1["modetext"].ToString() != "")
                    objInstruction.instructiontext = dr1["modetext"].ToString().Replace("@@sn", i.ToString());

                objML.paymentinstruction.Add(objInstruction);
                i++;
            }
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }
        return objML;
    }

    /// <summary>
    /// Funtion to Get MDD details for ORder Payment;
    /// </summary>
    /// <param name="vMDDCode">Partner Code</param>
    /// <returns></returns>
    public DataTable GetOrderPaymentMDDDetails(string vMDDCode)
    {


        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBPGGetMDDDetails", new SqlParameter("@PartnerCode", vMDDCode)).Tables[0];

            return dt;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    /// <summary>
    /// Function to Insert Product Details
    /// Added by Shyam Sunder Kumar as on 01-May-2021
    /// </summary>
    /// <param name="vOrderNo">Order No</param>
    /// <param name="vSource">Source</param>
    /// <param name="vUserID">User ID</param>
    /// <param name="vLegalEntityCode">Legal Entity Code</param>
    /// <param name="vStoreID">Store ID</param>
    /// <param name="vIsPayment">Is Payment</param>
    /// <param name="vDealerCode">Dealer Code</param>
    /// <param name="vPaymentModeID">Payment ModeID [6 : Buy Using Credit Limit, 7 : Online Payment, 8 : Cash On Delivery (COD)]</param>
    /// <param name="vIsFinalSubmit">IsFinalSubmit</param>
    /// <param name="vProductDetails">Product Details</param>
    /// <returns>bool</returns>
    public bool InsertOrderDetails(string vOrderNo
    , string vSource
    , string vUserID
    , string vLegalEntityCode
    , string vStoreID
    , bool vIsPayment
    , string vDealerCode
    , string vPaymentModeID
    , bool vIsFinalSubmit
    , string vProductDetails
    , out int Status)
    {
        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBPGInsertOrderDetails",
                new SqlParameter("@OrderNo", vOrderNo),
                new SqlParameter("@Source", vSource),
                new SqlParameter("@UserID", vUserID),
                new SqlParameter("@LegalEntityCode", vLegalEntityCode),
                new SqlParameter("@StoreID", vStoreID),
                new SqlParameter("@IsPayment", vIsPayment),
                new SqlParameter("@DealerCode", vDealerCode),
                 new SqlParameter("@PaymentModeID", vPaymentModeID),
                  new SqlParameter("@IsFinalSubmit", vIsFinalSubmit),
                new SqlParameter("@ProductDetails", vProductDetails),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);

            Status = ires;
            if (ires == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }
    /// <summary>
    /// Insert DMS Next Message
    /// Added by Shyam Sunder Kumar as on 01-may-2021
    /// </summary>
    /// <param name="vMethodName">MethodName</param>
    /// <param name="vRequest">Request</param>
    /// <param name="vDealerCode">Dealer Code</param> 
    /// <param name="vDMSNextMessage">DMSNext Message</param> 
    /// <param name="vOrderNo">Order No</param>
    /// <param name="vMDDCode">MDD Code</param>
    /// <param name="vAmount">Amount</param>
    /// <returns></returns>
    public bool InsertDMSNextMessage(string vMethodName
   , string vRequest
   , string vDealerCode
   , string vDMSNextMessage
   , string vOrderNo
   , string vMDDCode
   , string vAmount
  )
    {
        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBPGInsertDMSNextMessage",
                new SqlParameter("@methodname", vMethodName),
                new SqlParameter("@Request", vRequest),
                new SqlParameter("@DealerCode", vDealerCode),
                new SqlParameter("@DMSNextMessage", vDMSNextMessage),
                new SqlParameter("@OrderNo", vOrderNo),
                new SqlParameter("@MDDCode", vMDDCode),
                new SqlParameter("@Amount", vAmount),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);


            if (ires == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }

    /// <summary>
    /// Update Order Details
    /// Added by Shyam Sunder Kumar as on 20-may-2021
    /// </summary>
    /// <param name="vOrderNo">OrderNo</param>
    /// <param name="vStatus">Status</param>
    /// <param name="vDealerCode">Dealer Code</param> 
    /// <param name="vGatewayOrderNumber">GatewayOrderNumber</param> 
    /// <returns></returns>
    public bool UpdateOrderDetails(string vOrderNo
   , string vStatus
   , string vDealerCode
   , string vGatewayOrderNumber
  )
    {
        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBPGUpdateOrderDetails",
                new SqlParameter("@OrderNo", vOrderNo),
                new SqlParameter("@Status", vStatus),
                new SqlParameter("@DealerCode", vDealerCode),
                new SqlParameter("@GatewayOrderNumber", vGatewayOrderNumber),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);


            if (ires == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }

    /// <summary>
    /// Funtion to Get Online Payment Charges
    /// </summary>
    /// <returns>DataTable</returns>
    public DataTable GetOnlinePaymentCharges()
    {


        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBPGGetOnlinePaymentCharges").Tables[0];

            return dt;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    /// <summary>
    /// Function to get Payment history
    /// Added by shyam Sunder Kumar as on 07-Sep-2021
    /// </summary>
    /// <param name="vDealerCode"></param>
    /// <param name="vMDDCode"></param>
    /// <returns></returns>
    public DataTable GetPaymentHistory(string vDealerCode, string vMDDCode)
    {


        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {

            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spOBDRTranReport",
                 new SqlParameter("@Filter", "1"),
                 new SqlParameter("@DealerCode", vDealerCode),
                 new SqlParameter("@MDDCode", vMDDCode),
                 new SqlParameter("@Month", "0"),
                 new SqlParameter("@Year", "0")
                ).Tables[0];

            return dt;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }
    /// <summary>
    /// Function to get Order details from Smart dost
    /// </summary>
    /// <param name="vStoreCode">Store Code / Dealer code</param>
    /// <param name="vOrderno">Orderno</param>
    /// <returns>DataTable</returns>
    public DataTable GetSmartDostOrderDetails(string vStoreCode, string vOrderno)
    {
        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSmartDostConnection(), CommandType.StoredProcedure, "spPendingOrderBooking_PG",
                new SqlParameter("@StoreCode", vStoreCode)
                , new SqlParameter("@PaymentStatus", "3")
                , new SqlParameter("@OrderNo", vOrderno)
                , new SqlParameter("@UserID", "1")
                , new SqlParameter("@Source", "")
                ).Tables[0];


            return dt;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }
    #endregion

    #region SPP Nepal Security Changes for Login
    //spp created new for get country code by name to security check 2022 march 23 start Amandeep singh
    /// <summary>
    /// Funtion to Get Country Code By User Name Charges [SPP_Nepal_Mearge]
    /// </summary>
    /// <returns>DataTable</returns>
    public bool IsCountryCodeValid(string UserName, string CountryCode)
    {
        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetCountryCodeByUserName", new SqlParameter("@UserName", UserName)).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                var userCountryCode = dt.Rows[0]["CountryCode"].ToString();
                if (userCountryCode == CountryCode)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    //spp created new for get country code by name to security check 2022 march 23 end Amandeep singh

    //spp created new for get country code by name to security check 2022 march 24 start Amandeep singh
    /// <summary>
    /// Funtion to Get Country Code By User Name Charges [SPP_Nepal_Mearge]
    /// </summary>
    /// <returns>DataTable</returns>
    public string GetCountryCodeByUserName(string UserName)
    {
        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetCountryCodeByUserName", new SqlParameter("@UserName", UserName)).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                var userCountryCode = dt.Rows[0]["CountryCode"].ToString();
                return userCountryCode;
            }
            return "";
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    //spp created new for get country code by name to security check 2022 march 24 end Amandeep singh

    //spp created new for validate captcha  2022 march 28 start Smariti
    /// <summary>
    /// Funtion to validate Captcha [SPP_Nepal_Mearge]
    /// </summary>
    /// <returns>DataTable</returns>
    public bool IsCaptchaValid(string UserName, string Captcha, string Token)
    {
        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@IsCaptchaValid";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Bit;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 1;

            dtLayer = new DataLayer();
            SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spIsCaptchaValid"
                , new SqlParameter("@UserName", UserName)
                , new SqlParameter("@Captcha", Captcha)
                , new SqlParameter("@Token", Token)
                , outPutParameter);
            bool vIsCaptchaValid = Convert.ToBoolean(outPutParameter.Value);

            return vIsCaptchaValid;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    //spp created new for validate captcha 2022 march 28 end Smariti 

    //spp created new for get captcha security check 2022 march 28 start Smariti
    /// <summary>
    /// Funtion to Get Captcha [SPP_Nepal_Mearge]
    /// </summary>
    /// <returns>DataTable</returns>
    public CaptchaParamResponseDTO GetCaptcha(string UserName, string Captcha, string Token)
    {
        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        CaptchaParamResponseDTO objCaptchaParam = new CaptchaParamResponseDTO();
        try
        {

            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetCaptcha"
                , new SqlParameter("@UserName", UserName)
                , new SqlParameter("@Captcha", Captcha)
                , new SqlParameter("@Token", Token)).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                var captcha = dt.Rows[0]["Captcha"].ToString();
                var token = dt.Rows[0]["Token"].ToString();
                var username = dt.Rows[0]["UserName"].ToString();
                objCaptchaParam.captcha = captcha;
                objCaptchaParam.token = token;
                objCaptchaParam.userid = username;
                return objCaptchaParam;
            }
            return objCaptchaParam;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    //spp created new for get captcha security check 2022 march 28 end Smariti

    //spp created new for checking captcha required or not
    /// <summary>
    /// Funtion to check captcha required or not [SPP_Nepal_Mearge]
    /// </summary>
    /// <returns>DataTable</returns>
    public bool IsCaptchaRequired(string UserName)
    {
        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@IsCaptchaRequired";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Bit;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 1;

            dtLayer = new DataLayer();
            SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spIsCaptchaRequired"
                , new SqlParameter("@UserName", UserName)
                , outPutParameter);
            bool vIsCaptchaRequired = Convert.ToBoolean(outPutParameter.Value);
            return vIsCaptchaRequired;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    //spp created new for get captcha security check 2022 march 30 start Amandeep Singh
    /// <summary>
    /// Funtion to Get Captcha [SPP_Nepal_Mearge]
    /// </summary>
    /// <returns>DataTable</returns>
    public bool SaveTokenForAppVersion(string Token, string HashKey)
    {
        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSaveTokenForAppVersion",
                new SqlParameter("@Token", Token),
                new SqlParameter("@HashKey", HashKey),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);


            if (ires == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }

    //Added by Amandeep singh on 31 march for security changes start

    /// <summary>
    /// Function to Get GetAuthAppVersionByToken [SPP_Nepal_Mearge]
    /// </summary>
    /// <param name="vSKUCode">SKU Code</param>
    /// <param name="vDMSCode">DMS Code</param>
    /// <returns>DataTable</returns>
    public string GetAuthAppVersionByToken(string appVersionToken)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProductList = new DataSet();
        try
        {
            dsProductList = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetAuthAppVersionByToken"
                , new SqlParameter("@Token", appVersionToken));
            DataTable dt = dsProductList.Tables[0];
            string hash = "";
            if (dt.Rows.Count > 0)
            {
                hash = dt.Rows[0]["HashKey"].ToString();
            }
            return hash;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (dsProductList != null)
            {
                dsProductList = null;
            }
        }

    }
    //Added by Amandeep singh on 31 march for security changes  end
    /// <summary>
    /// Function to Get spGetCountryMasterData
    /// </summary>
    /// <param name="vSKUCode">SKU Code</param>
    /// <param name="vDMSCode">DMS Code</param>
    /// <returns>DataTable</returns>
    public string GetCountryMasterData(string CountryCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsCountryCode = new DataSet();
        try
        {
            dsCountryCode = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetCountryMasterData"
                , new SqlParameter("@CountryCode", CountryCode));
            DataTable dt = dsCountryCode.Tables[0];
            string currencyCode = "";
            if (dt.Rows.Count > 0)
            {
                currencyCode = dt.Rows[0]["CurrencyCode"].ToString();
            }
            return currencyCode;
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

            if (dsCountryCode != null)
            {
                dsCountryCode = null;
            }
        }

    }


    //spp created new for get captcha security check 2022 march 28 end Smariti
    #endregion SPP Nepal Security Changes for Login

    #region Sell Out Upload in SPP Mobile App 
    public DataTable GetCustDetailsApplicability()
    {
        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSOUGetCustDetailsApplicability").Tables[0];

            return dt;
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }
    #endregion

    #region  ADS Integration

    /// <summary>
    /// Function to Update ADS Details
    /// Added by as on 21-Jun-2022
    /// </summary>
    /// <param name="vMode">Mode</param>
    /// <param name="vDealerCode">Dealer Code</param>
    /// <param name="vPANNo">PAN No</param>
    /// <param name="vPANFile">PAN File</param>
    /// <param name="vGSTNo">GST No</param>
    /// <param name="vGSTFile">GST File</param>
    /// <param name="vSource">Source</param>
    /// <returns>bool</returns>
    public bool UpdateADSDetails(string vMode
   , string vDealerCode
   , string vPANNo
   , string vPANFile
   , string vGSTNo
   , string vGSTFile
   , string vSource
  )
    {
        int ires = 0;
        DataLayer objDataLayer = new DataLayer();
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spADSUpdateDocument",
                 new SqlParameter("@Mode", vMode),
                new SqlParameter("@DealerCode", vDealerCode),
                new SqlParameter("@PANNo", vPANNo),
                new SqlParameter("@PANFile", vPANFile),
                new SqlParameter("@GSTNo", vGSTNo),
                new SqlParameter("@Source", vSource),
                new SqlParameter("@GSTFile", vGSTFile),
                outPutParameter
                );
            ires = Convert.ToInt16(outPutParameter.Value);

            if (ires == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
    }

    /// <summary>
    /// Function to Get ADS Message
    /// Added by as on 22-Jun-2022 
    /// </summary>
    /// <param name="vMessageID">string</param>
    /// <returns>string</returns>
    public string GetADSMessage(string vMessageID)
    {
        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spADSGetMessage", new SqlParameter("@MessageID", vMessageID)).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                var userCountryCode = dt.Rows[0]["MessageValue"].ToString();
                return userCountryCode;
            }
            return "";
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }

    /// <summary>
    /// Function to check ADS Accessebality
    /// Added by Shyam Sunder Kumar as on 30-06-2022
    /// </summary>
    /// <param name="vDealerCode">Dealer Code</param>
    /// <param name="vMode">1 for Buyback, 2 for ADS Users </param>
    /// <returns></returns>
    public bool IsAdsAccess(string vDealerCode, string vMode)
    {
        DataLayer dtLayer = null;
        DataTable dt = new DataTable();
        try
        {
            dtLayer = new DataLayer();
            dt = SqlHelper.ExecuteDataset(dtLayer.GetSPPConnection(), CommandType.StoredProcedure, "spADSBuyProductAccess", new SqlParameter("@DealerCode", vDealerCode)
                , new SqlParameter("@Mode", vMode)).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                if (dt.Rows[0]["IsAccess"].ToString() == "1")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }

        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (dtLayer != null)
                dtLayer = null;

        }

    }
    #endregion

    #region Two Factor Authentication
    /// <summary>
    /// To save Login OTO.
    /// </summary>
    /// <param name="userid"></param>
    /// <param name="LoginOtop"></param>
    public void AddLoginOtp(string sUserId, string sLoginOtop)
    {
        DataLayer objDataLayer = new DataLayer();

        try
        {


            SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spAddLoginOtp",
                                                                                                            new SqlParameter("@UserID", sUserId),
                                                                                                            new SqlParameter("@LoginOtp", sLoginOtop));


        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {

        }
    }
    /// <summary>
    /// Name      : Get Mobile Detail
    /// CreatedBy : Amit Kumar Singh
    /// CreatedOn : 01 Sept 2022
    /// Perameter : N/A
    /// Output    : N/A
    /// Pupose    : Get Partner mobile No
    /// </summary>
    /// <returns></returns>
    public string GetMobileNo(string sUserId)
    {
        DataSet dsMobileDetail = null;
        string sMobileNo = string.Empty;
        DataLayer objDataLayer = new DataLayer();

        try
        {


            dsMobileDetail = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMobileNo",
                                                                                                           new SqlParameter("@UserID", sUserId));


            if (dsMobileDetail != null && dsMobileDetail.Tables.Count > 0 && dsMobileDetail.Tables[0].Rows.Count > 0)
            {
                sMobileNo = dsMobileDetail.Tables[0].Rows[0]["MobileNo"].ToString();
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (dsMobileDetail != null)
            {
                dsMobileDetail = null;
            }
        }
        return sMobileNo;
    }

    /// <summary>
    //  Name      : Get Otp Sender Type
    /// CreatedBy : Amit Kumar Singh
    /// CreatedOn : 20 March  2023
    /// Pupose    : Get Otp Sender Type
    /// </summary>
    /// <param name="sCountryCode"></param>
    /// <returns></returns>
    public string GetOtpSenderType(string sCountryCode)
    {
        DataSet dsOtpSenderType = null;
        string sSenderType = string.Empty;
        DataLayer objDataLayer = new DataLayer();

        try
        {


            dsOtpSenderType = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetOtpSenderType",
                                                                                                           new SqlParameter("@CountryCode", sCountryCode));


            if (dsOtpSenderType != null && dsOtpSenderType.Tables.Count > 0 && dsOtpSenderType.Tables[0].Rows.Count > 0)
            {
                sSenderType = dsOtpSenderType.Tables[0].Rows[0]["SenderType"].ToString();
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (dsOtpSenderType != null)
            {
                dsOtpSenderType = null;
            }
        }
        return sSenderType;
    }

    /// <summary>
    //  Name      : Get Email Id
    /// CreatedBy : Amit Kumar Singh
    /// CreatedOn : 20 March  2023
    /// Pupose    : Get Email Id
    /// </summary>
    /// <param name="sUserId"></param>
    /// <returns></returns>
    public string GetEmailId(string sUserId)
    {
        DataSet dsEmail = null;
        string sEmailId = string.Empty;
        DataLayer objDataLayer = new DataLayer();

        try
        {


            dsEmail = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetEmailId",
                                                                                                           new SqlParameter("@UserId", sUserId));


            if (dsEmail != null && dsEmail.Tables.Count > 0 && dsEmail.Tables[0].Rows.Count > 0)
            {
                sEmailId = dsEmail.Tables[0].Rows[0]["Email"].ToString();
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (dsEmail != null)
            {
                dsEmail = null;
            }
        }
        return sEmailId;
    }


    /// <summary>
    /// Name      : GetKeysValue
    /// CreatedBy : Amit Kumar Singh
    /// CreatedOn : 01 Sept 2022
    /// Perameter : N/A
    /// Output    : N/A
    /// Pupose    : Get Key Values detail
    /// </summary>
    /// <returns></returns>
    public string GetKeysValue(string ConfigType)
    {
        DataSet dsConfigValue = null;
        string sCOnfigValue = string.Empty;
        DataLayer objDataLayer = new DataLayer();

        try
        {

            dsConfigValue = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetOtpSMSText",
                                                                                                new SqlParameter("@ConfigType", ConfigType));



            if (dsConfigValue != null && dsConfigValue.Tables.Count > 0 && dsConfigValue.Tables[0].Rows.Count > 0)
            {
                sCOnfigValue = dsConfigValue.Tables[0].Rows[0]["ConfigValue"].ToString();
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (dsConfigValue != null)
            {
                dsConfigValue = null;
            }
        }
        return sCOnfigValue;
    }
    public DataSet ValidateLoginOtp(string sUserId, string sOtp)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsValidateOtp = new DataSet();
        try
        {
            dsValidateOtp = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetOtpStatus",
                                                                                                                        new SqlParameter("@UserID", sUserId),
                                                                                                                        new SqlParameter("@OTP", sOtp));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
                objDataLayer = null;
        }
        return dsValidateOtp;
    }
    public string GetSAARCCountryCodeByPartnerId(string _strUser)
    {
        int ProcAction = 1;//SENDING 1 TO GET SAARC USER DETAILS
        DataLayer objDataLayer = new DataLayer();
        DataSet dsUser = new DataSet();
        string countrycode = string.Empty;
        try
        {
            dsUser = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spSAARCGetUserDetails",
                                                                                         new SqlParameter("@PartnerCode", _strUser)
                                                                                         , new SqlParameter("@ProcAction", ProcAction));

            if (dsUser != null && dsUser.Tables.Count > 0 && dsUser.Tables[0].Rows.Count > 0)
            {
                countrycode = dsUser.Tables[0].Rows[0]["COUNTRYCODE"].ToString();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
                objDataLayer = null;
        }
        return countrycode;
    }
    public DataSet GetOtpEnableStatus(string sCountryCode)
    {

        DataLayer objDataLayer = new DataLayer();
        DataSet dsStatus = new DataSet();
        string countrycode = string.Empty;
        try
        {
            dsStatus = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetOtpEnableStatus",
                                                                                         new SqlParameter("@CountryCode", sCountryCode));

        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
                objDataLayer = null;
        }
        return dsStatus;
    }
    public bool SendOTP(string sMobileNo, string sMessage, string sCountryCode, string sDivisionCode)
    {
        DataTable DtSmsSetting = GetSMSSettings(sCountryCode, sDivisionCode);
        string sSendUrl = DtSmsSetting.Rows[0]["SmsApiUrl"].ToString();
        if (SendFinalMessage(sSendUrl, sMobileNo, sMessage, sCountryCode))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    private DataTable GetSMSSettings(string sCountryCode, string sDivisionCode)
    {
        DataLayer objDataLayer = new DataLayer();
        return SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetSmsSettings",
                                                                                                        new SqlParameter("@CountryCode", sCountryCode),
                                                                                                        new SqlParameter("@DivisionCode", sDivisionCode)).Tables[0];

    }
    public bool SendFinalMessage(string smsApiSetting, string sMobileNo, string sMessage, string sCountryCode)
    {
        bool SentStatus = false;
        string sStatusCode = string.Empty;
        string sResponseMsg = string.Empty;
        string sSuccessCode = string.Empty;
        //BusinessLayer objBiz = new BusinessLayer();
        try
        {
            string[] arrSMSTo = sMobileNo.Split(new char[] { ',' });
            for (int i = 0; i < arrSMSTo.Length; i++)
            {
                if (arrSMSTo[i].Length > 0)
                {
                    string SMS_MId_ErrorCode = string.Empty;
                    try
                    {
                        if (arrSMSTo[i].ToString() != "NoMobileNumber" && arrSMSTo[i].ToString() != "")
                        {
                            string url = smsApiSetting;
                            if (sCountryCode == "IND")
                            {
                                // url = url + "&destination=" + arrSMSTo[i].ToString() + "&message=" + sMessage;
                                //Changes for Karix API Implementation
                                url = url + "&dest=" + arrSMSTo[i].ToString() + "&text=" + sMessage;
                            }
                            else if (sCountryCode == "NPL")
                            {
                                url = url + "&to=" + arrSMSTo[i].ToString() + "&text=" + sMessage;
                            }
                            else if (sCountryCode == "BGD")
                            {
                                url = url + "&msisdn=880" + arrSMSTo[i].ToString() + "&sms=" + sMessage;
                            }
                            else if (sCountryCode == "LKA")
                            {
                                //Changed By Amit Singh for Lanka SMS API on 15th March 2023
                                url = url + "&dst=" + arrSMSTo[i].ToString() + "&msg=" + sMessage;
                            }

                            SMS_MId_ErrorCode = SendSMSToPartner(url);

                            if (sCountryCode.ToUpper() == "IND")
                            {
                                //Change By Amit Singh to Capture Full Response Message
                                sStatusCode = null;
                                sResponseMsg = SMS_MId_ErrorCode;
                                //string[] SendStatus = SMS_MId_ErrorCode.Split(new char[] { '&' });
                                //sStatusCode = SendStatus[0].ToString();
                                //sResponseMsg = SendStatus[1].ToString();
                                //Changes for Karix API Implementation
                                //sResponseMsg = SendStatus[0].ToString();
                                //sStatusCode = SendStatus[1].ToString();
                                //string[] sStatusCodeIND = sStatusCode.Split(new char[] { '=' });
                                //sStatusCode = sStatusCodeIND[1].ToString().Trim();

                            }
                            if (sCountryCode.ToUpper() == "LKA")
                            {
                                //Change By Amit Singh to Capture Full Response Message
                                sStatusCode = null;
                                sResponseMsg = SMS_MId_ErrorCode;
                                //Changed By Amit Singh for Lanka SMS API on 15th March 2023
                                //string[] SendStatus = SMS_MId_ErrorCode.Split(new char[] { ':' });
                                //sResponseMsg = SendStatus[1].ToString();
                                //sStatusCode = SendStatus[0].ToString().Trim();

                            }
                            if (sCountryCode.ToUpper() == "NPL")
                            {
                                //Change By Amit Singh to Capture Full Response Message
                                sStatusCode = null;
                                sResponseMsg = SMS_MId_ErrorCode;
                                //string Error = string.Empty;
                                //JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                                //SMSResponseDTO requote_list = json_serializer.Deserialize<SMSResponseDTO>(SMS_MId_ErrorCode);
                                //SPPSMSDataResponse _obj = new SPPSMSDataResponse();
                                //Error = requote_list.error;
                                //_obj = requote_list.data;
                                //if (Error == "False")
                                //{
                                //    sStatusCode = "False";
                                //    List<SPPSMSValidDataResponse> lstValid = new List<SPPSMSValidDataResponse>();
                                //    lstValid = _obj.valid;
                                //    if (lstValid.Count > 0)
                                //    {
                                //        string sResponseId = lstValid[0].id;
                                //        string sMobile = lstValid[0].mobile;
                                //        sResponseMsg = sMobile + ":" + sResponseId;
                                //    }
                                //}
                                //else
                                //{
                                //    sStatusCode = "True";
                                //    List<SPPSMSInValidDataResponse> lstInValid = new List<SPPSMSInValidDataResponse>();
                                //    lstInValid = _obj.invalid;
                                //    if (lstInValid.Count > 0)
                                //    {
                                //        string sResponseId = lstInValid[0].status;
                                //        string sMobile = lstInValid[0].mobile;
                                //        sResponseMsg = sMobile + ":" + sResponseId;
                                //    }
                                //}

                            }
                            if (sCountryCode.ToUpper() == "BGD")
                            {
                                //Change By Amit Singh to Capture Full Response Message
                                sStatusCode = null;
                                sResponseMsg = SMS_MId_ErrorCode;
                                //JavaScriptSerializer json_serializer = new JavaScriptSerializer();
                                //SMSResponseBanDTO requote_list = json_serializer.Deserialize<SMSResponseBanDTO>(SMS_MId_ErrorCode);
                                //sStatusCode = requote_list.status_code;
                                //if (requote_list.smsinfo != null && requote_list.smsinfo.Count > 0)
                                //{
                                //    sResponseMsg = requote_list.smsinfo[0].msisdn + ":" + requote_list.smsinfo[0].reference_id;
                                //}
                                //else
                                //{
                                //    sResponseMsg = sMobileNo + ":" + requote_list.error_message;
                                //}
                            }


                            //DataSet dsOtpSuccessCode = new DataSet();
                            //dsOtpSuccessCode = GetOtpEnableStatus(sCountryCode);
                            //if (dsOtpSuccessCode != null && dsOtpSuccessCode.Tables.Count > 0 && dsOtpSuccessCode.Tables[0].Rows.Count > 0)
                            //{
                            //    sSuccessCode = dsOtpSuccessCode.Tables[0].Rows[0]["OtpSuccessCode"].ToString();
                            //}

                            //if (sStatusCode == sSuccessCode)
                            //{
                            //    SentStatus = true;
                            //}
                            //else
                            //{
                            //    SentStatus = false;
                            //}
                            SentStatus = true;
                            AddSmsOtpLog(arrSMSTo[i].ToString(), sStatusCode, sResponseMsg);
                        }
                    }
                    catch (Exception ee)
                    {
                        SentStatus = false;
                        AddSmsOtpLog(arrSMSTo[i].ToString(), sStatusCode, sResponseMsg);
                    }

                }
            }
        }
        catch (Exception Ex)
        {
            SentStatus = false;
        }
        return SentStatus;
    }
    public void AddSmsOtpLog(string sMobileNo, string sStatusCode, string sResponseMsg)
    {
        DataLayer objDataLayer = new DataLayer();
        SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spAddSmsOtpLog",
          new SqlParameter("@MobileNo", sMobileNo),
          new SqlParameter("@ResponseCode", sStatusCode),
           new SqlParameter("@ResponseMsg", sResponseMsg));
    }
    public string SendSMSToPartner(string url)
    {
        HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
        HttpWebResponse response = (HttpWebResponse)request.GetResponse();
        Stream stream = response.GetResponseStream();
        StreamReader sr = new StreamReader(stream);
        String ResponseStr = sr.ReadToEnd();
        return ResponseStr;
    }
    #endregion
    public DataSet GetCEHPPDealerCodeList(string userid,string type)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet ds = new DataSet();
        try
        {
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetCEHHPDealerCode",
                                                        new SqlParameter("@UserID", userid), new SqlParameter("@Flag", "SPP")
                                                        ,new SqlParameter("@type", type));
        }
        catch (Exception ex)
        {
            throw ex;

        }
        finally
        {
            if (objDataLayer != null)
                objDataLayer = null;
        }
        return ds;

    }
    #region Get CE HPP DealerCode for SEC User
    public DataSet GetCEHPPDealerCodeListForSECUser(string userid)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet ds = new DataSet();
        try
        {
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetCEHHPDealerCodeForSECUser",
                                                        new SqlParameter("@UserID", userid), new SqlParameter("@Flag", "SPP"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
                objDataLayer = null;
        }
        return ds;

        }
    #endregion
    public DataSet GetSelloutUploadReport(string userid,string dealercode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet ds = new DataSet();
        try
        {
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetMCSConnection(), CommandType.StoredProcedure, "spCrossSellIncentiveDataForSEC",
                                                                                                        new SqlParameter("@SEC", userid),
                                                                                                        new SqlParameter("@Dealer", dealercode)
                                                                                                        );
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
        }
        }
        return ds;

    }

    #region MR/RRF SmartTool Management
    /// <summary>
    /// Function to Get MR/RRF SmartTool Management filter data
    /// Added by Shyam Sunder Kumar as on 12-Jul-2023
    /// </summary>
    /// <param name="vDistCode">Dealer Code</param>
    /// <returns>DataSet</returns>
    public DataSet MRRRFGetFilterData(string vDistCode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet ds = new DataSet();
        try
        {
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMRSMGetReportFilterData",
                new SqlParameter("@DistCode", vDistCode));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
                objDataLayer = null;
        }
        return ds;
    }

    /// <summary>
    /// Function to Get MR/RRF SmartTool Management Report data
    /// Added by Shyam Sunder Kumar as on 12-Jul-2023
    /// </summary>
    /// <param name="vDistCode">Dealer Code</param>
    /// <param name="vFilterValue">Filter Value</param>
    /// <returns>DataSet</returns>
    public DataSet MRRRFGetReportData(string vDistCode, string vFilterValue)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet ds = new DataSet();
        try
        {
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMRSMGetReportReportData",
                new SqlParameter("@DistCode", vDistCode),
                new SqlParameter("@FilterValue", vFilterValue));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
                objDataLayer = null;
        }
        return ds;
    }
    #endregion

    #region Module Tracking
    public int SPPInsertModuleTrackingVisitLog(string vMenuID, string vMenuType, string vMenuName, string vUserID,string vAPIKey, string vAPIToken)
    {
        DataLayer objDataLayer = new DataLayer();
        int ires = 0;
        try
        {
            SqlParameter outPutParameter = new SqlParameter();
            outPutParameter.ParameterName = "@OutputStatus";
            outPutParameter.SqlDbType = System.Data.SqlDbType.Int;
            outPutParameter.Direction = System.Data.ParameterDirection.Output;
            outPutParameter.Size = 4;

            ires = Convert.ToInt32(SqlHelper.ExecuteNonQuery(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spMTInsertVisitLog",
                      new SqlParameter("@MenuID", vMenuID),
                      new SqlParameter("@MenuType", vMenuType),
                      new SqlParameter("@MenuName", vMenuName),
                      new SqlParameter("@UserID", vUserID),
                      new SqlParameter("@APIKey", vAPIKey),
                      new SqlParameter("@APIToken", vAPIToken),
                      outPutParameter
                      ));
            ires = Convert.ToInt16(outPutParameter.Value.ToString());
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }

        }
        return ires;
    }
    #endregion

    #region Save common sellout upload details
    public DataTable SaveCommonSelloutDatails(string partnerCode, string SecCode, string Division, string Source,DataTable dtUploadDetails)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet dsProduct = new DataSet();
        try
        {
            SqlConnection con = new SqlConnection(objDataLayer.GetS2P2Connection());
            con.Open();
            SqlCommand com = new SqlCommand();
            com.Connection = con;
            com.CommandType = CommandType.StoredProcedure;
            com.CommandText = "spSaveCommonSelloutDatails";
            com.CommandTimeout = 600;
            com.Parameters.AddWithValue("@DealerCode", partnerCode);
            com.Parameters.AddWithValue("@SecCode", SecCode);            
            com.Parameters.AddWithValue("@Division", Division);
            com.Parameters.AddWithValue("@Source", Source);
            com.Parameters.AddWithValue("@UploadDetails", dtUploadDetails);
            SqlDataAdapter da = new SqlDataAdapter(com);
            da.Fill(dsProduct);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
        return dsProduct.Tables[0];
    }

    public DataSet GetSECMappedDealerList(string seccode)
    {
        DataLayer objDataLayer = new DataLayer();
        DataSet ds = new DataSet();
        try
        {
            ds = SqlHelper.ExecuteDataset(objDataLayer.GetSPPConnection(), CommandType.StoredProcedure, "spGetMappedMutlipleDealerCodeForSecUser",
                                                                                                        new SqlParameter("@SecCode", seccode));
        }
        catch (Exception ex)
        {
            throw ex;
        }
        finally
        {
            if (objDataLayer != null)
            {
                objDataLayer = null;
            }
        }
        return ds;
    }
    #endregion

}

#region DELEGATE Digital signature

public delegate void PdfGenerate_Delegate(string newfilename, string Name, string pdffilename, string Attachment, string sCustomerName, string delarname, string Mobile, string DealerCode);
public delegate void VerifiedProfileEmail(SPPSaveProfileRequestDTO Jsoninput, SPPUtility objUtility, string verificationCode);
#endregion
#region MyReward Delegate
public delegate void MyReward_Delegate(string Name, string mobile, string email, string dealercode, List<string> listRequestID);
public delegate void DelegateSendOTP(string userid, string token, DataTable dt);
public delegate void DelegateSendSMS(string userid, string smsmsg, string mobile);
#endregion

public class Dialog
{
    public string configurationid { get; set; }
    public string configurationimage { get; set; }
    public string termandcondition { get; set; }
    public string termconditiondetails { get; set; }
    public string isshowterm { get; set; }
    public string isupgrademenu { get; set; }
    public string isshowagree { get; set; }
    public string agreebuttontext { get; set; }
    public string agreebuttonvisible { get; set; }
    public string disagreebuttontext { get; set; }
    public string disagreebuttonvisible { get; set; }
}