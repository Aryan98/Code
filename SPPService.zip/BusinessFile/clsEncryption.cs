//using Microsoft.VisualBasic;
//using System;
//using System.IO;
//using System.Xml;
//using System.Text;
//using System.Security.Cryptography;
//using System.Web;
//using System.Web.Security;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.Web.UI.WebControls.WebParts;
//using System.Web.UI.HtmlControls;
//public class clsEncryption
//{
//    public clsMain objMain = new clsMain();
//    private byte[] key = { };
//    private byte[] IV = { 18, 52, 86, 120, 144, 171, 205, 239 };

//    public string Decrypt(string stringToDecrypt)
//    {
//        stringToDecrypt = stringToDecrypt.Replace(" ", "+");
//        string sEncryptionKey = "!*&@9876543210";
//        byte[] inputByteArray = new byte[stringToDecrypt.Length + 1];
//        clsSecurityCheck objSecurity = new clsSecurityCheck();
//        try
//        {
//            key = System.Text.Encoding.UTF8.GetBytes(sEncryptionKey.Substring(0, 8));
//            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
//            inputByteArray = Convert.FromBase64String(stringToDecrypt);
//            MemoryStream ms = new MemoryStream();
//            CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(key, IV), CryptoStreamMode.Write);
//            cs.Write(inputByteArray, 0, inputByteArray.Length);
//            cs.FlushFinalBlock();
//            System.Text.Encoding encoding = System.Text.Encoding.UTF8;
//            return encoding.GetString(ms.ToArray());
//        }
//        catch (Exception e)
//        {

//            bool ErrorInserted = objSecurity.InsertintoErrorLog("Function - Decrypt", e.Message+"||"+e.Source+"||"+e.InnerException.StackTrace+"||"+e.StackTrace,
//              "clsEncryption.cs", 0);

//            HttpContext.Current.Response.Redirect("Default.aspx?Mode=Logout", false);
//            return e.Message;
            
//        }
//    }

//    public string Encrypt(string stringToEncrypt)
//    {
//        clsSecurityCheck objSecurity = new clsSecurityCheck();
//        try
//        {
            
//            string SEncryptionKey = "!*&@9876543210";
//            key = System.Text.Encoding.UTF8.GetBytes(SEncryptionKey.Substring(0, 8));
//            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
//            byte[] inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
//            MemoryStream ms = new MemoryStream();
//            CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(key, IV), CryptoStreamMode.Write);
//            cs.Write(inputByteArray, 0, inputByteArray.Length);
//            cs.FlushFinalBlock();
//            return Convert.ToBase64String(ms.ToArray());
//        }
//        catch (Exception e)
//        {
           
//            HttpContext.Current.Response.Redirect("~/Logout.aspx", false);
//            return e.Message;
//        }
//    }

//}