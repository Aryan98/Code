﻿using System;
using System.Configuration;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using SPPWebService.SPP;

public class DataLayer
{
    static private Byte[] m_Key = new Byte[8];
    static private Byte[] m_IV = new Byte[8];
    private static readonly byte[] salt = Encoding.ASCII.GetBytes("Ent3r your oWn S@lt v@lu# h#r3");

    #region Samsung Smart Partner Portal

   

    public string GetMCSConnection()
    {
        // string conString = ConfigurationManager.AppSettings["S2P2Connection"].ToString();
        string conString = ConfigurationManager.ConnectionStrings["MCSConnection"].ConnectionString;
        conString = (new SPPUtility()).Decrypt(conString);       
        return conString;
    }
    public string GetMCSConnectionTest()
    {
        // string conString = ConfigurationManager.AppSettings["S2P2Connection"].ToString();
        string conString = ConfigurationManager.ConnectionStrings["MCSConnectionTest"].ConnectionString;
        conString = (new SPPUtility()).Decrypt(conString);
        return conString;
    }
    private static RijndaelManaged GetAlgorithm(string encryptionPassword)
    {


        // Create an encryption key from the encryptionPassword and salt.
        var key = new Rfc2898DeriveBytes(encryptionPassword, salt);

        // Declare that we are going to use the Rijndael algorithm with the key that we've just got.
        var algorithm = new RijndaelManaged();
        int bytesForKey = algorithm.KeySize / 8;
        int bytesForIV = algorithm.BlockSize / 8;
        algorithm.Key = key.GetBytes(bytesForKey);
        algorithm.IV = key.GetBytes(bytesForIV);
        return algorithm;
    }
    private static byte[] InMemoryCrypt(byte[] data, ICryptoTransform transform)
    {
        MemoryStream memory = new MemoryStream();
        using (Stream stream = new CryptoStream(memory, transform, CryptoStreamMode.Write))
        {
            stream.Write(data, 0, data.Length);
        }
        return memory.ToArray();
    }

    ///// <summary>
    ///// Name:DecryptData
    ///// when:24-May-2013
    ///// why : To  Decrypt Data which Is Encrypted
    ///// Argument: key value and Encrypted Data
    ///// </summary>
    ///// <param name="strKey"></param>
    ///// <param name="strData"></param>
    ///// <returns></returns>
    public string DecryptData(String strData)
    {
        string strResult;
        String strKey = "samsung";

        //1. Generate the Key used for decrypting
        if (!InitKey(strKey))
        {
            strResult = "Error. Fail to generate key for decryption";
            return strResult;
        }

        //2. Initialize the service provider
        int nReturn = 0;
        DESCryptoServiceProvider descsp = new DESCryptoServiceProvider();
        ICryptoTransform desDecrypt = descsp.CreateDecryptor(m_Key, m_IV);

        //3. Prepare the streams:
        //	mOut is the output stream. 
        //	cs is the transformation stream.
        MemoryStream mOut = new MemoryStream();
        CryptoStream cs = new CryptoStream(mOut, desDecrypt, CryptoStreamMode.Write);

        //4. Remember to revert the base64 encoding into a byte array to restore the original encrypted data stream
        byte[] bPlain = new byte[strData.Length];
        try
        {
            bPlain = Convert.FromBase64CharArray(strData.ToCharArray(), 0, strData.Length);
        }
        catch (Exception)
        {
            strResult = "Error. Input Data is not base64 encoded.";
            return strResult;
        }

        long lRead = 0;
        long lTotal = strData.Length;

        try
        {
            //5. Perform the actual decryption
            while (lTotal >= lRead)
            {
                cs.Write(bPlain, 0, (int)bPlain.Length);
                //descsp.BlockSize=64
                lRead = mOut.Length + Convert.ToUInt32(((bPlain.Length / descsp.BlockSize) * descsp.BlockSize));
            };

            ASCIIEncoding aEnc = new ASCIIEncoding();
            strResult = aEnc.GetString(mOut.GetBuffer(), 0, (int)mOut.Length);

            //6. Trim the string to return only the meaningful data
            //	Remember that in the encrypt function, the first 5 character holds the length of the actual data
            //	This is the simplest way to remember to original length of the data, without resorting to complicated computations.
            String strLen = strResult.Substring(0, 5);
            int nLen = Convert.ToInt32(strLen);
            strResult = strResult.Substring(5, nLen);
            nReturn = (int)mOut.Length;

            return strResult;
        }
        catch (Exception)
        {
            strResult = "Error. Decryption Failed. Possibly due to incorrect Key or corrputed data";
            return strResult;
        }
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="strKey"></param>
    /// <returns></returns>
    static private bool InitKey(String strKey)
    {
        try
        {
            // Convert Key to byte array
            byte[] bp = new byte[strKey.Length];
            ASCIIEncoding aEnc = new ASCIIEncoding();
            aEnc.GetBytes(strKey, 0, strKey.Length, bp, 0);

            //Hash the key using SHA1
            SHA1CryptoServiceProvider sha = new SHA1CryptoServiceProvider();
            byte[] bpHash = sha.ComputeHash(bp);

            int i;
            // use the low 64-bits for the key value
            for (i = 0; i < 8; i++)
                m_Key[i] = bpHash[i];

            for (i = 8; i < 16; i++)
                m_IV[i - 8] = bpHash[i];

            return true;
        }
        catch (Exception)
        {
            //Error Performing Operations
            return false;
        }
    }
    #endregion

    #region SPP
    /// <summary>
    /// Function to Get SPP Connection string
    /// Added by Shyam Sunder Kumar as on 23-Jun-2015
    /// </summary>
    /// <returns>string</returns>
    public string GetSPPConnection()
    {
        string conString = ConfigurationManager.ConnectionStrings["SPPConnection"].ConnectionString;
        conString = (new SPPUtility()).Decrypt(conString);
        return conString;
    }
    #endregion

    #region SmartDost
    /// <summary>
    /// Function to Get SmartDost Connection string
    /// Added by Shaif 10-9-2017
    /// </summary>
    /// <returns>string</returns>
    public string GetSmartDostConnection()
    {
        string conString = ConfigurationManager.ConnectionStrings["SmartDostConnection"].ConnectionString;
        conString = (new SPPUtility()).Decrypt(conString);
        return conString;
    }
    #endregion
    #region S2P2 Connection string
    /// <summary>
    /// Function to Get S2P2 Connection string
    /// Added by Nikhil 26-9-2022
    /// </summary>
    /// <returns>string</returns>
    public string GetS2P2Connection()
    {
        string conString = ConfigurationManager.ConnectionStrings["S2P2Connection"].ConnectionString;
        conString = (new SPPUtility()).Decrypt(conString);
        return conString;
    }
    #endregion
}
