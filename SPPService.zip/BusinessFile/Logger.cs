﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPPLog.Log
{
    public class Logger : ILogger
    {
        private string assemblyPath = System.Web.HttpContext.Current.Server.MapPath(".");


        public void LogMessage(string vMessage, string vFileName)
        {
            if (ConfigurationManager.AppSettings["IsDebuggingWriteLog"] != null && ConfigurationManager.AppSettings["IsDebuggingWriteLog"].ToUpper() == "Y")
            {
                string vPathName = Path.Combine(assemblyPath, "Logs");

                StreamWriter Sw = default(StreamWriter);
                string VCompletePath = string.Empty;
                string sFileName = DateTime.Now.ToShortDateString().Replace("/", "-");
                VCompletePath = vPathName + "\\" + vFileName + "_LogFile.txt";
                if (!Directory.Exists(vPathName))
                {
                    Directory.CreateDirectory(vPathName);
                }
                if (!File.Exists(VCompletePath))
                {
                    Sw = File.CreateText(VCompletePath);
                    Sw.Close();
                }
                Sw = File.AppendText(VCompletePath);
                Sw.WriteLine(DateTime.Now.ToString() + "\t:\t" + vMessage);
                Sw.Close();
                Sw.Dispose();
            }
        }


    }
}
