﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SPPWebservice.SPPWebserviceDTO;
namespace Auth2.SDS
{
   public interface IAuthProviderfunc
    {
      string getToken();
      bool validationClient(AuthModel authmodel);

        // int InsertToken(AuthModel authmodel);
      bool ValidateTokenParameter(AuthTokenParamRequestDTO input);
      void InsertAuthorizationCode(AuthModel authmodel);
       //TODO: get details API interface
   
    }
}
