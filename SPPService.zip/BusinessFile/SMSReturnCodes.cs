﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SPPWebservice.BusinessFile
{
    public class SMSReturnCodes
    {
        static public int size = 20;
        private string[] namelist = new string[size];
        public Hashtable ht;

        public static string EC0X200 = "Invalid Username or Password.";
        public static string EC0X201 = "Account Suspended due to some reason.";
        public static string EC0X202 = "Invalid Source Address/Sender Id. As per GSM standard the sender ID should be within 11 characters.";
        public static string EC0X203 = "Message Length Exceeded(more than 160 chars) if concat is set to 0";
        public static string EC0X204 = "Message Length Exceeded (more than 459 chars) if concat is set to 1.";
        public static string EC0X205 = "DLR URL is not set.";
        public static string EC0X206 = "Only the subscribed service type can be accessed, so ensure that the service type you are trying to connect with is a subscribed service type.";
        public static string EC0X207 = "Invalid Source IP. Kindly check if the IP is responding.";
        public static string EC0X208 = "Account Deactivated/Expired.";
        public static string EC0X209 = "Invalid Message Length (less than 160 chars) if concat is set to 1.";
        public static string EC0X210 = "Invalid Parameter values.";
        public static string EC0X211 = "Invalid Message Length (more than 280 chars).";
        public static string EC0X212 = "Invalid Message Length.";
        public static string EC0X213 = "Invalid Destination number.";

        //public static int ErrorPositionX200 = 0;
        //public static int ErrorPositionX201 = 1;
        //public static int ErrorPositionX202 = 2;
        //public static int ErrorPositionX203 = 3;
        //public static int ErrorPositionX204 = 4;
        //public static int ErrorPositionX205 = 5;
        //public static int ErrorPositionX206 = 6;
        //public static int ErrorPositionX207 = 7;
        //public static int ErrorPositionX208 = 8;
        //public static int ErrorPositionX209 = 9;
        //public static int ErrorPositionX210 = 10;
        //public static int ErrorPositionX211 = 11;
        //public static int ErrorPositionX212 = 12;
        //public static int ErrorPositionX213 = 13;

        public SMSReturnCodes()
        {
            ht = new Hashtable();

            namelist[0] = EC0X200;
            namelist[1] = EC0X201;
            namelist[2] = EC0X202;
            namelist[3] = EC0X203;
            namelist[4] = EC0X204;
            namelist[5] = EC0X205;
            namelist[6] = EC0X206;
            namelist[7] = EC0X207;
            namelist[8] = EC0X208;
            namelist[9] = EC0X209;
            namelist[10] = EC0X210;
            namelist[11] = EC0X211;
            namelist[12] = EC0X212;
            namelist[13] = EC0X213;



            ht.Add("0X200", 0);
            ht.Add("0X201", 1);
            ht.Add("0X202", 2);
            ht.Add("0X203", 3);
            ht.Add("0X204", 4);
            ht.Add("0X205", 5);
            ht.Add("0X206", 6);
            ht.Add("0X207", 7);
            ht.Add("0X208", 8);
            ht.Add("0X209", 9);
            ht.Add("0X210", 10);
            ht.Add("0X211", 11);
            ht.Add("0X212", 12);
            ht.Add("0X213", 13);
        }

        public string this[int index]
        {
            get
            {
                string tmp;

                if (index >= 0 && index <= size - 1)
                {
                    tmp = namelist[index];
                }
                else
                {
                    tmp = "";
                }

                return (tmp);
            }
            set
            {
                if (index >= 0 && index <= size - 1)
                {
                    namelist[index] = value;
                }
            }
        }
    }
}